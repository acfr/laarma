#include <neuv_defs.hpp>
#include <iostream>
#include <iomanip>
#include <cmath>
#ifdef _WINDOWS
#include <time.h>
#include <fstream>
#include <opencv2/opencv.hpp>
#include <Windows.h>
using namespace cv;
using namespace std;
//std::ofstream data_ofs;

void usleep(unsigned long ulMicroSeconds)
{
	if (ulMicroSeconds < 1000) {
		Sleep(1);
		return;
	}
	Sleep(ulMicroSeconds / 1000);
}

void sleep(unsigned long ulSeconds) 
{
	Sleep(ulSeconds * 1000); 
}

#else
#include <unistd.h>
#include <sys/time.h>
#endif




enum NEU_LASER_RATE
{
    NEU_200KHZ,
    NEU_300KHZ,
    NEU_400KHZ,
    NEU_500KHZ,
    NEU_750KHZ,
    NEU_1P5MHZ
};

const int CONNECT_STATE_CONNECTING = 0;
const int CONNECT_STATE_CONNECTED = 1;
const int CONNECT_STATE_DISCONNECTED = -1;

static int mConnectState = CONNECT_STATE_DISCONNECTED;

neuvition::NeuvWireDatas mNeuvWireDatas;
neuvition::on_wire_data_callback *wire_data_callback = NULL;

cv::Mat mjpgMat;

//// ?????
//double get_timestamp(void) {    
//    struct timeval now;
//    gettimeofday(&now,0);
//    return (double)(now.tv_sec) + (double)(now.tv_usec)/1000000.0;
//}

void showretval(int ret)
{
    if (ret == 0)
        return;
    std::cout << "ret:" << ret << std::endl;
}

// 对INeuvEvent虚类的实\E7\8E?
class myeventh : public neuvition::INeuvEvent
{
public:
    void on_connect(int code, const char *msg)
    {
        std::cout << "[NEUVITION]| Connect... code=" << code << ", msg=" << msg << std::endl;
        if (code == 0)
        {
            mConnectState = CONNECT_STATE_CONNECTED;
        }
        else
        {
            mConnectState = CONNECT_STATE_DISCONNECTED;
        }
    }

    void on_disconnect(int code)
    {
        if (code == 0)
        {
            std::cout << "[NEUVITION]| Disconnect..." << std::endl;
        }
std::cout << "[NEUVITION]| Disconnect1111111..." << std::endl;
        mConnectState = CONNECT_STATE_DISCONNECTED;
    }

    void on_response(int code, enum neuvition::neuv_cmd_code cmd)
    {

        switch (cmd)
        {
        case neuvition::NEUV_CMD_START_SCAN:
        {
            if (code == 0)
            {
                std::cout << "[NEUVITION]| Start scanning..." << std::endl;
            }
            break;
        }

        case neuvition::NEUV_CMD_STOP_SCAN:
        {
            if (code == 0)
            {
                std::cout << "[NEUVITION]| Stop scanning..." << std::endl;
            }
            break;
        }

        case neuvition::NEUV_CMD_START_STREAM:
        {
            if (code == 0)
            {
                std::cout << "[NEUVITION]| Start data streaming..." << std::endl;
            }
            break;
        }

        case neuvition::NEUV_CMD_STOP_STREAM:
        {
            if (code == 0)
            {
                std::cout << "[NEUVITION]| Stop data streaming..." << std::endl;
            }
            break;
        }

        // 上传底层设备配置参数
        case neuvition::NEUV_CMD_GET_PARAMS:
        {
            if (code == 0)
            {
                std::cout << "[NEUVITION]| Device parameters synced..." << std::endl;
            }
            break;
        }
        }
    }

    void on_framedata(int code, int64_t microsec, const neuvition::NeuvUnits& data, const neuvition::nvid_t& frame_id) {
    
    // 通过回调函数on_framedata()返回点云数据
        // 在此函数中进行点云处\E7\90?        
		std::cout<<"[NEUVITION]| On framedata... | Size " << data.size() << std::endl;

      	int ifiltercount = 0;
        float centerx = 0.0
        for (neuvition::NeuvUnits::const_iterator iter = data.begin(); iter != data.end(); iter++) {
            const neuvition::NeuvUnit& np = (*iter);         

        	if(np.intensity> 220) // 计算反射率大于２２０的点个数，并记录出左右位置ｘ
                {
			ifiltercount++;
			centerx+=np.x * 0.001;
	        }
        }
        if(ifiltercount > 10)
        {
		centerx = centerx / ifiltercount;
		int apd_id = -1;
		if(centerx > 0)  // > 0 右边　对应右侧有高反点，可以考虑裁剪１通道
		{
			apd_id = 1;
		}
		else
		{
			apd_id  =3;
		}
		 for (neuvition::NeuvUnits::const_iterator iter = data.begin(); iter != data.end(); iter++) {
            const neuvition::NeuvUnit& np = (*iter);         

        	if(np.apd_id != apd_id) // 不是要裁剪的通道就保留
                {
			//点云存储
	        }
        	}
		
        }
	else
	{
	     // 所有点保存
	}
		
		neuvition::jason_camearinfo_clear(frame_id);

		std::cout << "[NEUVITION]| On framedata... | Size  end " << data.size() << std::endl;
    }

    void on_imudata(int code, int64_t microsec, const neuvition::NeuvUnits &data, const neuvition::ImuData &imu) {}

    void on_pczdata(bool status) {}

    void on_mjpgdata(int code, int64_t microsec, cv::Mat mat)
    {

        std::cout << "[NEUVITION]| On 111111111111111111111 on_mjpgdata... | time | " << microsec << std::endl; // microsec为图像时间戳
		mat.copyTo(mjpgMat);
    }


    void on_rtspdata(int, int64_t microsec, cv::Mat)
    {
           std::cout << "[NEUVITION]| On 111111111111111111111 on_rtspdata... | time | " << microsec << std::endl; // microsec为图像时间戳
    }
    void on_Ladar_Camera(neuvition::NeuvCameraLadarDatas *datas)
    {
neuvition::NeuvCameraLadarDatas _datas = *datas;
            float max_distance=INT_MIN;
            cv::Mat depth(320,640, CV_8UC3, cv::Scalar(0, 0, 0));
            //            cv::Mat depth(640,320, CV_8UC3, cv::Scalar(0, 0, 0));
            for(neuvition::NeuvCameraLadarDatas::const_iterator iter = _datas.begin(); iter != _datas.end(); iter++){
                  const neuvition::CAMERA_POINT_POS& data = (*iter);
                  float distance=std::sqrt(std::pow(data.ladarx,2)+std::pow(data.ladary,2)+std::pow(data.ladarz,2));
                      max_distance=(distance>max_distance?distance:max_distance);
            }
            int r;
int g;
int b;
            std::cout << "Start!!!!!!!!!!!!!!!" << std::endl;
            for(neuvition::NeuvCameraLadarDatas::const_iterator iter = _datas.begin(); iter != _datas.end(); iter++){
                  const neuvition::CAMERA_POINT_POS& data = (*iter);
                  float distance=std::sqrt(std::pow(data.ladarx,2)+std::pow(data.ladary,2)+std::pow(data.ladarz,2));
                      float percent = ((float)distance/(float)max_distance*255.0f) / 255.0;
                  float procent = 1.0f;
                  if (percent >= 1.0f) {
                        ///colorMap[2]
                        r = 0;
                       g = 255;
                        b = 0;

                        ///colorMap[3]
                        r = 255;
                        g = 255;
                        b = 0;
                        procent = 1.0f;
                  }
                  else if (percent >= 0.75f) {
                        ///colorMap[2]
                        r = 0;
                        g = 255;
                        b = 0;
                        ///colorMap[3]
                        r = 255;
                        g = 255;
                        b = 0;
                        procent = (percent - 0.75f) / 0.25f;
                  }
                  else if (percent >= 0.5f) {
                        ///colorMap[1]
                        r = 0;
                        g = 0;
                        b = 255;
                        ///colorMap[2]
                        r = 0;
                        g = 255;
                        b = 0;
                        procent = (percent - 0.5f) / 0.25f;
                  }
                  else if (percent >= 0.25f) {
                        ///colorMap[0]
                        r = 0;
                        g = 0;
                        b = 0;
                        ///colorMap[1]
                        r = 0;
                        g = 0;
                        b = 255;
                        procent = (percent - 0.25f) / 0.25f;
                  }
                  else {
                        ///colorMap[0]
                        r = 0;
                        g = 0;
                        b = 0;
                        ///colorMap[4]
                        r = 255;
                        g = 0;
                        b = 0;
                        procent = (percent) / 0.25f;
                  }
                  depth.at<cv::Vec3b>(data.y,data.x)[0]=r * procent + r * (1.0f - procent);
                  depth.at<cv::Vec3b>(data.y,data.x)[1]=g * procent + g * (1.0f - procent);
                  depth.at<cv::Vec3b>(data.y,data.x)[2]=b * procent + b * (1.0f - procent);
            }
            std::cout << "end!!!!!!!!!!!!!!!!!!" << std::endl;
    }

    void on_lidar_info_status(neuvition::LidarInfoStatus *lidarInfoStatus)
    {
        printf("on_lidar_info_status=============>\n");
        printf("device_type = %s\n", lidarInfoStatus->device_type);
        printf("serial_number = %s\n", lidarInfoStatus->serial_number);
        printf("manufacturer = %s\n", lidarInfoStatus->manufacturer);
        printf("date_of_manufacture = %s\n", lidarInfoStatus->date_of_manufacture);
        printf("hardware_ver = %s\n", lidarInfoStatus->hardware_ver);
        printf("software_ver = %s\n", lidarInfoStatus->software_ver);
        printf("auth_code = %s\n", lidarInfoStatus->auth_code);
        printf("horizontal_fov = %d\n", lidarInfoStatus->horizontal_fov);
        printf("vertical_fov = %d\n", lidarInfoStatus->vertical_fov);
        printf("max_distance = %d(m)\n", lidarInfoStatus->max_distance);
        printf("accuracy = %d(mm)\n", lidarInfoStatus->accuracy);
        printf("wave_length = %d(nm)\n", lidarInfoStatus->wave_length);
        printf("curr_time = %d\n", lidarInfoStatus->curr_time);
        printf("power_on_time = %d\n", lidarInfoStatus->power_on_time);
        printf("laser_power = %d(%%)\n", lidarInfoStatus->laser_power);
        printf("fps = %d\n", lidarInfoStatus->fps);
        printf("laser_rate = %d(KHZ)\n", lidarInfoStatus->laser_rate);
        printf("cam_status = %d\n", lidarInfoStatus->cam_status);
        printf("lidar_status = %d\n", lidarInfoStatus->lidar_status);
        printf("lidar_temperature = %.2f(C)\n", lidarInfoStatus->lidar_temperature);
        printf("<==================on_lidar_info_status\n");
    }

};

void on_wire_data_callback_func(int frame_id, int64_t microsec, float temp, const neuvition::NeuvUnit *points,
                                int cloudsize, const neuvition::NeuvWireData *wire_data, int wire_size)
{
    std::cout << frame_id << " " << microsec << " " << temp << " " << cloudsize << " " << wire_size << std::endl;
    mNeuvWireDatas.clear();
    mNeuvWireDatas.resize(wire_size);
    for (int i = 0; i < wire_size; ++i)
    {
        neuvition::NeuvWireData wp = wire_data[i];
        mNeuvWireDatas.push_back(wp);
        //printf("id=%d, angle=%d, high=%d  ", wp.id, wp.angle, wp.high);
    }
    //std::cout << std::endl;
}

int main(int argc, char *argv[])
{
 	
    return 0;
}
