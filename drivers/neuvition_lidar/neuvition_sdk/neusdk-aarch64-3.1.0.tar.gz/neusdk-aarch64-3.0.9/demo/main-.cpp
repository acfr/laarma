#include <neuv_defs.hpp>
#include <iostream>
#include <iomanip>
#include <cmath>
#ifdef _WINDOWS
#include <time.h>
#include <fstream>
#include <opencv2/opencv.hpp>
#include <Windows.h>
using namespace cv;
using namespace std;
//std::ofstream data_ofs;

void usleep(unsigned long ulMicroSeconds)
{
	if (ulMicroSeconds < 1000) {
		Sleep(1);
		return;
	}
	Sleep(ulMicroSeconds / 1000);
}

void sleep(unsigned long ulSeconds) 
{
	Sleep(ulSeconds * 1000); 
}

#else
#include <unistd.h>
#include <sys/time.h>
#endif




enum NEU_LASER_RATE
{
    NEU_200KHZ,
    NEU_300KHZ,
    NEU_400KHZ,
    NEU_500KHZ,
    NEU_750KHZ,
    NEU_1P5MHZ
};

const int CONNECT_STATE_CONNECTING = 0;
const int CONNECT_STATE_CONNECTED = 1;
const int CONNECT_STATE_DISCONNECTED = -1;

static int mConnectState = CONNECT_STATE_DISCONNECTED;

neuvition::NeuvWireDatas mNeuvWireDatas;
neuvition::on_wire_data_callback *wire_data_callback = NULL;

cv::Mat mjpgMat;

//// ?????
//double get_timestamp(void) {    
//    struct timeval now;
//    gettimeofday(&now,0);
//    return (double)(now.tv_sec) + (double)(now.tv_usec)/1000000.0;
//}

void showretval(int ret)
{
    if (ret == 0)
        return;
    std::cout << "ret:" << ret << std::endl;
}

// 对INeuvEvent虚类的实\E7\8E?
class myeventh : public neuvition::INeuvEvent
{
public:
    void on_connect(int code, const char *msg)
    {
        std::cout << "[NEUVITION]| Connect... code=" << code << ", msg=" << msg << std::endl;
        if (code == 0)
        {
            mConnectState = CONNECT_STATE_CONNECTED;
        }
        else
        {
            mConnectState = CONNECT_STATE_DISCONNECTED;
        }
    }

    void on_disconnect(int code)
    {
        if (code == 0)
        {
            std::cout << "[NEUVITION]| Disconnect..." << std::endl;
        }
std::cout << "[NEUVITION]| Disconnect1111111..." << std::endl;
        mConnectState = CONNECT_STATE_DISCONNECTED;
    }

    void on_response(int code, enum neuvition::neuv_cmd_code cmd)
    {

        switch (cmd)
        {
        case neuvition::NEUV_CMD_START_SCAN:
        {
            if (code == 0)
            {
                std::cout << "[NEUVITION]| Start scanning..." << std::endl;
            }
            break;
        }

        case neuvition::NEUV_CMD_STOP_SCAN:
        {
            if (code == 0)
            {
                std::cout << "[NEUVITION]| Stop scanning..." << std::endl;
            }
            break;
        }

        case neuvition::NEUV_CMD_START_STREAM:
        {
            if (code == 0)
            {
                std::cout << "[NEUVITION]| Start data streaming..." << std::endl;
            }
            break;
        }

        case neuvition::NEUV_CMD_STOP_STREAM:
        {
            if (code == 0)
            {
                std::cout << "[NEUVITION]| Stop data streaming..." << std::endl;
            }
            break;
        }

        // 上传底层设备配置参数
        case neuvition::NEUV_CMD_GET_PARAMS:
        {
            if (code == 0)
            {
                std::cout << "[NEUVITION]| Device parameters synced..." << std::endl;
            }
            break;
        }
        }
    }

    void on_framedata(int code, int64_t microsec, const neuvition::NeuvUnits& data, const neuvition::nvid_t& frame_id) {
    
    // 通过回调函数on_framedata()返回点云数据
        // 在此函数中进行点云处\E7\90?        
		std::cout<<"[NEUVITION]| On framedata... | Size " << data.size() << std::endl;

      
        for (neuvition::NeuvUnits::const_iterator iter = data.begin(); iter != data.end(); iter++) {
            const neuvition::NeuvUnit& np = (*iter);         

            float x = np.x*0.001;
            float y = np.y*0.001;
            float z = np.z*0.001;
        // 如果设置摄像头开启，并开启图像获取，则RGB为真实颜色，否则\E4\B8?28
            uint8_t r = np.r; 
            uint8_t g = np.g; 
            uint8_t b = np.b;
            uint8_t intensity = np.intensity;   
            uint32_t timestamp_m = np.time_sec;
	    uint32_t timestamp_u = np.time_usec;
          
#if 0     //camera fusion test
		neuvition::CameraParams cameraParams = { 0,0,0,0,0,0,0,0,0,0,0 };
		neuvition::CamFusionParams camFusionParams = { 0,0,0,0,0,0 };
		uint8_t bgr[3] = { 0,0,0 };
		int row = 0, col = 0;
		if (!mjpgMat.empty()) {
			neuvition::get_cloudPoint_to_camera_coordiante(np, cameraParams, camFusionParams, mjpgMat, bgr, row, col);
			//std::cout << " tttttttt " << row << " " << col << " " << (int)bgr[2] << " " << (int)bgr[1] <<
			//	" " << (int)bgr[0] << std::endl;
		}
#endif
        }
		
		neuvition::jason_camearinfo_clear(frame_id);
    }

    void on_imudata(int code, int64_t microsec, const neuvition::NeuvUnits &data, const neuvition::ImuData &imu) {}

    void on_pczdata(bool status) {}

    void on_mjpgdata(int code, int64_t microsec, cv::Mat mat)
    {

        std::cout << "[NEUVITION]| On 111111111111111111111 on_mjpgdata... | time | " << microsec << std::endl; // microsec为图像时间戳
		mat.copyTo(mjpgMat);
    }


    void on_rtspdata(int, int64_t microsec, cv::Mat)
    {
           std::cout << "[NEUVITION]| On 111111111111111111111 on_rtspdata... | time | " << microsec << std::endl; // microsec为图像时间戳
    }
    void on_Ladar_Camera(neuvition::NeuvCameraLadarDatas *datas)
    {
    }

    void on_lidar_info_status(neuvition::LidarInfoStatus *lidarInfoStatus)
    {
        printf("on_lidar_info_status=============>\n");
        printf("device_type = %s\n", lidarInfoStatus->device_type);
        printf("serial_number = %s\n", lidarInfoStatus->serial_number);
        printf("manufacturer = %s\n", lidarInfoStatus->manufacturer);
        printf("date_of_manufacture = %s\n", lidarInfoStatus->date_of_manufacture);
        printf("hardware_ver = %s\n", lidarInfoStatus->hardware_ver);
        printf("software_ver = %s\n", lidarInfoStatus->software_ver);
        printf("auth_code = %s\n", lidarInfoStatus->auth_code);
        printf("horizontal_fov = %d\n", lidarInfoStatus->horizontal_fov);
        printf("vertical_fov = %d\n", lidarInfoStatus->vertical_fov);
        printf("max_distance = %d(m)\n", lidarInfoStatus->max_distance);
        printf("accuracy = %d(mm)\n", lidarInfoStatus->accuracy);
        printf("wave_length = %d(nm)\n", lidarInfoStatus->wave_length);
        printf("curr_time = %d\n", lidarInfoStatus->curr_time);
        printf("power_on_time = %d\n", lidarInfoStatus->power_on_time);
        printf("laser_power = %d(%%)\n", lidarInfoStatus->laser_power);
        printf("fps = %d\n", lidarInfoStatus->fps);
        printf("laser_rate = %d(KHZ)\n", lidarInfoStatus->laser_rate);
        printf("cam_status = %d\n", lidarInfoStatus->cam_status);
        printf("lidar_status = %d\n", lidarInfoStatus->lidar_status);
        printf("lidar_temperature = %.2f(C)\n", lidarInfoStatus->lidar_temperature);
        printf("<==================on_lidar_info_status\n");
    }

};

void on_wire_data_callback_func(int frame_id, int64_t microsec, float temp, const neuvition::NeuvUnit *points,
                                int cloudsize, const neuvition::NeuvWireData *wire_data, int wire_size)
{
    std::cout << frame_id << " " << microsec << " " << temp << " " << cloudsize << " " << wire_size << std::endl;
    mNeuvWireDatas.clear();
    mNeuvWireDatas.resize(wire_size);
    for (int i = 0; i < wire_size; ++i)
    {
        neuvition::NeuvWireData wp = wire_data[i];
        mNeuvWireDatas.push_back(wp);
        //printf("id=%d, angle=%d, high=%d  ", wp.id, wp.angle, wp.high);
    }
    //std::cout << std::endl;
}

int main(int argc, char *argv[])
{
    int ret = 0;

#if 0
    // int i = 0;
    // for (i = 0; i < argc; ++i){
    //     printf("argv[%d], %s\n", i, *(argv + i*sizeof(char)));
    // }
    // ??: X/Y??

 	cv::VideoCapture m_VideoCapture;
	 m_VideoCapture.open("rtsp://192.168.1.101:8554/720p-stream");  
	  cv::Mat frame;  
	 while(m_VideoCapture.read(frame))
	 {
	    cv::imshow("test",frame);
	 }
	

    neuvition::start_rtspcamera();
    ret = neuvition::set_flip_axis(false, true);
    showretval(ret);
 #endif

    neuvition::INeuvEvent *phandler = new myeventh();

    mConnectState = CONNECT_STATE_CONNECTING;
    // ??????????
    ret = neuvition::setup_client("192.168.1.101", 6668, phandler /*event-handler*/, false /*auto-reconnect*/);
    usleep(1 * 1000 * 1000);

    while (mConnectState == CONNECT_STATE_CONNECTING)
    {
        usleep(10000);
        printf("waiting...\n");
    }

    usleep(20000);

	//data_ofs.open("C:\\Users\\qk\\Desktop\\20210909\\data.txt");
	//data_ofs.open("C:\\neuvition\\neusdk\\sdk\\demo\\x64\\Release\\data.txt");
    // ????
    if (mConnectState == CONNECT_STATE_CONNECTED)
    {
        // ?????????????????????
        double hfov = neuvition::get_hfov();
        double vfov = neuvition::get_vfov();
        int device_type = neuvition::get_device_type();
        double bias_y = 0.0; //?????,???0

        // ??????%
        // ???:0~65%
      //  ret = neuvition::set_laser_power(60);
        usleep(20000);//20ms

        // ??????????
        // ???:0: 200KHZ 1:300KHZ 2:400KHZ 3:500KHZ 4:750KHZ 5:1MHZ
        ret = neuvition::set_laser_interval(NEU_500KHZ);
        usleep(20000);//20ms

        // ??????FPS
        // ???:3/5/6/10/15/20/30
        ret = neuvition::set_frame_frequency(30);
        usleep(20000);//20ms

		ret = neuvition::set_frame_line_quantity(180);
        // ??: ???????,???????
        // ?????,????
        ret = neuvition::set_camera_status(true);
		ret = neuvition::set_mjpg_curl(true);

        std::cout << "[NEUVITION]| ret " << ret << std::endl;

        //ret = neuvition::set_mjpg_curl(true);
        std::cout << "[NEUVITION]| ret " << ret << std::endl;

        // ??????????
        ret = neuvition::start_scan();
        sleep(2); // 2s

        // ????????????
        ret = neuvition::start_stream();

        // ??10?,???????TOF?????
        // ?????????
        sleep(60*5);

        // ????????????
        ret = neuvition::stop_stream();
        usleep(20000); //20ms

        // ??????????
        ret = neuvition::stop_scan();

        // ??????????
        ret = neuvition::teardown_client();
        usleep(200000); //20ms
    }
	//if (data_ofs.is_open())
	//	data_ofs.close();

   
    delete phandler;
    return 0;
}
