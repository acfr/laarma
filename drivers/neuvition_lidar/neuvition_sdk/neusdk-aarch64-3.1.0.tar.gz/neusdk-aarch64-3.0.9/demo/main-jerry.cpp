#include <neuv_defs.hpp>
#include <iostream>
#include <iomanip>
#include <cmath>


#ifdef _WINDOWS

#else // !_Win
#include <unistd.h>
#include <sys/time.h>

#endif

#ifdef _WINDOWS
#include <Windows.h>
#include <time.h>


void usleep(unsigned long ulMicroSeconds)
{
	if (ulMicroSeconds < 1000) {
		Sleep(1);
		return;
	}
	Sleep(ulMicroSeconds / 1000);
}

void sleep(unsigned long ulSeconds)
{
	Sleep(ulSeconds*1000);
}
#endif


enum NEU_LASER_RATE {NEU_200KHZ, NEU_300KHZ, NEU_400KHZ, NEU_500KHZ, NEU_750KHZ, NEU_1P5MHZ};

const int CONNECT_STATE_CONNECTING = 0;
const int CONNECT_STATE_CONNECTED = 1;
const int CONNECT_STATE_DISCONNECTED = -1;

static int mConnectState = CONNECT_STATE_DISCONNECTED;

neuvition::NeuvWireDatas mNeuvWireDatas;
neuvition::on_wire_data_callback *wire_data_callback = NULL;

//// 获取时间戳
//double get_timestamp(void) {
//    struct timeval now;
//    gettimeofday(&now,0);
//    return (double)(now.tv_sec) + (double)(now.tv_usec)/1000000.0;
//} 

void showretval(int ret) { if(ret == 0) return; std::cout<<"ret:"<<ret<<std::endl;}

// 对INeuvEvent虚类的实现
class myeventh : public neuvition::INeuvEvent
{
public:  
    virtual void on_connect(int code,const char* msg) {
        std::cout<<"[NEUVITION]| Connect... code=" << code << ", msg="<< msg << std::endl;
        if (code == 0) {  
            mConnectState = CONNECT_STATE_CONNECTED;
        } else {
            mConnectState = CONNECT_STATE_DISCONNECTED;
        }
    }

    virtual void on_disconnect(int code) {
        if (code == 0) { std::cout<<"[NEUVITION]| Disconnect..." << std::endl; }
        mConnectState = CONNECT_STATE_DISCONNECTED; 
    }

    virtual void on_response(int code,enum neuvition::neuv_cmd_code cmd) {

        switch (cmd) {
            case neuvition::NEUV_CMD_START_SCAN: {
                if (code == 0) { std::cout<<"[NEUVITION]| Start scanning..." << std::endl; }
                break;
            }

            case neuvition::NEUV_CMD_STOP_SCAN: {
                if (code == 0) { std::cout<<"[NEUVITION]| Stop scanning..." << std::endl; }
                break;
            }

            case neuvition::NEUV_CMD_START_STREAM: {
                if (code == 0) { std::cout<<"[NEUVITION]| Start data streaming..." << std::endl; }
                break;
            }

            case neuvition::NEUV_CMD_STOP_STREAM: {
                if (code == 0) { std::cout<<"[NEUVITION]| Stop data streaming..." << std::endl; }
                break;
            }

            // 上传底层设备配置参数
            case neuvition::NEUV_CMD_GET_PARAMS: {
                if (code == 0) { std::cout<<"[NEUVITION]| Device parameters synced..." << std::endl; }
                break;
            }

        }
    }

    void on_framedata(int code, int64_t microsec, const neuvition::NeuvUnits& data, const neuvition::nvid_t& frame_id) {
    
    // 通过回调函数on_framedata()返回点云数据
        // 在此函数中进行点云处理
        std::cout<<"[NEUVITION]| On framedata... | Size " << data.size() << std::endl;
 	

        if (data.size() == 0) return;
   
        int itest = 0;
        for (neuvition::NeuvUnits::const_iterator iter = data.begin(); iter != data.end(); iter++) {
            const neuvition::NeuvUnit& np = (*iter);
		
            if(itest == 0)
	    {
             //  std::cout<<"[NEUVITION]| On framedata... | microsec " << np.timestamp << std::endl; // np.timestamp 是每个点的时间戳。正常一帧只要获取一个点的时间戳即可
            }
	    itest++;
            float x = np.x*0.001;
            float y = np.y*0.001;
            float z = np.z*0.001;
        // 如果设置摄像头开启，并开启图像获取，则RGB为真实颜色，否则为128
            uint8_t r = np.r; 
            uint8_t g = np.g; 
            uint8_t b = np.b;
            uint8_t intensity = np.intensity;   
			uint32_t time_sec = np.time_sec;
			uint32_t time_usec = np.time_usec;
        }
    }

    void on_imudata(int code,int64_t microsec, const neuvition::NeuvUnits& data,const neuvition::ImuData& imu) {}

    void on_pczdata(bool status) {}

   void on_mjpgdata(int code, int64_t microsec, cv::Mat mat) {

	
	   std::cout<<"[NEUVITION]| On 111111111111111111111 on_mjpgdata... | time | "<<microsec <<std::endl; // microsec为图像时间戳
        

    }

    void on_Ladar_Camera( neuvition::NeuvCameraLadarDatas* datas) {

    }
};

void on_wire_data_callback_func(int frame_id, int64_t microsec, float temp, const neuvition::NeuvUnit* points,
	int cloudsize, const neuvition::NeuvWireData* wire_data, int wire_size) {
	std::cout << frame_id << " " << microsec << " " << temp << " " << cloudsize << " " << wire_size << std::endl;
	mNeuvWireDatas.clear();
	mNeuvWireDatas.resize(wire_size);
	for (int i = 0; i < wire_size; ++i) {
		neuvition::NeuvWireData wp = wire_data[i];
		mNeuvWireDatas.push_back(wp);
		//neu_log(NEU_INFO, "id=%d, angle=%d, high=%d  ", wp.id, wp.angle, wp.high);
	}
	//std::cout << std::endl;
}

int main(int argc, char* argv[]) {
    int ret=0;

    // int i = 0;
    // for (i = 0; i < argc; ++i){
    //     printf("argv[%d], %s\n", i, *(argv + i*sizeof(char)));
    // }
    // 可选: X/Y轴翻转
    ret = neuvition::set_flip_axis(false,true);
    showretval(ret);

    neuvition::INeuvEvent* phandler = new myeventh();

    mConnectState = CONNECT_STATE_CONNECTING;
    // 建立与底层设备的连接
    ret = neuvition::setup_client("192.168.1.101",6668,phandler/*event-handler*/,false/*auto-reconnect*/);
    usleep(1*1000*1000);

    while(mConnectState == CONNECT_STATE_CONNECTING) {
        usleep(10000);
        printf("waiting...\n");
    }

    usleep(20000);

    // 查询状态
    if (mConnectState == CONNECT_STATE_CONNECTED) {
        // 获取设备视场角、设备类型、俯仰角、位置参数
        double hfov = neuvition::get_hfov();
        double vfov = neuvition::get_vfov();
        int device_type = neuvition::get_device_type();
        double bias_y = 0.0;    //设备俯仰角，默认为0

        // 设置激光功率%
        // 范围值：0~65%
       // ret = neuvition::set_laser_power(60);
        usleep(20000);//20ms

        // 设置激光发射频率档位
        // 可选值：0: 200KHZ 1:300KHZ 2:400KHZ 3:500KHZ 4:750KHZ 5:1MHZ
        ret = neuvition::set_laser_interval(NEU_500KHZ);
        usleep(20000);//20ms

        // 设置点云帧率FPS
        // 可选值：3/5/6/10/15/20/30
        ret = neuvition::set_frame_frequency(10);
        usleep(20000);//20ms

      	
	
  // 可选: 设置摄像头开启，并开启图像获取
        // 如果不使用，直接注释
        ret = neuvition::set_camera_status(true);


	   std::cout<<"[NEUVITION]| ret "<<ret <<std::endl;
        
        ret = neuvition::set_mjpg_curl(true);
std::cout<<"[NEUVITION]| ret "<<ret <<std::endl;   
        

        // 请求底层设备开始扫描
        ret=neuvition::start_scan();
        sleep(2); // 2s

        // 请求底层设备开始送点云流
        ret=neuvition::start_stream();
    

        // 等待10秒,从底层设备获取TOF数据并回调
        // 等待时间可自行定义
        sleep(20);

        // 请求底层设备停止送点云流
        ret=neuvition::stop_stream();
        usleep(20000);//20ms

        // 请求底层设备停止扫描
        ret=neuvition::stop_scan();

        // 断开与底层设备的连接
        ret=neuvition::teardown_client();
        usleep(200000);//20ms

    } 

    usleep(1*1000*1000);
    delete phandler;
    return 0;

}

