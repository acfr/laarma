code=1
msg=2 
print('[NEUVITION]| Connect... code={code}, msg={msg}'.format(code=code, msg=msg))
