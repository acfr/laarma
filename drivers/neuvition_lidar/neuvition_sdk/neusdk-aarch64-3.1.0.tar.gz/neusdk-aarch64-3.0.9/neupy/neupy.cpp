#include <pybind11/stl.h>
#include <pybind11/pybind11.h>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <pybind11/embed.h>
#include <pybind11/numpy.h>
#include "neuv_defs.hpp"
namespace py = pybind11;
using namespace py::literals;
using namespace neuvition;
using std::vector;

py::array_t<unsigned char> matToNumpy_Gray(cv::Mat& img) {
	return py::array_t<unsigned char>({ img.rows,img.cols }, img.data);
}
 
py::array_t<unsigned char> matToNumpy_Color(cv::Mat& img,int channel) {
	return py::array_t<unsigned char>({ img.rows,img.cols,channel}, img.data);
}

vector<unsigned char> matToVector(cv::Mat& img,int channel) {
	vector<unsigned char> vecdata;
	vecdata.clear();
	int isize = img.rows * img.cols * channel;
	vecdata.reserve(img.rows * img.cols * channel); // Requests that the vector capacity be at least enough to contain n elements.
	for (size_t i = 0; i < isize; ++i) {
		unsigned char v = img.data[i];
		vecdata.push_back(v);
	}
	return vecdata;
}



class PyNeuvEvent : public INeuvEvent {
public:
    using INeuvEvent::INeuvEvent; // Inherit constructors
    void on_connect(int code, const char *msg) override {
        PYBIND11_OVERRIDE_PURE(void, INeuvEvent, on_connect,
                               code, msg
        );
    }

    void on_disconnect(int code) override {
        PYBIND11_OVERRIDE_PURE(void, INeuvEvent, on_disconnect,
                               code
        );
    }

    void on_response(int code, enum neuv_cmd_code cmd) override {
        PYBIND11_OVERRIDE_PURE(void, INeuvEvent, on_response,
                               code, cmd
        );
    }

    void on_framedata(int code, int64_t microsec, const NeuvUnits &data, const nvid_t &frame_id) override {
        PYBIND11_OVERRIDE_PURE(void, INeuvEvent, on_framedata,
                               code, microsec, data, frame_id
        );
    }

    void on_imudata(int code, int64_t microsec, const NeuvUnits &data, const ImuData &imu) override {
        PYBIND11_OVERRIDE_PURE(void, INeuvEvent, on_imudata,
                               code, microsec, data, imu
        );
    }

    void on_mjpgdata(int code, int64_t microsec, cv::Mat mat) override {
      	if(mat.empty())
	{
		return ;
	}
	int channelsize = mat.channels();
	printf("on_mjpgdata______on_mjpgdata\n");
	vector<unsigned char> vecdata;
        vecdata = matToVector(mat,channelsize);
	printf("on_mjpgdata______on_mjpgdata11111111111\n");
	cv::imwrite("1.png",mat);
	
	//arraydata = matToNumpy_Color(mat,channelsize);
	
        PYBIND11_OVERRIDE_PURE(void, INeuvEvent, on_mjpgdata,
                               code, microsec,channelsize,vecdata
        );
    }

    void on_pczdata(bool status) override {
        PYBIND11_OVERRIDE_PURE(void, INeuvEvent, on_pczdata,
                               status
        );
    }

    void on_Ladar_Camera(NeuvCameraLadarDatas *datas) override {
        PYBIND11_OVERRIDE_PURE(void, INeuvEvent, on_Ladar_Camera,
                               datas
        );
    }

    void on_lidar_info_status(LidarInfoStatus *lidarInfoStatus) override {
	printf("on_lidar_info_status\n");
	int a = 22;
        PYBIND11_OVERRIDE_PURE(void, INeuvEvent, on_lidar_info_status,
                               a
        );
    }
};


PYBIND11_MODULE(neupy, m) {
    py::class_<INeuvEvent, PyNeuvEvent /* <--- trampoline*/>(m, "PyNeuvEvent")
            .def(py::init<>())
            .def("on_connect", &INeuvEvent::on_connect)
            .def("on_disconnect", &INeuvEvent::on_disconnect)
            .def("on_response", &INeuvEvent::on_response)
            .def("on_framedata", &INeuvEvent::on_framedata)
            .def("on_imudata", &INeuvEvent::on_imudata)
            .def("on_mjpgdata", &INeuvEvent::on_mjpgdata)
            .def("on_pczdata", &INeuvEvent::on_pczdata)
            .def("on_Ladar_Camera", &INeuvEvent::on_Ladar_Camera)
            .def("on_lidar_info_status", &INeuvEvent::on_lidar_info_status);

    py::class_<NEUV_UNIT>(m, "PyNeuvUnit")
            .def(py::init<>())
            .def_readonly("x", &NEUV_UNIT::x)
            .def_readonly("x", &NEUV_UNIT::x)
            .def_readonly("y", &NEUV_UNIT::y)
            .def_readonly("z", &NEUV_UNIT::z)
            .def_readonly("r", &NEUV_UNIT::r)
            .def_readonly("g", &NEUV_UNIT::g)
            .def_readonly("b", &NEUV_UNIT::b)
            .def_readonly("lid", &NEUV_UNIT::lid)
            .def_readonly("apd", &NEUV_UNIT::apd_id)
            .def_readonly("row", &NEUV_UNIT::row)
            .def_readonly("col", &NEUV_UNIT::col)
            .def_readonly("tof", &NEUV_UNIT::tof)
            .def_readonly("intensity", &NEUV_UNIT::intensity)
            .def_readonly("time", &NEUV_UNIT::time_sec)
            .def_readonly("time", &NEUV_UNIT::time_usec)
            .def_readonly("level", &NEUV_UNIT::level)
            .def_readonly("tofts", &NEUV_UNIT::tofts)
            .def_readonly("intensityts", &NEUV_UNIT::intensityts);

    py::class_<CAMERA_POINT_POS>(m, "PyCamera_point_pos")
            .def(py::init<>())
            .def_readonly("x", &CAMERA_POINT_POS::x)
            .def_readonly("y", &CAMERA_POINT_POS::y)
            .def_readonly("pixel_id", &CAMERA_POINT_POS::pixel_id)
            .def_readonly("line_id", &CAMERA_POINT_POS::line_id)
	    .def_readonly("r", &CAMERA_POINT_POS::r)
            .def_readonly("g", &CAMERA_POINT_POS::g)
            .def_readonly("b", &CAMERA_POINT_POS::b)
            .def_readonly("ladarx", &CAMERA_POINT_POS::ladarx)
            .def_readonly("ladary", &CAMERA_POINT_POS::ladary)
            .def_readonly("ladarz", &CAMERA_POINT_POS::ladarz);

    py::enum_<neuv_cmd_code>(m, "NeuvCmdCode")
            .value("START_SCAN", neuv_cmd_code::NEUV_CMD_START_SCAN)
            .value("STOP_SCAN", neuv_cmd_code::NEUV_CMD_STOP_SCAN)
            .value("GET_DEVICE_INFO", neuv_cmd_code::NEUV_CMD_GET_DEVICE_INFO)
            .value("START_STREAM", neuv_cmd_code::NEUV_CMD_START_STREAM)
            .value("STOP_STREAM", neuv_cmd_code::NEUV_CMD_STOP_STREAM)
            .value("SHUTDOWN", neuv_cmd_code::NEUV_CMD_SHUTDOWN)
            .value("GET_PARAMS", neuv_cmd_code::NEUV_CMD_GET_PARAMS)
            .value("SET_RT_PARAM", neuv_cmd_code::NEUV_CMD_SET_RT_PARAM)
            .value("SET_LASER_KHZLV", neuv_cmd_code::NEUV_CMD_SET_LASER_KHZLV)
            .value("SET_LASER_COUNT", neuv_cmd_code::NEUV_CMD_SET_LASER_COUNT)
            .value("SET_FRAME_COUNT", neuv_cmd_code::NEUV_CMD_SET_FRAME_COUNT)
            .value("SET_TRECT_LINE", neuv_cmd_code::NEUV_CMD_SET_TRECT_LINE)
            .value("SET_TRECT_PIXEL", neuv_cmd_code::NEUV_CMD_SET_TRECT_PIXEL)
            .value("SET_PWM_VALUE", neuv_cmd_code::NEUV_CMD_SET_PWM_VALUE)
            .value("SET_SCAN_MODE", neuv_cmd_code::NEUV_CMD_SET_SCAN_MODE)
            .value("SET_DAC_VOLTAGE", neuv_cmd_code::NEUV_CMD_SET_DAC_VOLTAGE)
            .value("SET_NOISE_POINTS", neuv_cmd_code::NEUV_CMD_SET_NOISE_POINTS)
            .value("SET_VOXTEL_PERIOD", neuv_cmd_code::NEUV_CMD_SET_VOXTEL_PERIOD)
            .value("SET_CAMERA_CROP_WH", neuv_cmd_code::NEUV_CMD_SET_CAMERA_CROP_WH)
            .value("SET_CAMERA_CROP_XY", neuv_cmd_code::NEUV_CMD_SET_CAMERA_CROP_XY)
            .value("SET_SYS_MODE", neuv_cmd_code::NEUV_CMD_SET_SYS_MODE)
            .value("SET_LASER_TASK_MODE", neuv_cmd_code::NEUV_CMD_SET_LASER_TASK_MODE)
            .value("SAVE_CONFIG_DATA", neuv_cmd_code::NEUV_CMD_SAVE_CONFIG_DATA)
            .value("SET_PIXEL_OFFSET", neuv_cmd_code::NEUV_CMD_SET_PIXEL_OFFSET)
            .value("SET_DENSITY", neuv_cmd_code::NEUV_CMD_SET_DENSITY)
            .value("UPDATE_FPGA_VERSION", neuv_cmd_code::NEUV_CMD_UPDATE_FPGA_VERSION)
            .value("UPDATE_FPGA_STATUS", neuv_cmd_code::NEUV_CMD_UPDATE_FPGA_STATUS)
            .value("GET_DEVICE_STATUS", neuv_cmd_code::NEUV_CMD_GET_DEVICE_STATUS)
            .value("CAM_IMAGE_UPDATED", neuv_cmd_code::NEUV_CMD_CAM_IMAGE_UPDATED)
            .value("SET_CAM_X_DEVIATE", neuv_cmd_code::NEUV_CMD_SET_CAM_X_DEVIATE)
            .value("SET_CAM_Y_DEVIATE", neuv_cmd_code::NEUV_CMD_SET_CAM_Y_DEVIATE)
            .value("SET_CAM_Z_DEVIATE", neuv_cmd_code::NEUV_CMD_SET_CAM_Z_DEVIATE)
            .value("STILL_ALIVE", neuv_cmd_code::NEUV_CMD_STILL_ALIVE)
            .value("GPS_UPDATED", neuv_cmd_code::NEUV_CMD_GPS_UPDATED)
            .value("SET_VOLTAGE_OFFSET", neuv_cmd_code::NEUV_CMD_SET_VOLTAGE_OFFSET)
            .value("GET_LIDAR_INFO_STATUS", neuv_cmd_code::NEUV_CMD_GET_LIDAR_INFO_STATUS)
            .value("NIL", neuv_cmd_code::NEUV_CMD_NIL)
            .value("TEMP0", neuv_cmd_code::NEUV_CMD_TEMP0)
            .value("TEMP1", neuv_cmd_code::NEUV_CMD_TEMP1)
            .value("TEMP2", neuv_cmd_code::NEUV_CMD_TEMP2)
            .value("TEMP3", neuv_cmd_code::NEUV_CMD_TEMP3)
            .value("TEMP4", neuv_cmd_code::NEUV_CMD_TEMP4)
            .value("TEMP5", neuv_cmd_code::NEUV_CMD_TEMP5)
            .value("TEMP6", neuv_cmd_code::NEUV_CMD_TEMP6)
            .value("TEMP7", neuv_cmd_code::NEUV_CMD_TEMP7)
            .value("TEMP8", neuv_cmd_code::NEUV_CMD_TEMP8)
            .value("TEMP9", neuv_cmd_code::NEUV_CMD_TEMP9)
            .value("TEMP10", neuv_cmd_code::NEUV_CMD_TEMP10)
            .value("TEMP80", neuv_cmd_code::NEUV_CMD_TEMP80)
            .value("TEMP81", neuv_cmd_code::NEUV_CMD_TEMP81)
            .value("TEMP_RSP", neuv_cmd_code::NEUV_CMD_TEMP_RSP)
            .value("LIVE_PUB", neuv_cmd_code::NEUV_CMD_LIVE_PUB)
            .value("LIVE_SUB", neuv_cmd_code::NEUV_CMD_LIVE_SUB)
            .value("LIVE_FRH", neuv_cmd_code::NEUV_CMD_LIVE_FRH)
            .value("LIVE_FRT", neuv_cmd_code::NEUV_CMD_LIVE_FRT)
            .value("LIVE_PCZ", neuv_cmd_code::NEUV_CMD_LIVE_PCZ)
            .value("LIVE_CLP", neuv_cmd_code::NEUV_CMD_LIVE_CLP)
            .value("LIVE_SLP", neuv_cmd_code::NEUV_CMD_LIVE_SLP)
            .value("LIVE_PS1", neuv_cmd_code::NEUV_CMD_LIVE_PS1)
            .value("LIVE_PS2", neuv_cmd_code::NEUV_CMD_LIVE_PS2)
            .value("LIVE_LS0", neuv_cmd_code::NEUV_CMD_LIVE_LS0)
            .value("LIVE_LS1", neuv_cmd_code::NEUV_CMD_LIVE_LS1)
            .value("LIVE_LS2", neuv_cmd_code::NEUV_CMD_LIVE_LS2)
            .value("LIVE_NIL", neuv_cmd_code::NEUV_CMD_LIVE_NIL)
            .export_values();

    //m.def("Get_Pcz_PosCorParams", &Get_Pcz_PosCorParams);
    //m.def("Set_Pcz_PosCorParams", &Set_Pcz_PosCorParams);
    m.def("set_pczevent_callback", &set_pczevent_callback);
    m.def("open_pczdata", &open_pczdata);
    m.def("set_event_callback", &set_event_callback);
    m.def("compute_tof2xyz_table", &compute_tof2xyz_table);
    m.def("compute_tof2xyz_table_with_multi_lasers", &compute_tof2xyz_table_with_multi_lasers);
    m.def("ntohll", &ntohll);
    m.def("htonll", &htonll);
    m.def("setup_client", &setup_client);
    m.def("setup_client2", &setup_client2);
    m.def("teardown_client", &teardown_client);
    m.def("start_scan", &start_scan);
    m.def("stop_scan", &stop_scan);
    m.def("start_stream", &start_stream);
    m.def("stop_stream", &stop_stream);
    m.def("shutdown_device", &shutdown_device);
    m.def("query_device_status", &query_device_status);
    m.def("query_device_params", &query_device_params);
    m.def("save_device_params", &save_device_params);
    m.def("set_event_handler", &set_event_handler);
    m.def("set_reconnect_params", &set_reconnect_params);
    m.def("set_flip_axis", &set_flip_axis);
    m.def("set_laser_power", &set_laser_power);
    m.def("set_laser_interval", &set_laser_interval);
    m.def("set_scan_mode", &set_scan_mode);
    m.def("set_frame_frequency", &set_frame_frequency);
    m.def("set_frame_line_quantity", &set_frame_line_quantity);
    m.def("set_camera_status", &set_camera_status);
    m.def("set_imu_status", &set_imu_status);
    m.def("set_gps_status", &set_gps_status);
    m.def("get_laser_power", &get_laser_power);
    m.def("get_laser_interval", &get_laser_interval);
    m.def("get_laser_angles", &get_laser_angles);
    m.def("get_gps_details", &get_gps_details);
    m.def("get_poscor_params", &get_poscor_params);
    m.def("get_laser_status", &get_laser_status);
    m.def("get_lidar_info_status", &get_lidar_info_status);
    m.def("get_frame_frequency", &get_frame_frequency);
    m.def("get_frame_line_quantity", &get_frame_line_quantity);
    m.def("get_scan_mode", &get_scan_mode);
    m.def("get_device_type", &get_device_type);
    m.def("get_tof_one_length", &get_tof_one_length);
    m.def("get_tof_with_timestamp", &get_tof_with_timestamp);
    m.def("is_camera_on", &is_camera_on);
    m.def("is_imu_on", &is_imu_on);
    m.def("set_data_save", &set_data_save);
    m.def("set_mjpg_curl", &set_mjpg_curl);
    m.def("get_hfov", &get_hfov);
    m.def("get_vfov", &get_vfov);
    m.def("is_connected", &is_connected);
    m.def("is_scanning", &is_scanning);
    m.def("is_streaming", &is_streaming);
    m.def("get_lidar_frame_count", &get_lidar_frame_count);
    m.def("get_lidar_transferred_bytes", &get_lidar_transferred_bytes);
}
