from time import sleep
from neupy import PyNeuvUnit, PyNeuvEvent, PyCamera_point_pos,setup_client, set_laser_interval, set_frame_frequency, \
    set_frame_line_quantity, start_scan, start_stream, stop_stream, teardown_client,set_camera_status,set_mjpg_curl,stop_scan
from neupy import NeuvCmdCode as CMDCODE

CONNECT_STATE_DISCONNECTED = 0
CONNECT_STATE_CONNECTED = 1

NEU_200KHZ = 0
NEU_300KHZ = 1
NEU_400KHZ = 2
NEU_500KHZ = 3
NEU_750KHZ = 4
NEU_1P5MHZ = 5


class MyNeuv(PyNeuvEvent):
    # virtual function override
    def __init__(self):
        super(MyNeuv, self).__init__()
        self.__connset_state = CONNECT_STATE_DISCONNECTED
        self.__framecount = 0
        self.__mjpgnum = 0
    def on_connect(self, code, msg):
        #print(f'[NEUVITION]| Connect... code={code}, msg={msg} ')
        if code == 0:
            self.__connset_state = CONNECT_STATE_CONNECTED
        else:
            self.__connset_state = CONNECT_STATE_DISCONNECTED

    def on_disconnect(self, code):
        if code == 0:
            print('[NEUVITION]| Disconnect...')
        self.__connset_state = CONNECT_STATE_DISCONNECTED

    def on_response(self, code, cmd):
        print('1111')
        print('[MyNeuv] on_response, code=%s, cmd=%s'%(code, cmd))

    def on_framedata(self, code, microsec, data, frame_id):
        size = len(data)
        print('on_framedataon_framedataon_framedataon_framedataon_framedata')
       	print('[NEUVITION]| on_framedata | code %s | microsec %s | Size %s | id %s'%(code, microsec,size,frame_id))
       	print(data[0].x, data[-1].y, data[size-1].y, data[size-1].tofts)
        itest = 0
        self.__framecount += 1

    def on_mjpgdata(self, code,microsec,channelsize,arraydata):
        #print('__mjpgnum = ',self.__mjpgnum)
        print('on_mjpgdataon_mjpgdataon_mjpgdataon_mjpgdata')
        #print('channelsize = ',channelsize)
        #print('data = ',arraydata)
        #print(f'[NEUVITION]| on_mjpgdata... | time | {microsec}')
        #self.__mjpgnum += 1

    def on_lidar_info_status(self, info):
        print('on_lidar_info_status')
        #print('on_lidar_info_status=============>')

    # custom function
    def is_connected(self):
        return self.__connset_state == CONNECT_STATE_CONNECTED

    def wait_for_connected(self):
        while not self.is_connected():
            sleep(1)
            print('waiting...')
    def on_Ladar_Camera(self, datas):
        print('on_Ladar_Camera')

if __name__ == '__main__':
    neuvHandler = MyNeuv()
    ret = setup_client(
        "192.168.1.101",
        6668,
        neuvHandler,  # event-handler
        True,  # auto-reconnect
    )
    neuvHandler.wait_for_connected()

    # todo: check cmd code def
    set_laser_interval(NEU_500KHZ)
    sleep(0.02)
    set_frame_frequency(10)
    sleep(0.02)
#    set_camera_status(True)
#   set_mjpg_curl(True)
 
    start_scan()
    sleep(2)
    start_stream()
    
    sleep(30)

    # todo
    #set_camera_status(False)
    #set_mjpg_curl(False)
    stop_stream()
    sleep(0.02)
    stop_scan()
    sleep(0.02)
    teardown_client()
    sleep(0.02)

    sleep(1)
