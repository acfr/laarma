#include "NeuvitionViewerDemo.h"
#include "ui_NeuvitionViewerDemo.h"

#include <stdio.h>

#include <QDesktopServices>
#include <QUrl>

#include <opencv2/imgproc/types_c.h>
#include <opencv2/dnn.hpp>
#include <opencv2/dnn/shape_utils.hpp>
#include <curl/curl.h>
#include <curl/easy.h>

#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>
#include <boost/lockfree/spsc_queue.hpp>
#include <boost/atomic.hpp>

#include <QDebug>
#define UNUSED(var) (void)(var)

extern NeuvitionViewerDemo *mNeuvitionViewerDemo;

const uint32_t coloredge[6] = {0xffff00, 0xff0000, 0xff00ff, 0x0000ff, 0x00ffff, 0x00ff00};
const static int mHostPort = 6668;

const static uint8_t COLOR_R = 0x80;
const static uint8_t COLOR_G = 0x80;
const static uint8_t COLOR_B = 0x80;

static std::string mHostIP = "192.168.1.101";
static int mTofColorCycle = 0;

bool cameraLidarEnabled = false;
neuvition::NeuvUnits cloudFrame;

cv::Mat mJpegMat;

boost::mutex cloudMutex;
bool bRtsp = false;

void start_rtsp()
{
	char rtspbuf[100] = "";
	sprintf(rtspbuf, "rtsp://%s:8554/720p-stream", mHostIP.c_str());
	neuvition::start_rtspcamera(rtspbuf);
}

int custom_ffs(uint32_t x)
{
	if (x == 0)
	{
		return 0;
	}
	int num = 1;
	if ((x & 0xffff) == 0)
	{
		num += 16;
		x >>= 16;
	}
	if ((x & 0xff) == 0)
	{
		num += 8;
		x >>= 8;
	}
	if ((x & 0xf) == 0)
	{
		num += 4;
		x >>= 4;
	}
	if ((x & 0x3) == 0)
	{
		num += 2;
		x >>= 2;
	}
	if ((x & 0x1) == 0)
	{
		num += 1;
	}
	return num;
}

int jpeg_download_run()
{
	cv::VideoWriter outputVideo;
	cv::Mat mat;
	QString video_fname;
	long framenum = 0;
	Ui::NeuvitionViewerDemoClass *uip = mNeuvitionViewerDemo->getUiPtr();
	//	cout << " *************JPEG Thread | IN************* " << endl;
	while (1)
	{
		// camera start uploading .jpg
		//if (uip->checkBoxCamera->isChecked())
		//{
			if (mNeuvitionViewerDemo->mRefreshCamImage && mNeuvitionViewerDemo->mDeviceConnected)
			{
				if (!mJpegMat.empty())
				{
					mat = mJpegMat.clone(); // refresh Mat
					mJpegMat.release();
				}
				mNeuvitionViewerDemo->mRefreshCamImage = false;
				if (uip->dockWidgetImage->isVisible())
				{
					// function: show jpeg
					if (!mat.empty())
					{
						mNeuvitionViewerDemo->mImageMat = mat.clone();
						uip->openGLWidget->update();
					}
				}
			}
		//}
		//else
		//{
		//	break;
		//}
#ifdef _WINDOWS
		Sleep(5);
#else
		usleep(5000);
#endif
	}
	outputVideo.release();
	mNeuvitionViewerDemo->mVideoThreadRunning = false;
	//cout << " *************JPEG Thread | OUT************* " << endl;
	return 1;
}

int neuv_init_jpeg_download_run()
{
	boost::thread jpeg_download_thread(&jpeg_download_run);
	jpeg_download_thread.detach();
	mNeuvitionViewerDemo->mVideoThreadRunning = true;
	return 0;
}

UIObject::UIObject()
{
}
UIObject::~UIObject()
{
}

void UIObject::runUpdateButton(bool enabled0, bool enabled1, bool enabled2, bool enabled3, bool enabled4, bool enabled5)
{
	emit updateButtons(enabled0, enabled1, enabled2, enabled3, enabled4, enabled5);
}

void UIObject::runUpdateCloudView()
{
	emit updateCloudView();
}

void UIObject::runUpdateConfigView()
{
	emit updateConfigView();
}

void UIObject::runRefreshInfoView()
{
	emit refreshInfoView();
}

UIObject *mUIObject;

class gEventHandler : public neuvition::INeuvEvent
{
public:
	void on_connect(int code, const char *msg)
	{
		if (code == 0)
		{
			mUIObject->runUpdateButton(false, true, true, false, false, false);
		}
	}

	void on_disconnect(int code)
	{
		if (code == 0)
		{
			mUIObject->runUpdateButton(true, false, false, false, false, false);
		}
	}

	void on_response(int code, neuvition::neuv_cmd_code cmd)
	{
		switch (cmd)
		{
		case neuvition::NEUV_CMD_START_SCAN:
		{
			if (code == 0)
			{
				mUIObject->runUpdateButton(false, false, false, true, true, false);
			}
			break;
		}
		case neuvition::NEUV_CMD_STOP_SCAN:
		{
			if (code == 0)
			{
				mUIObject->runUpdateButton(false, true, true, false, false, false);
			}
			break;
		}
		case neuvition::NEUV_CMD_START_STREAM:
		{
			if (code == 0)
			{
				mUIObject->runUpdateButton(false, false, false, false, false, true);
			}
			break;
		}
		case neuvition::NEUV_CMD_STOP_STREAM:
		{
			if (code == 0)
			{
				mUIObject->runUpdateButton(false, false, false, true, true, false);
			}
			break;
		}
		case neuvition::NEUV_CMD_GET_PARAMS:
		{
			if (code == 0)
			{
				mUIObject->runUpdateConfigView();
			}
			break;
		}
		case neuvition::NEUV_CMD_GET_DEVICE_INFO:
		{
			if (code == 0)
			{
				cout << "[NEUVITION]| " << cmd << " | Device info synced..." << std::endl;
				mUIObject->runRefreshInfoView();
			}
			break;
		}
		case neuvition::NEUV_CMD_GET_CAMERA_TYPE:
		{
			neuvition::NeuCameraType mCameratype;
			memset(&mCameratype, -1, sizeof(mCameratype));
			mCameratype = neuvition::get_camera_type();
			switch (mCameratype.cameramode)
			{
			case 0:
				bRtsp = false;
				break;
			case 1:
				bRtsp = true;
				break;
			}
			break;
		}
		default:
			break;
		}
	}

	void on_framedata(int code, int64_t microsec, const neuvition::NeuvUnits &data, const neuvition::nvid_t &frame_id)
	{
		if (data.size() == 0)
			return;
		std::cout << "on_framedata_size***********" << data.size() << std::endl;
		pcl::PointCloud<PointXYZRGBATI> cloud_;
		cloud_.reserve(data.size());
		cloud_.is_dense = false;
		for (neuvition::NeuvUnits::const_iterator iter = data.begin(); iter != data.end(); iter++)
		{
			const neuvition::NeuvUnit &np = (*iter);
			PointXYZRGBATI point;
			//PointXYZRGBATI
			point.x = np.x * 0.001;
			point.y = np.y * 0.001;
			point.z = np.z * 0.001;
			point.r = np.r;
			point.g = np.g;
			point.b = np.b;
			point.a = 255;
			point.intensity = np.intensity;
			point.timestamp = np.time_sec;
			//time_sec = val.time_sec;
			//time_usec = val.time_usec;
			uint32_t tofcolor = np.tof % mTofColorCycle;
			uint32_t tofclass = tofcolor / (mTofColorCycle / 6);
			uint32_t tofreman = tofcolor % (mTofColorCycle / 6);
			uint32_t cbase = coloredge[(tofclass + 0) % 6];
			uint32_t cnext = coloredge[(tofclass + 1) % 6];
			uint32_t ccand = cnext & cbase;
			UNUSED(ccand);
			uint32_t ccxor = cnext ^ cbase;
			//int shift = __builtin_ffs(ccxor) - 1;
			int shift = custom_ffs(ccxor) - 1;
			int xincr = (cnext > cbase) ? 1 : -1;
			uint32_t crender = cbase + xincr * ((int)(tofreman * (256.0 / (mTofColorCycle / 6))) << shift);
			point.r = (crender & 0xff0000) >> 16;
			point.g = (crender & 0x00ff00) >> 8;
			point.b = (crender & 0x0000ff) >> 0;
			cloud_.push_back(point);
		}
		size_t size = cloud_.size();
		if (size > 0)
		{
			{
				boost::mutex::scoped_lock lockit(cloudMutex);
				mNeuvitionViewerDemo->mCloud->reserve(size);
				pcl::copyPointCloud(cloud_, *(mNeuvitionViewerDemo->mCloud));
			}
		}
		if (cameraLidarEnabled) {		
			boost::mutex::scoped_lock lockit(cloudMutex);
			cloudFrame.assign(data.begin(), data.end());
			cameraLidarEnabled = false;
		}
		mUIObject->runUpdateCloudView();
	}

	void on_imudata(int code, int64_t microsec, const neuvition::NeuvUnits &data, const neuvition::ImuData &imu){}

	void on_mjpgdata(int code, int64_t microsec, cv::Mat mat)
	{
		if (mat.empty())
			return;
		mJpegMat = mat.clone();
		mNeuvitionViewerDemo->mRefreshCamImage = true;
		mat.release();
	}

	void on_rtspdata(int code, int64_t microsec, cv::Mat mat)
	{
		if (mat.empty())
			return;
		cv::Mat	rtspmat;
		cv::cvtColor(mat, rtspmat, cv::COLOR_RGBA2RGB);
		mJpegMat = rtspmat.clone();
		//mJpegMat = mat.clone();
		mNeuvitionViewerDemo->mRefreshCamImage = true;
		mat.release();
		rtspmat.release();
	}

	void on_pczdata(bool status){}

	void on_Ladar_Camera(neuvition::NeuvCameraLadarDatas *datas){}

    void on_lidar_info_status(neuvition::LidarInfoStatus *lidarInfoStatus)
    {
        printf("on_lidar_info_status=============>\n");
        printf("device_type = %s\n", lidarInfoStatus->device_type);
        printf("serial_number = %s\n", lidarInfoStatus->serial_number);
        printf("manufacturer = %s\n", lidarInfoStatus->manufacturer);
        printf("date_of_manufacture = %s\n", lidarInfoStatus->date_of_manufacture);
        printf("hardware_ver = %s\n", lidarInfoStatus->hardware_ver);
        printf("software_ver = %s\n", lidarInfoStatus->software_ver);
        printf("auth_code = %s\n", lidarInfoStatus->auth_code);
        printf("horizontal_fov = %d\n", lidarInfoStatus->horizontal_fov);
        printf("vertical_fov = %d\n", lidarInfoStatus->vertical_fov);
        printf("max_distance = %d(m)\n", lidarInfoStatus->max_distance);
        printf("accuracy = %d(mm)\n", lidarInfoStatus->accuracy);
        printf("wave_length = %d(nm)\n", lidarInfoStatus->wave_length);
        printf("curr_time = %d\n", lidarInfoStatus->curr_time);
        printf("power_on_time = %d\n", lidarInfoStatus->power_on_time);
        printf("laser_power = %d(%%)\n", lidarInfoStatus->laser_power);
        printf("fps = %d\n", lidarInfoStatus->fps);
        printf("laser_rate = %d(KHZ)\n", lidarInfoStatus->laser_rate);
        printf("cam_status = %d\n", lidarInfoStatus->cam_status);
        printf("lidar_status = %d\n", lidarInfoStatus->lidar_status);
        printf("lidar_temperature = %.2f(C)\n", lidarInfoStatus->lidar_temperature);
        printf("<==================on_lidar_info_status\n");
    }
};

NeuvitionViewerDemo::NeuvitionViewerDemo(QWidget *parent)
	: QMainWindow(parent),
	  ui(new Ui::NeuvitionViewerDemoClass)
{
	ui->setupUi(this);

	this->setWindowTitle("Neuvition Viewer");
	this->setMouseTracking(true);

	ui->qvtkWidget->setMouseTracking(true);

	ui->dockWidgetImage->setVisible(false);
	ui->dockWidgetImage->setFloating(true);

	QDesktopWidget *desktop = QApplication::desktop();
	int max_w = desktop->width();  //��Ļ�Ŀ���
	int max_h = desktop->height(); //��Ļ�ĸ߶�
	ui->centralwidget->setMaximumSize(max_w, max_h);

	// Setup the cloud pointer
	mCloud.reset(new PointCloudT);
	mCloudNeu.reset(new pcl::PointCloud<PointXYZRGBATI>);

	mTofColorCycle = 65000;
	mPointType = 1;

	mDeviceConnected = false;
	mRefreshCamImage = false;
	mNewVideo = false;
	mPCZStatus = false;
	mVideoThreadRunning = false;

	// The default color
	unsigned int red = 0;
	unsigned int green = 60;
	unsigned int blue = 90;

	// Fill the cloud with some points
	if (pcl::io::loadPCDFile("logo.pcd", *mCloud) == -1)
	{
		PCL_ERROR("Couldn't read file logo.pcd\n");
	}
	for (size_t i = 0; i < mCloud->size(); ++i)
	{
		mCloud->points[i].r = red;
		mCloud->points[i].g = green;
		mCloud->points[i].b = blue;
	}

	// Set up the QVTK window
	mViewer.reset(new pcl::visualization::PCLVisualizer("viewer", false));
	mViewer->setBackgroundColor(0, 0, 0);
	mViewer->initCameraParameters();
	mViewer->removeAllPointClouds();
	mViewer->addCoordinateSystem(1.0);

	/*mViewer->getRenderWindow()->DebugOff();
	mViewer->getRenderWindow()->GlobalWarningDisplayOff();*/
	ui->qvtkWidget->SetRenderWindow(mViewer->getRenderWindow());
	mViewer->setupInteractor(ui->qvtkWidget->GetInteractor(), ui->qvtkWidget->GetRenderWindow());
	ui->qvtkWidget->update();

	connect(ui->pushButtonConnect, SIGNAL(clicked()), this, SLOT(connect_button_pressed()));
	connect(ui->pushButtonDisconnect, SIGNAL(clicked()), this, SLOT(disconnect_button_pressed()));
	connect(ui->pushButtonStartScan, SIGNAL(clicked()), this, SLOT(start_scan_button_pressed()));
	connect(ui->pushButtonStopScan, SIGNAL(clicked()), this, SLOT(stop_scan_button_pressed()));
	connect(ui->pushButtonStartData, SIGNAL(clicked()), this, SLOT(start_data_button_pressed()));
	connect(ui->pushButtonStopData, SIGNAL(clicked()), this, SLOT(stop_data_button_pressed()));
	connect(ui->pushButtonRGBVideo, SIGNAL(clicked()), this, SLOT(rgbvideo_button_pressed()));
	connect(ui->lineEditIp, SIGNAL(textChanged(QString)), this, SLOT(ip_edit_text_changed()));
	connect(ui->checkBoxCamera, SIGNAL(stateChanged(int)), this, SLOT(camera_checkbox_changed(int)));
	connect(ui->lineEditLaserPower, SIGNAL(returnPressed()), this, SLOT(power_edit_changed()));
	connect(ui->comboBoxFreq, SIGNAL(currentIndexChanged(int)), this, SLOT(freq_index_changed()));
	connect(ui->comboBoxLaserRate, SIGNAL(currentIndexChanged(int)), this, SLOT(laser_rate_index_changed()));
	connect(ui->pushButtonCameraLidar, SIGNAL(clicked()), this, SLOT(camera_lidar_pressed()));

	mUIObject = new UIObject();
	connect(mUIObject, SIGNAL(updateButtons(bool, bool, bool, bool, bool, bool)), this, SLOT(update_buttons(bool, bool, bool, bool, bool, bool)));
	connect(mUIObject, SIGNAL(updateCloudView()), this, SLOT(update_cloud_view()));
	connect(mUIObject, SIGNAL(updateConfigView()), this, SLOT(refresh_config_view()));
	connect(mUIObject, SIGNAL(refreshInfoView()), this, SLOT(refresh_info_view()));

	ui->pushButtonConnect->setEnabled(false);
	ui->pushButtonDisconnect->setEnabled(false);
	ui->pushButtonStartScan->setEnabled(false);
	ui->pushButtonStopScan->setEnabled(false);
	ui->pushButtonStartData->setEnabled(false);
	ui->pushButtonStopData->setEnabled(false);

	mViewer->addPointCloud(mCloud, "neuvgram");
	mViewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, "neuvgram");
	mViewer->resetCamera();
	ui->qvtkWidget->update();
}

NeuvitionViewerDemo::~NeuvitionViewerDemo()
{
	neuvition::set_mjpg_curl(false);
	if (mDeviceConnected)
	{
		disconnect_button_pressed();
	}
	delete ui;
}

void NeuvitionViewerDemo::connect_button_pressed()
{
	printf("Connect button was pressed\n");
	QString hostIp = ui->lineEditIp->text();
	if (hostIp.isEmpty())
	{
		printf("Connect host ip is empty\n");
		return;
	}
	mHostIP = hostIp.toStdString();

	neuvition::set_flip_axis(false, true);
	neuvition::set_mjpg_curl(false);

	int ret = 0;
	printf("on_connect_click IP = %s\n", mHostIP);
	neuvition::INeuvEvent *phandler = new gEventHandler();
	ret = neuvition::setup_client(mHostIP.c_str(), mHostPort, phandler /*event-handler*/, false /*auto-reconnect*/);
}

void NeuvitionViewerDemo::disconnect_button_pressed()
{
	printf("Disconnect button was pressed\n");
	int ret = 0;
	ret = neuvition::teardown_client();
}

void NeuvitionViewerDemo::start_scan_button_pressed()
{
	printf("Start scan button was pressed\n");
	int ret = 0;
	ret = neuvition::start_scan();
}

void NeuvitionViewerDemo::stop_scan_button_pressed()
{
	printf("Stop scan button was pressed\n");
	int ret = 0;
	ret = neuvition::stop_scan();
}

void NeuvitionViewerDemo::start_data_button_pressed()
{
	printf("Start data button was pressed\n");
	int ret = 0;
	ret = neuvition::start_stream();
	usleep(1 * 1000);
	#ifdef _WINDOWS
		Sleep(5);
#else
		usleep(5000);
#endif

	neuvition::get_jason_camera();
}

void NeuvitionViewerDemo::stop_data_button_pressed()
{
	printf("Stop data button was pressed\n");
	int ret = 0;
	ret = neuvition::stop_stream();
}

void NeuvitionViewerDemo::rgbvideo_button_pressed()
{
	if (bRtsp == true && mDeviceConnected && isCamera == false)
	{
		boost::thread rtsp_start_thread(&start_rtsp);
		rtsp_start_thread.detach();
		std::cout << "show_rgb_video_dlg" << std::endl;
	}
	if (!ui->dockWidgetImage->isVisible())
	{
		if (mDeviceConnected && bRtsp == false)
		{
			int ret;
			ret = neuvition::set_camera_status(true);
			ret = neuvition::set_mjpg_curl(true);
		}
		ui->dockWidgetImage->setVisible(true);
		if (mDeviceConnected && !mVideoThreadRunning)
		{
			int jpeg_init = neuv_init_jpeg_download_run();
			UNUSED(jpeg_init);
			mVideoThreadRunning = true;
		}
	}
	else
	{
		//int ret;
		//ret = neuvition::set_camera_status(false);
		//ret = neuvition::set_mjpg_curl(false);
		ui->dockWidgetImage->setVisible(false);
	}
	isCamera = !isCamera;
}

void NeuvitionViewerDemo::ip_edit_text_changed()
{
	if (ui->lineEditIp->text().isEmpty())
	{
		ui->pushButtonConnect->setEnabled(false);
	}
	else
	{
		ui->pushButtonConnect->setEnabled(true);
	}
}

void NeuvitionViewerDemo::camera_checkbox_changed(int checked)
{
	//bool flag = ui->checkBoxCamera->isChecked();
	////printf("Camera: [%s]\n",flag?"true":"false");
	//if (!mRefreshCamCheckState)
	//{
	//	int ret = neuvition::set_camera_status(flag);
	//	ret = neuvition::set_mjpg_curl(flag);
	//	UNUSED(ret);
	//}
	//if (!mVideoThreadRunning && ui->dockWidgetImage->isVisible())
	//{
	//	int jpeg_init = neuv_init_jpeg_download_run();
	//	UNUSED(jpeg_init);
	//	mVideoThreadRunning = true;
	//}
	//mRefreshCamCheckState = false;
}
//
//void NeuvitionViewerDemo::camera_lidar_pressed() 
//{
//	cv::Mat cameraMatrix;
//	cv::Mat distCoeffs;
//	cv::Mat rtMatrix;
//	int row, col;
//	uint8_t bgr[3];
//	cv::Mat imageFrame;
//	pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloudView(new pcl::PointCloud<pcl::PointXYZRGBA>);
//	pcl::visualization::PCLVisualizer::Ptr p(new pcl::visualization::PCLVisualizer);
//	p->addCoordinateSystem();
//	p->initCameraParameters();
//	cameraLidarEnabled = true;
//	neuvition::getCameraLidarMatrix(cameraMatrix, distCoeffs, rtMatrix);
//	std::cout << " cameraMatrix= " << cameraMatrix << std::endl;
//	std::cout << " distCoeffs= " << distCoeffs << std::endl;
//	std::cout << " rtMatrix= " << rtMatrix << std::endl;
//	while (true) {
//		boost::this_thread::sleep(boost::get_system_time() + boost::posix_time::milliseconds(100));
//		if (cameraLidarEnabled)
//			continue;
//		break;
//	}
//	if (cloudFrame.size() <= 0) {
//		std::cout << " cloudFrame is empty." << std::endl;
//		return;
//	}
//	imageFrame = mJpegMat.clone();
//	if (imageFrame.empty()) {
//		std::cout << " imageFrame is empty." << std::endl;
//		return;
//	}
//	for (neuvition::NeuvUnits::const_iterator iter = cloudFrame.begin(); iter != cloudFrame.end(); iter++) {
//		const neuvition::NeuvUnit &np = (*iter);
//		pcl::PointXYZRGBA point;
//		neuvition::getCameraLidarCoordinate(np, cameraMatrix, distCoeffs, rtMatrix, imageFrame, bgr, row, col);
//		point.x = np.x / 1000.0;
//		point.y = np.y / 1000.0;
//		point.z = np.z / 1000.0;
//		point.b = bgr[0];
//		point.g = bgr[1];
//		point.r = bgr[2];
//		point.a = 255;
//		cloudView->push_back(point);
//	}
//	p->addPointCloud(cloudView, "cloudView");
//	p->spin();
//}

void NeuvitionViewerDemo::power_edit_changed()
{
	QString qpwm = ui->lineEditLaserPower->text();
	if (qpwm.toInt() >= 57 && qpwm.toInt() <= 65)
	{
		//// Warning
		mPowerValue = qpwm.toInt();
		int ret = neuvition::set_laser_power(mPowerValue);
		UNUSED(ret);
	}
	else if (qpwm.toInt() < 57)
	{
		mPowerValue = qpwm.toInt();
		int ret = neuvition::set_laser_power(mPowerValue);
		UNUSED(ret);
	}
	else if (qpwm.toInt() > 65)
	{
		// FORBID
		ui->lineEditLaserPower->setText(QString::number(mPowerValue));
	}
}

void NeuvitionViewerDemo::freq_index_changed()
{
	if (!mRefreshFreq)
	{
		int index = ui->comboBoxFreq->currentIndex();
		int fps = 0;
		switch (index)
		{
		case (0):
		{
			mFreqValue = 2;
			fps = 30;
			break;
		}
		case (1):
		{
			mFreqValue = 3;
			fps = 20;
			break;
		}
		case (2):
		{
			mFreqValue = 4;
			fps = 15;
			break;
		}
		case (3):
		{
			mFreqValue = 6;
			fps = 10;
			break;
		}
		case (4):
		{
			mFreqValue = 10;
			fps = 6;
			break;
		}
		case (5):
		{
			mFreqValue = 12;
			fps = 5;
			break;
		}
		case (6):
		{
			mFreqValue = 20;
			fps = 3;
			break;
		}
		case (7):
		{
			mFreqValue = 30;
			fps = 2;
			break;
		}
		case (8):
		{
			mFreqValue = 60;
			fps = 1;
			break;
		}
		}
		int ret = neuvition::set_frame_frequency(fps);
		UNUSED(ret);
	}
	mRefreshFreq = false;
}

void NeuvitionViewerDemo::laser_rate_index_changed()
{
	if (!mRefreshLaserRate)
	{
		mLaserRateIndex = ui->comboBoxLaserRate->currentIndex();
		int ret = neuvition::set_laser_interval(mLaserRateIndex);
		UNUSED(ret);
	}
	mRefreshLaserRate = false;
}

void NeuvitionViewerDemo::update_buttons(bool enabled0, bool enabled1, bool enabled2, bool enabled3, bool enabled4, bool enabled5)
{
	mDeviceConnected = !enabled0;
	ui->pushButtonConnect->setEnabled(enabled0);
	ui->pushButtonDisconnect->setEnabled(enabled1);
	ui->pushButtonStartScan->setEnabled(enabled2);
	ui->pushButtonStopScan->setEnabled(enabled3);
	ui->pushButtonStartData->setEnabled(enabled4);
	ui->pushButtonStopData->setEnabled(enabled5);
	if (mDeviceConnected)
	{
		ui->checkBoxCamera->setEnabled(true);
	}
	else
	{
		neuvition::set_mjpg_curl(false);
		ui->checkBoxCamera->setChecked(false);
		ui->checkBoxCamera->setEnabled(false);
	}
}

void NeuvitionViewerDemo::update_cloud_view()
{
	if (mCloud->size() == 0)
		return;
	PointCloudT::Ptr cloud_(new PointCloudT);
	{
		boost::mutex::scoped_lock lockit(cloudMutex);
		//pcl::copyPointCloud(*mCloud, *cloud_);
		cloud_->swap(*mCloud);
	}
	mViewer->updatePointCloud(cloud_, "neuvgram");
	ui->qvtkWidget->update();
}

void NeuvitionViewerDemo::refresh_config_view()
{
	int deviceType = neuvition::get_device_type();
	int interval = neuvition::get_laser_interval();
	int frequency = neuvition::get_frame_frequency();
	bool cameraOn = neuvition::is_camera_on();
	int scanMode = neuvition::get_scan_mode();
	mRefreshFreq = false;
	mRefreshLaserRate = false;
	mRefreshCamCheckState = true;
	mPowerValue = neuvition::get_laser_power();
	QString xpwm = QString::number(mPowerValue, 10);
	ui->lineEditLaserPower->setText(xpwm);
	if (interval == ui->comboBoxLaserRate->currentIndex())
	{
		mRefreshLaserRate = false;
	}
	else
	{
		mRefreshLaserRate = true;
	}
	ui->comboBoxLaserRate->setCurrentIndex(interval);
	int frameFreqIndex = 0;
	switch (frequency)
	{
	case (30):
	{
		mFreqValue = 2;
		frameFreqIndex = 0;
		break;
	}
	case (20):
	{
		mFreqValue = 3;
		frameFreqIndex = 1;
		break;
	}
	case (15):
	{
		mFreqValue = 4;
		frameFreqIndex = 2;
		break;
	}
	case (10):
	{
		mFreqValue = 6;
		frameFreqIndex = 3;
		break;
	}
	case (6):
	{
		mFreqValue = 10;
		frameFreqIndex = 4;
		break;
	}
	case (5):
	{
		mFreqValue = 12;
		frameFreqIndex = 5;
		break;
	}
	case (3):
	{
		mFreqValue = 20;
		frameFreqIndex = 6;
		break;
	}
	case (2):
	{
		mFreqValue = 30;
		frameFreqIndex = 7;
		break;
	}
	case (1):
	{
		mFreqValue = 60;
		frameFreqIndex = 8;
		break;
	}
	}
	if (frameFreqIndex == ui->comboBoxFreq->currentIndex())
	{
		mRefreshFreq = false;
	}
	else
	{
		mRefreshFreq = true;
	}
	ui->comboBoxFreq->setCurrentIndex(frameFreqIndex);

	if (cameraOn == ui->checkBoxCamera->isChecked())
	{
		mRefreshCamCheckState = false;
	}
	else
	{
		mRefreshCamCheckState = true;
	}
	if (cameraOn)
	{
		ui->checkBoxCamera->setChecked(true);
		int ret = neuvition::set_mjpg_curl(true);
		UNUSED(ret);
	}
	else
	{
		ui->checkBoxCamera->setChecked(false);
	}
}

void NeuvitionViewerDemo::refresh_info_view()
{
	int deviceType = neuvition::get_device_type();
}

QImage Mat2QImage(cv::Mat cvImg)
{
	QImage qImg;
	if (cvImg.channels() == 3) //3 channels color image
	{
		cv::cvtColor(cvImg, cvImg, CV_BGR2RGB);
		qImg = QImage((const unsigned char *)(cvImg.data),
					  cvImg.cols, cvImg.rows,
					  cvImg.cols * cvImg.channels(),
					  QImage::Format_RGB888);
	}
	else if (cvImg.channels() == 1) //grayscale image
	{
		qImg = QImage((const unsigned char *)(cvImg.data),
					  cvImg.cols, cvImg.rows,
					  cvImg.cols * cvImg.channels(),
					  QImage::Format_Indexed8);
	}
	else
	{
		qImg = QImage((const unsigned char *)(cvImg.data),
					  cvImg.cols, cvImg.rows,
					  cvImg.cols * cvImg.channels(),
					  QImage::Format_RGB888);
	}
	return qImg;
}

NeuGLWidget::NeuGLWidget(QWidget *parent) : QOpenGLWidget(parent) {}

NeuGLWidget::~NeuGLWidget() {}

void NeuGLWidget::paintEvent(QPaintEvent *e)
{
	QPainter painter(this);
	if (mNeuvitionViewerDemo == NULL)
	{
		return;
	}
	if (!mNeuvitionViewerDemo->mImageMat.empty())
	{
		cv::Mat mat = mNeuvitionViewerDemo->mImageMat.clone();
		//mNeuvitionViewerDemo->mImageMat.copyTo(mat);
		QImage img = Mat2QImage(mat);
		int w = this->width();
		int h = this->height();
		QImage result = img.scaled(w, h, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
		painter.drawImage(QPoint(0, 0), result);
	}
	else
	{
		return;
	}
}
