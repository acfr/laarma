#include "NeuvitionViewerDemo.h"
#include <QtWidgets/QApplication>

NeuvitionViewerDemo *mNeuvitionViewerDemo;
int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	mNeuvitionViewerDemo = new NeuvitionViewerDemo();
	mNeuvitionViewerDemo->show();
	return a.exec();
}


