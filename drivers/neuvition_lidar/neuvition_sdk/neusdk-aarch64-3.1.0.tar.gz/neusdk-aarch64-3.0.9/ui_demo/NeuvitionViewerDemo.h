#pragma once
#ifdef _WINDOWS
#include <afx.h>
#endif
#include <QtWidgets/QMainWindow>
#include <neuv_defs.hpp>

#include <iostream>

// Qt
#include <QMainWindow>
#include <QWidget>
#include <QFileDialog>
#include <QString>
#include <QDesktopWidget>
#include <QTextStream>
#include <QFile>
#include <QThread>
#include <QMessageBox>
#include <QDateTime>
#include <QSignalMapper>
#include <QOpenGLWidget>
#include <QPainter>
#include <QTimer>
#include <QPalette>
#include <QColor>

// Point Cloud Library
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/io/pcd_io.h>

// Visualization Toolkit (VTK)
#include <vtkRenderWindow.h>

// Opencv
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>  
#include <opencv2/highgui/highgui.hpp>  
#include <opencv2/imgproc/imgproc.hpp> 
#include <opencv2/videoio.hpp>

typedef pcl::PointXYZRGBA PointT;
typedef pcl::PointCloud<PointT> PointCloudT;

namespace Ui
{
	class NeuvitionViewerDemoClass;
}

class UIObject : public QObject
{
	Q_OBJECT
public:
	UIObject();
	~UIObject();
Q_SIGNALS:
	void updateButtons(bool, bool, bool, bool, bool, bool);
	void updateCloudView();
	void updateConfigView();
	void refreshInfoView();
public:
	void runUpdateButton(bool enabled0, bool enabled1, bool enabled2, bool enabled3, bool enabled4, bool enabled5);
	void runUpdateCloudView();
	void runUpdateConfigView();
	void runRefreshInfoView();
};

// Define PointType 
struct PointXYZRGBATI              //��������ͽṹ
{
	PCL_ADD_POINT4D; // This adds the members x,y,z which can also be accessed using the point (which is float[4])
	PCL_ADD_UNION_RGB;
	uint32_t timestamp;
	uint32_t intensity;
	EIGEN_MAKE_ALIGNED_OPERATOR_NEW// ȷ��new�������������
}EIGEN_ALIGN16;// ǿ��SSE����


POINT_CLOUD_REGISTER_POINT_STRUCT(PointXYZRGBATI,// ע������ͺ�
(float, x, x)
(float, y, y)
(float, z, z)
(uint32_t, rgba, rgba)
(uint32_t, timestamp, timestamp)
(uint32_t, intensity, intensity)
)

class NeuGLWidget : public QOpenGLWidget
{
	Q_OBJECT
public:
	NeuGLWidget(QWidget *parent);
	~NeuGLWidget();

	//��дpaintEvent����
	void paintEvent(QPaintEvent *e);
};

class NeuvitionViewerDemo : public QMainWindow
{
	Q_OBJECT

public:
	explicit NeuvitionViewerDemo(QWidget *parent = Q_NULLPTR);
	~NeuvitionViewerDemo();
	inline Ui::NeuvitionViewerDemoClass *getUiPtr() { return ui; }
public Q_SLOTS:
	void connect_button_pressed();
	void disconnect_button_pressed();
	void start_scan_button_pressed();
	void stop_scan_button_pressed();
	void start_data_button_pressed();
	void stop_data_button_pressed();
	void rgbvideo_button_pressed();
	void camera_checkbox_changed(int);
	void ip_edit_text_changed();
	void power_edit_changed();
	void freq_index_changed();
	void laser_rate_index_changed();
	//void camera_lidar_pressed();

	void update_buttons(bool, bool, bool, bool, bool, bool);
	void update_cloud_view();
	void refresh_config_view();
	void refresh_info_view();

Q_SIGNALS:
	void UpdateCamera_signal(cv::Mat mat);

public:
	boost::shared_ptr<pcl::visualization::PCLVisualizer> mViewer;
	PointCloudT::Ptr mCloud;
	pcl::PointCloud<PointXYZRGBATI>::Ptr mCloudNeu;

	neuvition::LaserIncidentAngles mAngles;
	neuvition::LaserIncidentAngles mLaserangles;

	int mFreqValue = 0;
	int mLaserRateIndex = 0;
	int mPowerValue = 0;
	int mGridSizeIndex = 0;

	bool mRefreshFreq;
	bool mRefreshLaserRate;
	bool mRefreshCamCheckState;
	bool mRefreshCamImage;
	bool mVideoThreadRunning;
	bool mNewVideo;
	bool mPCZStatus;
	bool isVideoPlay = false;
	int mPointType = 0;
	int imageWidth;
	int imageHight;
	cv::Mat mImageMat;

	bool mDeviceConnected;

	bool isCamera = false;
private:
	Ui::NeuvitionViewerDemoClass *ui;
};
