/********************************************************************************
** Form generated from reading UI file 'NeuvitionViewerDemo.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEUVITIONVIEWERDEMO_H
#define UI_NEUVITIONVIEWERDEMO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDockWidget>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "NeuvitionViewerDemo.h"
#include "QVTKWidget.h"

QT_BEGIN_NAMESPACE

class Ui_NeuvitionViewerDemoClass
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QVTKWidget *qvtkWidget;
    QTabWidget *tabWidget;
    QWidget *tab;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QLineEdit *lineEditIp;
    QWidget *horizontalLayoutWidget_3;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *pushButtonConnect;
    QPushButton *pushButtonDisconnect;
    QWidget *horizontalLayoutWidget_4;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *pushButtonStartScan;
    QPushButton *pushButtonStopScan;
    QWidget *horizontalLayoutWidget_5;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *pushButtonStartData;
    QPushButton *pushButtonStopData;
    QCheckBox *checkBoxCamera;
    QWidget *horizontalLayoutWidget_6;
    QHBoxLayout *horizontalLayout_7;
    QPushButton *pushButtonRGBVideo;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_2;
    QLineEdit *lineEditLaserPower;
    QWidget *horizontalLayoutWidget_7;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_3;
    QComboBox *comboBoxFreq;
    QWidget *horizontalLayoutWidget_8;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_4;
    QComboBox *comboBoxLaserRate;
    QPushButton *pushButtonCameraLidar;
    QDockWidget *dockWidgetImage;
    QWidget *dockWidgetContents;
    QVBoxLayout *verticalLayout_2;
    NeuGLWidget *openGLWidget;

    void setupUi(QMainWindow *NeuvitionViewerDemoClass)
    {
        if (NeuvitionViewerDemoClass->objectName().isEmpty())
            NeuvitionViewerDemoClass->setObjectName(QString::fromUtf8("NeuvitionViewerDemoClass"));
        NeuvitionViewerDemoClass->resize(909, 583);
        centralwidget = new QWidget(NeuvitionViewerDemoClass);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        qvtkWidget = new QVTKWidget(centralwidget);
        qvtkWidget->setObjectName(QString::fromUtf8("qvtkWidget"));

        horizontalLayout->addWidget(qvtkWidget);

        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setMaximumSize(QSize(200, 16777215));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        horizontalLayoutWidget_2 = new QWidget(tab);
        horizontalLayoutWidget_2->setObjectName(QString::fromUtf8("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(0, 0, 191, 41));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(7, 0, 7, 0);
        label = new QLabel(horizontalLayoutWidget_2);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout_2->addWidget(label);

        lineEditIp = new QLineEdit(horizontalLayoutWidget_2);
        lineEditIp->setObjectName(QString::fromUtf8("lineEditIp"));

        horizontalLayout_2->addWidget(lineEditIp);

        horizontalLayoutWidget_3 = new QWidget(tab);
        horizontalLayoutWidget_3->setObjectName(QString::fromUtf8("horizontalLayoutWidget_3"));
        horizontalLayoutWidget_3->setGeometry(QRect(0, 40, 205, 41));
        horizontalLayout_3 = new QHBoxLayout(horizontalLayoutWidget_3);
        horizontalLayout_3->setSpacing(5);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(7, 0, 7, 0);
        pushButtonConnect = new QPushButton(horizontalLayoutWidget_3);
        pushButtonConnect->setObjectName(QString::fromUtf8("pushButtonConnect"));

        horizontalLayout_3->addWidget(pushButtonConnect);

        pushButtonDisconnect = new QPushButton(horizontalLayoutWidget_3);
        pushButtonDisconnect->setObjectName(QString::fromUtf8("pushButtonDisconnect"));

        horizontalLayout_3->addWidget(pushButtonDisconnect);

        horizontalLayoutWidget_4 = new QWidget(tab);
        horizontalLayoutWidget_4->setObjectName(QString::fromUtf8("horizontalLayoutWidget_4"));
        horizontalLayoutWidget_4->setGeometry(QRect(0, 80, 205, 41));
        horizontalLayout_5 = new QHBoxLayout(horizontalLayoutWidget_4);
        horizontalLayout_5->setSpacing(5);
        horizontalLayout_5->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(7, 0, 7, 0);
        pushButtonStartScan = new QPushButton(horizontalLayoutWidget_4);
        pushButtonStartScan->setObjectName(QString::fromUtf8("pushButtonStartScan"));

        horizontalLayout_5->addWidget(pushButtonStartScan);

        pushButtonStopScan = new QPushButton(horizontalLayoutWidget_4);
        pushButtonStopScan->setObjectName(QString::fromUtf8("pushButtonStopScan"));

        horizontalLayout_5->addWidget(pushButtonStopScan);

        horizontalLayoutWidget_5 = new QWidget(tab);
        horizontalLayoutWidget_5->setObjectName(QString::fromUtf8("horizontalLayoutWidget_5"));
        horizontalLayoutWidget_5->setGeometry(QRect(0, 120, 205, 41));
        horizontalLayout_6 = new QHBoxLayout(horizontalLayoutWidget_5);
        horizontalLayout_6->setSpacing(5);
        horizontalLayout_6->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(7, 0, 7, 0);
        pushButtonStartData = new QPushButton(horizontalLayoutWidget_5);
        pushButtonStartData->setObjectName(QString::fromUtf8("pushButtonStartData"));

        horizontalLayout_6->addWidget(pushButtonStartData);

        pushButtonStopData = new QPushButton(horizontalLayoutWidget_5);
        pushButtonStopData->setObjectName(QString::fromUtf8("pushButtonStopData"));

        horizontalLayout_6->addWidget(pushButtonStopData);

        checkBoxCamera = new QCheckBox(tab);
        checkBoxCamera->setObjectName(QString::fromUtf8("checkBoxCamera"));
        checkBoxCamera->setGeometry(QRect(10, 210, 81, 20));
        horizontalLayoutWidget_6 = new QWidget(tab);
        horizontalLayoutWidget_6->setObjectName(QString::fromUtf8("horizontalLayoutWidget_6"));
        horizontalLayoutWidget_6->setGeometry(QRect(0, 160, 191, 41));
        horizontalLayout_7 = new QHBoxLayout(horizontalLayoutWidget_6);
        horizontalLayout_7->setSpacing(5);
        horizontalLayout_7->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(7, 0, 7, 0);
        pushButtonRGBVideo = new QPushButton(horizontalLayoutWidget_6);
        pushButtonRGBVideo->setObjectName(QString::fromUtf8("pushButtonRGBVideo"));

        horizontalLayout_7->addWidget(pushButtonRGBVideo);

        horizontalLayoutWidget = new QWidget(tab);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(0, 240, 191, 41));
        horizontalLayout_4 = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(horizontalLayoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_4->addWidget(label_2);

        lineEditLaserPower = new QLineEdit(horizontalLayoutWidget);
        lineEditLaserPower->setObjectName(QString::fromUtf8("lineEditLaserPower"));

        horizontalLayout_4->addWidget(lineEditLaserPower);

        horizontalLayoutWidget_7 = new QWidget(tab);
        horizontalLayoutWidget_7->setObjectName(QString::fromUtf8("horizontalLayoutWidget_7"));
        horizontalLayoutWidget_7->setGeometry(QRect(0, 280, 191, 41));
        horizontalLayout_8 = new QHBoxLayout(horizontalLayoutWidget_7);
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalLayout_8->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(horizontalLayoutWidget_7);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_8->addWidget(label_3);

        comboBoxFreq = new QComboBox(horizontalLayoutWidget_7);
        comboBoxFreq->addItem(QString());
        comboBoxFreq->addItem(QString());
        comboBoxFreq->addItem(QString());
        comboBoxFreq->addItem(QString());
        comboBoxFreq->addItem(QString());
        comboBoxFreq->addItem(QString());
        comboBoxFreq->addItem(QString());
        comboBoxFreq->addItem(QString());
        comboBoxFreq->addItem(QString());
        comboBoxFreq->setObjectName(QString::fromUtf8("comboBoxFreq"));

        horizontalLayout_8->addWidget(comboBoxFreq);

        horizontalLayoutWidget_8 = new QWidget(tab);
        horizontalLayoutWidget_8->setObjectName(QString::fromUtf8("horizontalLayoutWidget_8"));
        horizontalLayoutWidget_8->setGeometry(QRect(0, 320, 191, 41));
        horizontalLayout_9 = new QHBoxLayout(horizontalLayoutWidget_8);
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        horizontalLayout_9->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(horizontalLayoutWidget_8);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_9->addWidget(label_4);

        comboBoxLaserRate = new QComboBox(horizontalLayoutWidget_8);
        comboBoxLaserRate->addItem(QString());
        comboBoxLaserRate->addItem(QString());
        comboBoxLaserRate->addItem(QString());
        comboBoxLaserRate->addItem(QString());
        comboBoxLaserRate->addItem(QString());
        comboBoxLaserRate->addItem(QString());
        comboBoxLaserRate->addItem(QString());
        comboBoxLaserRate->setObjectName(QString::fromUtf8("comboBoxLaserRate"));

        horizontalLayout_9->addWidget(comboBoxLaserRate);

        pushButtonCameraLidar = new QPushButton(tab);
        pushButtonCameraLidar->setObjectName(QString::fromUtf8("pushButtonCameraLidar"));
        pushButtonCameraLidar->setGeometry(QRect(80, 210, 101, 23));
        tabWidget->addTab(tab, QString());

        horizontalLayout->addWidget(tabWidget);


        verticalLayout->addLayout(horizontalLayout);

        NeuvitionViewerDemoClass->setCentralWidget(centralwidget);
        dockWidgetImage = new QDockWidget(NeuvitionViewerDemoClass);
        dockWidgetImage->setObjectName(QString::fromUtf8("dockWidgetImage"));
        dockWidgetImage->setMinimumSize(QSize(400, 225));
        dockWidgetImage->setFloating(false);
        dockWidgetContents = new QWidget();
        dockWidgetContents->setObjectName(QString::fromUtf8("dockWidgetContents"));
        verticalLayout_2 = new QVBoxLayout(dockWidgetContents);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        openGLWidget = new NeuGLWidget(dockWidgetContents);
        openGLWidget->setObjectName(QString::fromUtf8("openGLWidget"));

        verticalLayout_2->addWidget(openGLWidget);

        dockWidgetImage->setWidget(dockWidgetContents);
        NeuvitionViewerDemoClass->addDockWidget(static_cast<Qt::DockWidgetArea>(1), dockWidgetImage);

        retranslateUi(NeuvitionViewerDemoClass);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(NeuvitionViewerDemoClass);
    } // setupUi

    void retranslateUi(QMainWindow *NeuvitionViewerDemoClass)
    {
        NeuvitionViewerDemoClass->setWindowTitle(QApplication::translate("NeuvitionViewerDemoClass", "NeuvitionViewerDemo", nullptr));
        label->setText(QApplication::translate("NeuvitionViewerDemoClass", "IP Address", nullptr));
        pushButtonConnect->setText(QApplication::translate("NeuvitionViewerDemoClass", "Connect", nullptr));
        pushButtonDisconnect->setText(QApplication::translate("NeuvitionViewerDemoClass", "Disconnect", nullptr));
        pushButtonStartScan->setText(QApplication::translate("NeuvitionViewerDemoClass", "Start Scan", nullptr));
        pushButtonStopScan->setText(QApplication::translate("NeuvitionViewerDemoClass", "Stop Scan", nullptr));
        pushButtonStartData->setText(QApplication::translate("NeuvitionViewerDemoClass", "Start Data", nullptr));
        pushButtonStopData->setText(QApplication::translate("NeuvitionViewerDemoClass", "Stop Data", nullptr));
        checkBoxCamera->setText(QApplication::translate("NeuvitionViewerDemoClass", "Camera", nullptr));
        pushButtonRGBVideo->setText(QApplication::translate("NeuvitionViewerDemoClass", "RGB Video", nullptr));
        label_2->setText(QApplication::translate("NeuvitionViewerDemoClass", "Power(%)", nullptr));
        label_3->setText(QApplication::translate("NeuvitionViewerDemoClass", "Frame/S", nullptr));
        comboBoxFreq->setItemText(0, QApplication::translate("NeuvitionViewerDemoClass", "30", nullptr));
        comboBoxFreq->setItemText(1, QApplication::translate("NeuvitionViewerDemoClass", "20", nullptr));
        comboBoxFreq->setItemText(2, QApplication::translate("NeuvitionViewerDemoClass", "15", nullptr));
        comboBoxFreq->setItemText(3, QApplication::translate("NeuvitionViewerDemoClass", "10", nullptr));
        comboBoxFreq->setItemText(4, QApplication::translate("NeuvitionViewerDemoClass", "6", nullptr));
        comboBoxFreq->setItemText(5, QApplication::translate("NeuvitionViewerDemoClass", "5", nullptr));
        comboBoxFreq->setItemText(6, QApplication::translate("NeuvitionViewerDemoClass", "3", nullptr));
        comboBoxFreq->setItemText(7, QApplication::translate("NeuvitionViewerDemoClass", "2", nullptr));
        comboBoxFreq->setItemText(8, QApplication::translate("NeuvitionViewerDemoClass", "1", nullptr));

        label_4->setText(QApplication::translate("NeuvitionViewerDemoClass", "Laser Rate", nullptr));
        comboBoxLaserRate->setItemText(0, QApplication::translate("NeuvitionViewerDemoClass", "200KHz", nullptr));
        comboBoxLaserRate->setItemText(1, QApplication::translate("NeuvitionViewerDemoClass", "300KHz", nullptr));
        comboBoxLaserRate->setItemText(2, QApplication::translate("NeuvitionViewerDemoClass", "400KHz", nullptr));
        comboBoxLaserRate->setItemText(3, QApplication::translate("NeuvitionViewerDemoClass", "500KHz", nullptr));
        comboBoxLaserRate->setItemText(4, QApplication::translate("NeuvitionViewerDemoClass", "750KHz", nullptr));
        comboBoxLaserRate->setItemText(5, QApplication::translate("NeuvitionViewerDemoClass", "1MHz", nullptr));
        comboBoxLaserRate->setItemText(6, QApplication::translate("NeuvitionViewerDemoClass", "1.5MHz", nullptr));

        pushButtonCameraLidar->setText(QApplication::translate("NeuvitionViewerDemoClass", "cameraLidar", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("NeuvitionViewerDemoClass", "Main", nullptr));
        dockWidgetImage->setWindowTitle(QApplication::translate("NeuvitionViewerDemoClass", "RGB Video", nullptr));
    } // retranslateUi

};

namespace Ui {
    class NeuvitionViewerDemoClass: public Ui_NeuvitionViewerDemoClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEUVITIONVIEWERDEMO_H
