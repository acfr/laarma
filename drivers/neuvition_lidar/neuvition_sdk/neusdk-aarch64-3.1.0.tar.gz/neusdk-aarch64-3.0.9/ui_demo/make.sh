#!/bin/bash
mkdir build
cp logo.pcd build/
cd build
cmake ..
make -j4
./neuviewerdemo