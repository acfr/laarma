/* neuv_defs.hpp */
/*
 * Software License Agreement (BSD License)
 *
 *  Neuvition SDK Library - www.neuvition.com
 *  Copyright (c) 2016-2019, Neuvition, Inc.
 *
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of the copyright holder(s) nor the names of its
 *     contributors may be used to endorse or promote products derived 
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS  
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 * 
 */
#ifndef __NEUVDEFS_H__
#define __NEUVDEFS_H__

#ifdef _WINDOWS
#define _DLL_EXPORT
#else
#define _LINUX
#endif
#ifdef _LINUX
#define DECLSPEC_EXPORT  
#define CALLBACK __attribute__((stdcall))
#endif

#ifdef _DLL_EXPORT
#define CALLBACK __stdcall
#ifdef  NEUVWINSDK_EXPORTS
#define DECLSPEC_EXPORT _declspec(dllexport)
#else
#define DECLSPEC_EXPORT _declspec(dllimport)
#endif 
#endif

//#define __DEBUG

//#undef __DEBUG
//#define P1M1905TDC


#include <vector>
#include <cstdlib>
#include <cstdint>


#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

using namespace std;

namespace neuvition {

	#define MAX_LASERS   3
	#define TOF_DIM      3
	#define TOF_WIDTH 1800
	#define TOF_HEIGHT 720
	#define TOF_WIDTH_P 4096
	#define TOF_HEIGHT_P 1800
	#define TOF_WIDTH_S2 240
	#define TOF_HEIGHT_S2 160
	#define QP(n) (1.0f/(1<<n))
	#ifdef _DLL_EXPORT
	#ifdef __cplusplus
	extern "C" {
	#endif 
	#endif
	

	typedef uint32_t nvid_t;
	typedef struct NEUV_UNIT { 
		int x; 
		int y; 
		int z; 
		uint8_t r; 
		uint8_t g; 
		uint8_t b; 
		uint8_t lid; 
		uint8_t apd_id; 
		uint16_t row; // line
		uint16_t col; // pixel
		uint32_t tof; 
		#ifdef P1M1905TDC
		uint32_t tof1; 
		uint32_t tof2;
		uint32_t tof3;  
		#endif
		uint8_t intensity; 
		// uint32_t timestamp;
		uint32_t time_sec;
		uint32_t time_usec;
		uint8_t level; 
		uint8_t tofts; 
		uint8_t intensityts; 

		NEUV_UNIT& operator = (const NEUV_UNIT& val)
		{
			x = val.x; 
			y = val.y; 
			z = val.z; 
			r = val.r; 
			g = val.g; 
			b = val.b; 
			lid = val.lid; 
			apd_id = val.apd_id; 
			row= val.row; // line
			col = val.col; // pixel
			tof = val.tof; 
			intensity = val.intensity; 
			// timestamp = val.timestamp;
			time_sec = val.time_sec;
			time_usec = val.time_usec;
			level = val.level; 
			tofts = val.tofts; 
			intensityts = val.intensityts; 
			
			return *this;
		}
	} NeuvUnit;

	typedef struct NEUV_POINT { 
		int x; 
		int y; 
		int z; 
		uint8_t r; 
		uint8_t g; 
		uint8_t b; 
		uint32_t tof; 
	} NeuvPoint; 
	



        struct NEUV_POINT_FRANK 
        {
          	int x; 
			int y; 
			int z; 
			uint8_t r; 
			uint8_t g; 
			uint8_t b; 
			uint32_t col;
			uint32_t tof;    
			uint8_t  dele_lv;
			uint8_t  dele_lv_2;
			uint32_t label;
			uint32_t intensity;
        }; 









	typedef struct TOF_DATA { 
		uint16_t line_id; 
		uint16_t pixel_id; 
		uint32_t tof_ns; 
		uint8_t laser_id; 
		uint8_t apd_id; 
		uint8_t r; 
		uint8_t g; 
		uint8_t b; 
		uint8_t intensity; 
		uint64_t timestamp; 
		uint32_t u_timestamp; //MAKE JASON
	} TofPoint;

	typedef struct IMU_DATA { 
		int32_t sec; 
		int32_t usec; 
		int32_t roll; 
		int32_t yaw; 
		int32_t pitch; 
		int16_t quat_i; 
		int16_t quat_j; 
		int16_t quat_k; 
		int16_t quat_r; 
		int16_t gro_x;
		int16_t gro_y;
		int16_t gro_z;
		int16_t line_accx;
		int16_t line_accy;
		int16_t line_accz;
	} ImuData;

	typedef struct GPRMC { 
		uint8_t status; 
		double utc; 
		char lat; 
		char lon; 
		double latitude; 
		double longitude; 
		double speed; 
		double course; 
		uint32_t ddmmyy; 
		double variation; 
		char vardirection; 
		char checksum; 
	} NeuGPRMC;

	typedef struct NEU_POSCOR { 
		short ratio_x; 
		short ratio_y; 
		short xmove; 
		short ymove; 
		short xcoeff1;  
		short xcoeff2; 
		short ycoeff1; 
		short averz; 
		short zcoeff0; 
	} NeuPosCor;

	typedef struct NEUV_WIREDATA { 
		uint8_t id;
		int pull_value; 
		int wire_height;
		int width;
		int length;
		int avg_z;
		int avg_x;
	} NeuvWireData;

	typedef struct NEUV_CT {
		uint8_t detecting; 
		uint8_t has_car;
		uint8_t detected; 
		uint8_t is_open; 
		uint8_t is_alarm; 
		uint8_t is_saved;
		uint32_t width; 
		uint32_t height; 
		uint32_t length;
	} NeuvCt;

	typedef struct LASER_STATUS{
		uint8_t state; 
		float temperature; 
		uint16_t pulserate; 
		uint16_t powervoltage; 
		uint16_t firstcurrent; 
		uint16_t secondcurrent; 
		float pulsewidth; 
		uint16_t laserpower; 
		float boardtemp; 
		float probe1temp; 
		float probe2temp; 
		float fpgatemp; 
		uint8_t evk1status; 
		uint8_t evk2status; 
		uint8_t spistatus; 
		uint8_t imustatus;
		uint32_t launchtimes;
		uint32_t lidartime_sec;
		uint32_t lidartime_usec;
	} NeuvLaserStatus;

typedef struct camera_point_pos 
{
    int x;
    int y;
    int pixel_id;
    int line_id;
    uint8_t r; 
	uint8_t g; 
	uint8_t b; 
	int ladarx;
	int ladary;
	int ladarz;

}CAMERA_POINT_POS;

typedef struct LIDAR_INFO_STATUS
{
	char device_type[32];
	char serial_number[32];
	char manufacturer[32];
	char date_of_manufacture[32];
	char hardware_ver[32];
	char software_ver[32];
	char auth_code[32];
	uint8_t horizontal_fov;
	uint8_t vertical_fov;
	uint32_t max_distance;
	uint16_t accuracy;
	uint16_t wave_length;
	uint32_t curr_time;
	uint32_t power_on_time;
	uint16_t laser_power;
	uint16_t fps;
	uint16_t laser_rate;
	uint8_t cam_status;
	uint8_t lidar_status;
	float lidar_temperature;
	uint8_t s2_ocles_freq;              //s2_ocllus2_repeat_frequency
	uint16_t polygon_moto_speed;		//polygon mote speeds
	uint8_t reserved[18];
} LidarInfoStatus;

   typedef struct _NEUCAMERATYPE { int typeenum; int cameramode; char strfirmware[50]; char strmanufature[40]; }NeuCameraType;
   //typedef enum { AXIS_NO_INIT = 0, AXIS_NO_EXIST = 1, AXIS_BNO080 = 2, AXIS_ICM20608 = 3, AXIS_SENSOR_ERROR = 100 }axis_sensor_type;
   typedef struct { int typenum; char version[30]; char pn[30]; char bn[30]; }AxisSensorInfo_t;
   typedef struct { uint16_t max_frame; uint16_t trans_count; uint8_t reserved[48]; }LidarExpandInfo;
   typedef struct { uint32_t exposure_time;uint16_t snr[3];uint8_t repeatFreq; uint8_t reserved[49];}Ocellus_param_t;
	typedef std::vector<NeuvUnit> NeuvUnits;
    typedef std::vector<std::vector<NeuvUnit> > NeuvUnits_2D;

	typedef std::vector<NeuvPoint> NeuvPoints;
	typedef std::vector<double> LaserIncidentAngles;
	typedef std::vector<NeuvWireData> NeuvWireDatas;
	typedef std::vector<CAMERA_POINT_POS> NeuvCameraLadarDatas;

	enum neuv_connect_type { ONLY_TCP, TCP_AND_MULTICAST, ONLY_MULTICAST};
	enum neuv_device_type { TITAN_M1,      TITAN_M1_PRO,  TITAN_M1_PLUS,  TITAN_M1_R,       TITAN_S1, 
							TITAN_M1_A,    TITAN_M1_SL,   TITAN_M2,       TITAN_M1_M,       TITAN_M1_PRO_SL, 
							TITAN_M1_R_SL, TITAN_M1_120,  TITAN_S1_PLUS,  TITAN_S1_PLUS_SL, TITAN_P1,
							TITAN_S2,      TITAN_M1_A_SL, TITAN_P1_SL,TITAN_S2_70,TITAN_S2_120, TITAN_M1_R3X3, TITAN_P1_ML905,TITAN_S2_45,TITAN_P1_SL1550,};
	enum neuv_cmd_code {
		NEUV_CMD_START_SCAN = 1,
		NEUV_CMD_STOP_SCAN = 2,
		NEUV_CMD_GET_DEVICE_INFO = 3,
		NEUV_CMD_START_STREAM = 6,
		NEUV_CMD_STOP_STREAM = 7,
		NEUV_CMD_SHUTDOWN = 8,
		NEUV_CMD_GET_PARAMS = 13,
		NEUV_CMD_SET_RT_PARAM = 14,
		NEUV_CMD_SET_LASER_KHZLV = 15,
		NEUV_CMD_SET_LASER_COUNT = 17,
		NEUV_CMD_SET_FRAME_COUNT = 18,
		NEUV_CMD_SET_TRECT_LINE = 19,
		NEUV_CMD_SET_TRECT_PIXEL = 20,
		NEUV_CMD_SET_PWM_VALUE = 22,
		NEUV_CMD_SET_SCAN_MODE = 23,
		NEUV_CMD_SET_DAC_VOLTAGE = 25,
		NEUV_CMD_SET_NOISE_POINTS = 26,
		NEUV_CMD_SET_VOXTEL_PERIOD = 27,
		NEUV_CMD_SET_CAMERA_CROP_WH = 29,
		NEUV_CMD_SET_CAMERA_CROP_XY = 30,
		NEUV_CMD_SET_SYS_MODE = 31,
		NEUV_CMD_SET_LASER_TASK_MODE = 32,
		NEUV_CMD_SAVE_CONFIG_DATA = 33,
		NEUV_CMD_SET_PIXEL_OFFSET = 34,
		NEUV_CMD_SET_DENSITY = 35,
		NEUV_CMD_UPDATE_FPGA_VERSION = 38,
		NEUV_CMD_UPDATE_FPGA_STATUS = 39,
		NEUV_CMD_GET_DEVICE_STATUS = 40,
		NEUV_CMD_CAM_IMAGE_UPDATED = 41,
		NEUV_CMD_SET_CAM_X_DEVIATE = 42,
		NEUV_CMD_SET_CAM_Y_DEVIATE = 43,
		NEUV_CMD_SET_CAM_Z_DEVIATE = 44,
		NEUV_CMD_STILL_ALIVE = 45,
		NEUV_CMD_GPS_UPDATED = 46,
		NEUV_CMD_SET_VOLTAGE_OFFSET = 50,
		NEUV_CMD_GET_LIDAR_INFO_STATUS = 51,
		NEUV_CMD_UPDATE_SYS_TIMESTAMP = 52,
		NEUV_CMD_GET_CAMERA_TYPE = 53,
		NEUV_CMD_GET_AXIS_INFO = 54,
		NEUV_CMD_GET_EXPAND_INFO = 55,
		NEUV_CMD_GET_OCELLUS_PARM = 56,
		NEUV_CMD_SET_OCELLUS_PARM = 57,
		NEUV_CMD_SET_TRANS_COUNT = 58,             
		NEUV_CMD_LIDAR_CTRL = 59,			 	 
		NEUV_CMD_SET_TOF_DELAY = 60,
		NEUV_CMD_SET_SUN_POINT_THRESHOLD = 62,				 
		NEUV_CMD_NIL = 0xffff,

		NEUV_CMD_TEMP0 = 400,
		NEUV_CMD_TEMP1 = 401,
		NEUV_CMD_TEMP2 = 402,
		NEUV_CMD_TEMP3 = 403,
		NEUV_CMD_TEMP4 = 404,
		NEUV_CMD_TEMP5 = 405,
		NEUV_CMD_TEMP6 = 406,
		NEUV_CMD_TEMP7 = 407,
		NEUV_CMD_TEMP8 = 408,
		NEUV_CMD_TEMP9 = 409,
		NEUV_CMD_TEMP10 = 410,
		NEUV_CMD_TEMP80 = 480,
		NEUV_CMD_TEMP81 = 481,
		NEUV_CMD_TEMP_RSP = 499,
		NEUV_CMD_TEMP_SNDR4 = 600,
		NEUV_CMD_TEMP_SNDR5= 601,
		NEUV_CMD_TEMP_SNDR1_DISTANCE = 602,
		NEUV_CMD_TEMP_SNDR2_DISTANCE = 603,
		NEUV_CMD_TEMP_SNDR3_DISTANCE = 604,
		NEUV_CMD_TEMP_SNDR4_DISTANCE = 605,
		NEUV_CMD_TEMP_SNDR5_DISTANCE = 606,

		NEUV_CMD_LIVE_PUB = 0x10001, // publish
		NEUV_CMD_LIVE_SUB = 0x10002, // subscribe
		NEUV_CMD_LIVE_FRH = 0x10003, // frame head
		NEUV_CMD_LIVE_FRT = 0x10004, // frame tail
		NEUV_CMD_LIVE_PCZ = 0x10005, // frame payload
		NEUV_CMD_LIVE_CLP = 0x10006, // client-side ping-pong
		NEUV_CMD_LIVE_SLP = 0x10007, // server-side ping-pong
		NEUV_CMD_LIVE_PS1 = 0x10008, // start push stream
		NEUV_CMD_LIVE_PS2 = 0x10009, // stop push stream
		NEUV_CMD_LIVE_LS0 = 0x1000a, // get stream info
		NEUV_CMD_LIVE_LS1 = 0x1000b, // start pull stream
		NEUV_CMD_LIVE_LS2 = 0x1000c, // stop pull stream
		NEUV_CMD_LIVE_NIL = 0x1ffff
	};

	

	class INeuvEvent {
	public:
		virtual ~INeuvEvent() {}
		virtual void on_connect(int, const char*) = 0;
		virtual void on_disconnect(int) = 0;
		virtual void on_response(int, enum neuv_cmd_code) = 0;
		virtual void on_framedata(int, int64_t, const NeuvUnits&, const nvid_t&) = 0;

		virtual void on_imudata(int, int64_t, const NeuvUnits&, const ImuData&) = 0;
		virtual void on_mjpgdata(int, int64_t, cv::Mat) = 0;
		virtual void on_pczdata(bool) = 0;
		virtual void on_Ladar_Camera(neuvition::NeuvCameraLadarDatas * neuvcameraladardatas) = 0;
		virtual void on_lidar_info_status(neuvition::LidarInfoStatus * lidarInfoStatus) = 0;
		virtual void on_rtspdata(int, int64_t, cv::Mat){}
		virtual void on_rtspsrcdata(int, int64_t,uchar *m_OutBuffer){}
		virtual void on_framestart1(int nCode) {};
		virtual void on_framestart2(int nCode) {};
		virtual void on_abnormal_disconn(std::string err) {};
		

	};
	typedef struct _NeuvEventCallBack {
		void(CALLBACK* on_connect)(int, const char*);
		void(CALLBACK* on_disconnect)(int);
		void(CALLBACK* on_response)(int, int);
		void(CALLBACK* on_framedata)(int, int64_t,const NeuvUnit*, int , nvid_t);
		void(CALLBACK* on_mjpgdata)(int, int64_t, uint8_t *, int, int, int);
		void(CALLBACK* on_rtspdata)(int, int64_t, uint8_t *, int, int, int);
		void(CALLBACK* on_imudata)(int, int64_t, const NeuvUnit*,int, ImuData);
		void(CALLBACK* on_pczdata)(bool);
		void(CALLBACK* on_lidar_info_status)(neuvition::LidarInfoStatus *);
	}NeuvEventCallBack;

	class  NeuvEventPCZCallBack {
		public:
	virtual void on_framedata(int, int64_t, const NeuvUnits&, const nvid_t&) = 0;
		
	};
	

	DECLSPEC_EXPORT void set_pczevent_callback(NeuvEventPCZCallBack  * pczevent_cb_t);

	DECLSPEC_EXPORT void open_pczdata(char * absolutefilepath);

	DECLSPEC_EXPORT INeuvEvent* set_event_callback(NeuvEventCallBack event_cb_t);

	

	DECLSPEC_EXPORT int compute_tof2xyz_table(const double angle_x, const double angle_y, const double bias_y, const int device_type, const NeuPosCor& pos_cor);
	DECLSPEC_EXPORT void compute_tof2xyz_table_with_multi_lasers(const LaserIncidentAngles& angles, const int device_type, const NeuPosCor& pos_cor);
	DECLSPEC_EXPORT uint64_t ntohll(uint64_t val);
	DECLSPEC_EXPORT uint64_t htonll(uint64_t val);

	DECLSPEC_EXPORT int setup_client(const char* host, const int port, INeuvEvent* handler, const bool flag);
	DECLSPEC_EXPORT int setup_client2(const char *host_addr, const int host_port, const char *listen_addr, const char *multi_addr, const int multi_port, INeuvEvent *handler, const bool flag, neuv_connect_type connect_type);
	DECLSPEC_EXPORT int teardown_client();
	DECLSPEC_EXPORT int start_scan();
	DECLSPEC_EXPORT int stop_scan();
	DECLSPEC_EXPORT int start_stream();
	DECLSPEC_EXPORT int stop_stream();
	DECLSPEC_EXPORT int shutdown_device();
	DECLSPEC_EXPORT int query_device_status();
	DECLSPEC_EXPORT int query_device_params();
	DECLSPEC_EXPORT int save_device_params();

	DECLSPEC_EXPORT int set_event_handler(INeuvEvent* handler);
	DECLSPEC_EXPORT int set_reconnect_params(const bool enabled, const size_t seconds);
	DECLSPEC_EXPORT int set_flip_axis(const bool flip_x, const bool flip_y);
	DECLSPEC_EXPORT int set_laser_power(const int percent);
	DECLSPEC_EXPORT int set_laser_interval(const int index);
	DECLSPEC_EXPORT int set_scan_mode(const int index);
	DECLSPEC_EXPORT int set_frame_frequency(const int fps);
	DECLSPEC_EXPORT int set_frame_line_quantity(const int frameline);
	DECLSPEC_EXPORT int set_camera_status(const bool enabled);
	DECLSPEC_EXPORT int set_imu_status(const bool enabled);
	DECLSPEC_EXPORT int set_gps_status(const bool enabled);
	DECLSPEC_EXPORT int get_laser_power();
	DECLSPEC_EXPORT int get_laser_interval();
	DECLSPEC_EXPORT LaserIncidentAngles get_laser_angles();
	DECLSPEC_EXPORT NeuGPRMC get_gps_details();
	DECLSPEC_EXPORT NeuPosCor get_poscor_params();
	DECLSPEC_EXPORT NeuvLaserStatus get_laser_status();
	DECLSPEC_EXPORT int get_lidar_info_status();
	DECLSPEC_EXPORT int get_frame_frequency();
	DECLSPEC_EXPORT int get_frame_line_quantity();
	DECLSPEC_EXPORT int get_scan_mode();	
	DECLSPEC_EXPORT int get_device_type(); 
	//get lidar mac_address
	DECLSPEC_EXPORT string get_device_mac_add(); 
	DECLSPEC_EXPORT NeuCameraType get_camera_type();
	DECLSPEC_EXPORT LidarExpandInfo get_expand_info();
	DECLSPEC_EXPORT Ocellus_param_t get_ocellus_info();
	DECLSPEC_EXPORT ImuData get_lidar_imu_pose();
	DECLSPEC_EXPORT int expand_info_update();
	DECLSPEC_EXPORT int cmd_get_ocellus_params();
	DECLSPEC_EXPORT int cmd_set_ocellus_params(Ocellus_param_t info);
	DECLSPEC_EXPORT int get_tof_one_length();
	DECLSPEC_EXPORT int get_tof_with_timestamp();
	DECLSPEC_EXPORT bool is_camera_on();
	DECLSPEC_EXPORT bool is_imu_on();
	DECLSPEC_EXPORT int set_data_save(const bool enabled);
	DECLSPEC_EXPORT int set_mjpg_curl(const bool enabled);
	DECLSPEC_EXPORT double get_hfov();
	DECLSPEC_EXPORT double get_vfov();
	DECLSPEC_EXPORT int cmd_lidar_ctrl_reboot();
	DECLSPEC_EXPORT int cmd_set_sun_points_threshold(uint32_t value);
	DECLSPEC_EXPORT int cmd_set_tof_delay(uint32_t *delay);
	DECLSPEC_EXPORT int set_trans_count(uint32_t cnt);

	DECLSPEC_EXPORT bool is_connected();
	DECLSPEC_EXPORT bool is_scanning();
	DECLSPEC_EXPORT bool is_streaming();
	DECLSPEC_EXPORT size_t get_lidar_frame_count();
	DECLSPEC_EXPORT size_t get_lidar_transferred_bytes();
	//jason
	DECLSPEC_EXPORT void jason_set_apd_filter(int intensity_value,int dispersioncount,float fdistance);

	//PTHAHNIL
	DECLSPEC_EXPORT void PTH_exec_filter(neuvition::nvid_t frame_id, neuvition::NeuvUnits* points, unsigned int LaserInterval, uint8_t FilterType);
        DECLSPEC_EXPORT void cloud_to_video(int x, int y, int z, cv::Mat mjpgMat, int campos[2]);



	DECLSPEC_EXPORT int start_rtspcamera(const char * url = "rtsp://192.168.1.101:8554/720p-stream");
	DECLSPEC_EXPORT void stop_rtspcamera();
	DECLSPEC_EXPORT void set_rtspfun(void ( * on_rtspdatafun)(int , int , cv::Mat img));

    DECLSPEC_EXPORT void set_apd_value(int val);
    DECLSPEC_EXPORT void set_reflectivity_value(int val);


	//// DEBUG
	DECLSPEC_EXPORT int set_evk_offset(uint8_t id, short offset);
	DECLSPEC_EXPORT int set_slm_mode(uint8_t slmvalue);
	DECLSPEC_EXPORT int laser_angles_clear();
	DECLSPEC_EXPORT int laser_angles_add(double angle);
	DECLSPEC_EXPORT void set_tlog_time(const nvid_t frameid, const int index, const int64_t microsec);
	DECLSPEC_EXPORT void set_tlog_size(const nvid_t frameid, const int index, const size_t cloudsize);
	DECLSPEC_EXPORT void reset_tlog(const nvid_t frameid);
	DECLSPEC_EXPORT void print_tlog(const nvid_t frameid);
	//DECLSPEC_EXPORT int camera_type_update();
	DECLSPEC_EXPORT int laser_status_update();
	DECLSPEC_EXPORT int set_debug_temp_data(enum neuv_cmd_code, int data);
	DECLSPEC_EXPORT int get_debug_temp_data(enum neuv_cmd_code);
	DECLSPEC_EXPORT int set_frank_filter_enabled(bool enabled);
	DECLSPEC_EXPORT int set_g_filter_enabled(bool enabled);
 	DECLSPEC_EXPORT int set_newjpeg_enabled(bool enabled);
	DECLSPEC_EXPORT int set_g_gaus_fit_enabled(bool enabled);
	DECLSPEC_EXPORT int set_g_linear_fit_enabled(bool enabled);
	DECLSPEC_EXPORT int set_g_remove_ground_enabled(bool enabled);
	DECLSPEC_EXPORT int set_jason_filter_enabled(bool enabled);
	DECLSPEC_EXPORT int set_jason_tof_value(int value);
	DECLSPEC_EXPORT int set_jason_process_c_fusion(NeuvUnits& point, const cv::Mat &mjpgMat);

	DECLSPEC_EXPORT int jason_cameartopoint_pos(int x,int y,int & pixel_id,int & line_id,int & cloudpointx,int & cloudpointy,CAMERA_POINT_POS * temppos,int threadid);
	DECLSPEC_EXPORT int jason_cameartopointlist_pos(int x,int y,int & pixel_id,int & line_id,int & cloudpointx,int & cloudpointy,int threadid);
	DECLSPEC_EXPORT cv::Mat get_jason_camearmat(int threadid);
	DECLSPEC_EXPORT cv::Mat get_jasonlist_camearmat(int threadid);
	DECLSPEC_EXPORT void jason_camearinfo_clear(int threadid);
	DECLSPEC_EXPORT void jason_camearinfolist_clear(int threadid);
	DECLSPEC_EXPORT void jason_camearinfo_Add(int threadid);
	
	DECLSPEC_EXPORT	void jason_get_c_flip_axis(bool flip_x, bool flip_y);
	DECLSPEC_EXPORT void JasonSet_config_params(const char * configstr);
	DECLSPEC_EXPORT	std::string JasonGet_config_params();

	DECLSPEC_EXPORT void jason_pcz_correct1(NeuvUnits* points);
	DECLSPEC_EXPORT void jason_pcz_correct2(NeuvUnits* points,int device_type);
	DECLSPEC_EXPORT void jason_pcz_correct_fun(NeuvUnits* points,int device_type,
		bool bFilpX = false, bool bFilpY = true,int nFps = -1,
		int nLaserInter = -1,int nFrameLineQuan = -1);



	DECLSPEC_EXPORT void lidarHardware_json(const char *ipadress,char * datajson);
	DECLSPEC_EXPORT void lidarCalibrtions_json(const char *ipadress,char * datajson);
	DECLSPEC_EXPORT void lidarVerifications_json(const char *ipadress,char * datajson);

	DECLSPEC_EXPORT int set_log_output_enabled(bool enabled);
	DECLSPEC_EXPORT bool is_task_mode_on();
	DECLSPEC_EXPORT int set_npvt_value(int value);
	DECLSPEC_EXPORT int set_task_mode(bool enabled);
	DECLSPEC_EXPORT int get_jason_camera();
	DECLSPEC_EXPORT int get_scan_line_start();
	DECLSPEC_EXPORT int get_scan_line_end();
	DECLSPEC_EXPORT int get_scan_pixel_start();
	DECLSPEC_EXPORT int get_scan_pixel_end();
	DECLSPEC_EXPORT int set_scan_line_pixel(int startLine, int endLine, int startPixel, int endPixel);
	DECLSPEC_EXPORT double get_matrix_data(unsigned int i0, unsigned int i1, unsigned int i2, unsigned int i3);
	DECLSPEC_EXPORT int get_delay_tof();
	DECLSPEC_EXPORT int get_min_tof();
	DECLSPEC_EXPORT int get_max_tof();
	DECLSPEC_EXPORT int get_center_x();
	DECLSPEC_EXPORT int get_center_y();
	DECLSPEC_EXPORT int get_pixel_radius();
	DECLSPEC_EXPORT int get_line_radius();
    DECLSPEC_EXPORT int get_s2_sndr1();
    DECLSPEC_EXPORT int get_s2_sndr2();
    DECLSPEC_EXPORT int get_s2_sndr3();
    DECLSPEC_EXPORT int get_s2_sndr4();
    DECLSPEC_EXPORT int get_s2_sndr5();
    DECLSPEC_EXPORT int get_s2_sndr1_distance();
    DECLSPEC_EXPORT int get_s2_sndr2_distance();
    DECLSPEC_EXPORT int get_s2_sndr3_distance();
    DECLSPEC_EXPORT int get_s2_sndr4_distance();
    DECLSPEC_EXPORT int get_s2_sndr5_distance();

	DECLSPEC_EXPORT int set_camera_fps(int video_fps);
	DECLSPEC_EXPORT int set_pcz_path(const char* pczPath);
	DECLSPEC_EXPORT void get_pcz_path_id(char * pczId);
	DECLSPEC_EXPORT bool is_can_get_pcz_path_id();//add by jerry : 2021?12?22? : ??neuvition::get_pcz_path_id(pcz_id); ??????յ?cz_id ???⣺ ?Ϊsdk??̻?û???????򣬾͵??????????

	//Cisson
	DECLSPEC_EXPORT int set_c_filter_enabled(bool enabled);
	DECLSPEC_EXPORT int set_c_noise_filter_enabled(bool enabled);
	DECLSPEC_EXPORT int set_c_smooth_by_tof_enabled(bool enabled);
	DECLSPEC_EXPORT int set_c_tof_cor_by_pw(bool enabled);
	DECLSPEC_EXPORT int set_c_absol_dis_cor_enabled(bool enabled);
	DECLSPEC_EXPORT int set_c_surface_correct_enabled(bool enabled);
	DECLSPEC_EXPORT int set_c_move_average_enabled(bool enabled);
	DECLSPEC_EXPORT int set_c_remove_brushed_enabled(bool enabled);
	DECLSPEC_EXPORT int set_c_interp_by_tof_enabled(bool enabled);
	DECLSPEC_EXPORT int set_c_lines_merge_enabled(bool enabled);
	DECLSPEC_EXPORT int set_c_lens_cor_enabled(bool enabled);
	DECLSPEC_EXPORT int set_c_pos_cor_enabled(bool enabled);
	DECLSPEC_EXPORT int set_c_reflectivity_cor_enabled(bool enabled);
	DECLSPEC_EXPORT int opencl_test();

	DECLSPEC_EXPORT int set_c_cor_binary_options(uint8_t flag);
	DECLSPEC_EXPORT void get_cameraLidarCoordinate(const NeuvUnit& point, const cv::Mat &mjpgMat, uint8_t bgr[3], int &row, int &col);
	DECLSPEC_EXPORT void get_externalCamera_camera_registration(const cv::Mat &srcImage, const cv::Mat &dstImage, cv::Mat &outImage);
	DECLSPEC_EXPORT void get_externalCameraLidarCoordinate(const NeuvUnit& point, const cv::Mat &mjpgMat, uint8_t bgr[3], int &row, int &col);
	DECLSPEC_EXPORT int get_calibration_params_by_http_json(const char *ipAdress);
	DECLSPEC_EXPORT int set_calibration_params_by_http_json(const char *ipAdress, const char * filePath);
	DECLSPEC_EXPORT void get_calibration_params(int code, bool& enabled, cv::Mat& outputMat);
	DECLSPEC_EXPORT void set_calibration_params(int code, bool enabled, const cv::Mat& inputMat);
	DECLSPEC_EXPORT void get_camera_lidar_params(int code, bool& enabled, cv::Mat& outputMat1, cv::Mat& outputMat2, cv::Mat& outputMat3);
	DECLSPEC_EXPORT void set_camera_lidar_params(int code, bool enabled, const cv::Mat& inputMat1, const cv::Mat& inputMat2, const cv::Mat& inputMat3);

	//wire 
	typedef void(CALLBACK* on_wire_data_callback)(int, int64_t,float, const NeuvUnit*, int, const NeuvWireData*, int);
    DECLSPEC_EXPORT int set_c_wire_callback(on_wire_data_callback callback);
	DECLSPEC_EXPORT int set_c_wire_distance_limit_low(int low);
	DECLSPEC_EXPORT int set_c_wire_distance_limit_high(int high);
	DECLSPEC_EXPORT int set_c_wire_detection_enabled(bool enabled);
    
	//container 
    typedef void(CALLBACK* on_container_data_callback)(int, int64_t, const NeuvUnit*, int, uint8_t *, int, int, int, NeuvCt);
    DECLSPEC_EXPORT int set_c_container_callback(on_container_data_callback callback);
	DECLSPEC_EXPORT int set_c_container_detection_enabled(bool enabled);
    DECLSPEC_EXPORT int set_c_container_manual_enabled(bool enabled);
    DECLSPEC_EXPORT int set_c_container_dispresion_size(int size);
    DECLSPEC_EXPORT int set_c_container_dispresion_depth(int depth);
    DECLSPEC_EXPORT int set_c_container_manual_handle(int is_handle);


	//ship bridge
	DECLSPEC_EXPORT int set_c_ship_bridge_callback(on_container_data_callback callback);
	DECLSPEC_EXPORT int set_c_ship_bridge_enabled(bool enabled);
	DECLSPEC_EXPORT int set_c_ship_bridge_h1(int h);
	DECLSPEC_EXPORT int set_c_ship_bridge_h2(int h);
	DECLSPEC_EXPORT int set_c_ship_bridge_h3(int h);
	DECLSPEC_EXPORT int set_c_ship_bridge_h4(int h);

	//Jerry 
	DECLSPEC_EXPORT int get_cameraladardatas_process_c_fusion(const NeuvUnits& point, const cv::Mat &mjpgMat, neuvition::NeuvCameraLadarDatas& vec_cameraladardatas);

    //salt pile
    DECLSPEC_EXPORT int set_c_salt_pile_params(int status, int pos_id);

	DECLSPEC_EXPORT void set_open_rm_diffusion(bool open);


	//thermal image ??????
	DECLSPEC_EXPORT int jerry_set_thermal_image_status(const bool enabled);
	DECLSPEC_EXPORT int jerry_set_thermal_image(const cv::Mat &mjpgMat);

	DECLSPEC_EXPORT void jerry_process_c_camera_registration(const cv::Mat& srcImage, const cv::Mat& dstImage, cv::Mat &outImage);

#ifdef _DLL_EXPORT
#ifdef __cplusplus
	}
#endif 
#endif
}

#endif /* __NEUVDEFS_H__ */