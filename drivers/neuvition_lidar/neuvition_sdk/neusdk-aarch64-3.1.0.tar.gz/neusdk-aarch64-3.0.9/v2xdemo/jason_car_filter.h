#define _JSON_CAR_FILTER_
#ifdef _JSON_CAR_FILTER_


#include "neuv_defs.hpp"


// Qt

#include <QString>

#include <QFile>
#include <QDir>

#include <QApplication>



// Point Cloud Library
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/surface/mls.h>   //最小二乘平滑处理类定义
#include <pcl/sample_consensus/method_types.h>   //随机参数估计方法头文件
#include <pcl/sample_consensus/model_types.h>   //模型定义头文件
#include <pcl/segmentation/sac_segmentation.h>   //基于采样一致性分割的类的头文件
#include <pcl/features/moment_of_inertia_estimation.h>
#include <pcl/common/transforms.h>
#include <math.h>
#include <QSettings>
#include "v2x.h"
typedef struct oneobject
{
    double objdistance;
    double objDirectionAngle;
    float x;
    float y;
    float width;
    float lenth;
    float speed;
    short id;
    char lane;
    char make;
}ONEOBJECT;

typedef union U1
{
    float bar;
    char ch[4];
}DataU1;

typedef union U2
{
    double bar;
    char ch[8];
}DataU2;


enum OBJID
{
    HUMAN=100,
    BICYCLE=101,
    CAR=102,
    MICROBUS=103,
    MEDIUMBUS=104,
    LARGEBUS=105,
    MICROTRUCK=106,
    MEDIUMTRUCK=107,
    LARGETRUCK=108,
    NOTID=109

};

typedef struct pix_row
{
    int pixcol;
    int row;
}PIX_ROW;
typedef struct objinfo
{

   float centerx;
   float centery;
   float centerz;
   float maxx;
   float maxy;
   float maxz;
   float minx;
   float miny;
   float minz;
   int objtype;
   float lenth;
   float width;
   float height;
   int id;
   float fspeed;
   std::string filename;
   std::string direction;
   int col;
   int row;
   int lane;
   char abnormaltype[20];
   int istamp;
   bool isNewCar;
   std::string car_licenseplate;


}OBJINFO;

struct Detected_Obj
{
    pcl::PointXYZ min_point_;
    pcl::PointXYZ max_point_;
    pcl::PointXYZ centroid_;
    std::string fileid;
};
typedef struct Car_Size
{
    float x;
    float y;
    float z;
}CARSIZE;
typedef struct Car_Info
{
    float flenth;
    float fwidth;
    float fheight;
    int icarid;
    pcl::PointXYZ centroid_;
    int64 iTimeTimestamp;
    float fSpeed;
    std::string fileid;
    bool isCar;
}CAR_INFO;
typedef struct Car_Mark
{
    int iRow;
    int iCol;
}CARMARK;

typedef struct Car_Center
{
    int objid;
    float centerx;
    float centery;
    float centerz;
}CAR_CENTER;

typedef struct Car_Centertracking
{
    int objid;
    float centerx;
    float centery;
    float centerz;
    int istate;
    int iframe;
    float fspeed;
}CAR_CENTERTRACKING;


int64_t jason_current_timestamp();
void Jason_Add(pcl::PointXYZRGBA OnePoint);
void Jason_Setpointime(uint32_t timesec ,uint32_t timeusec);
void Jason_CalculatedSize();
bool Jason_Slice(pcl::PointCloud<pcl::PointXYZRGBA>::Ptr clound, Detected_Obj obj, pcl::PointXYZ sourccenter);
void  sendtoserver_carinfo(unsigned char * cpdata,int & sendsize);
void send_objinfo();
void send_avgobjinfo(OBJINFO objinfo);
void init_globalobjid(int id);
int ExceptionEventJudgment(POSTCAR_INFO & objinfo);

int Jason_Trackingid(std::vector<OBJINFO>   preframe , OBJINFO  & info);

void point_clustering(neuvition::NeuvUnits pointdatas);

void Jason_average_statistics();
void Jason_Set_V2XObjPoint(V2X_Information_Operational * pv2xobj);

void jason_trackingcar(int carid);
void jason_trackingcarcheck();
void jason_trackingcarcheck_continuous();

void jason_FuzzyTrackingDraw();



void Jason_CalculatedSize_Into();



void Jason_TrackingAdd(pcl::PointXYZRGBA OnePoint);
void Jason_TrackingCalculatedSize();
void Jason_CalculateTrackingInfo(std::vector<OBJINFO>   preframe,std::vector<OBJINFO> nowframe);
int Jason_DetectionTrackingDraw(std::vector<OBJINFO>   tempframe);

void Jason_Mergingclustering(std::vector<OBJINFO>  & preframe);
#endif

