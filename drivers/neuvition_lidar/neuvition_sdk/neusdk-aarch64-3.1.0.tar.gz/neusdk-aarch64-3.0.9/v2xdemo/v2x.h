
#pragma once
//#define V2X_H
#ifndef V2X_H
#define V2X_H



#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>
#include <boost/lockfree/spsc_queue.hpp>
#include <boost/atomic.hpp>
// Qt
#include <QMainWindow>
#include <QWidget>
#include <QFileDialog>
#include <QString>
#include <QDesktopWidget>
#include <QTextStream>
#include <QFile>
#include <QThread>
#include <QMessageBox>
#include <QDateTime>
#include <QSignalMapper>
#include <QOpenGLWidget>
#include <QPainter>
#include <QTimer>
#include <QPalette>
#include <QTextBlock>
#include <QColor>
#include <QDesktopServices>
#include <QUrl>
#include <QApplication>
#include <QtNetwork/QNetworkReply>
#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkRequest>
#include <QTcpSocket>

#include <curl/curl.h>
#include <curl/easy.h>


#ifdef _WINDOWS
#else
//qiniu
#include <base.h>
#include <conf.h>
#include <http.h>
#include <io.h>
#include <fop.h>
#include <rs.h>
#endif

#include <opencv2/imgproc/types_c.h>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/dnn.hpp>
#include <opencv2/dnn/shape_utils.hpp>
#include<math.h>




using namespace cv;
#if 0
extern "C"
{
#include <libswscale/swscale.h>
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/time.h>

#include <x264.h>
}
#endif
#include<list>
#include<iostream>
#include<string>



//#define NO_SEND_WEB

using namespace std;
typedef struct postcar_info
{
    unsigned int  car_id;
    int classtype;
    char timestamps[30];
    char timestampu[30];
    int lidar_id;
    float length;
    float width;
    float height;
    char  pic_url[20];
    char  pcd_url[20];
    float pos_x;
    float pos_y;
    float pos_z;
    float speed;
    int local_id;
    int lane;
    char origentation[4];
    char  abnormal_type[20];

}POSTCAR_INFO;
typedef struct Abnormal_evnet
{
    uint64 event_id;
    std::string timestamp;
    int lidar_id;
    std::string abnormal_type;
    std::string  image_url;
    int car_id;
    int obj_type;
    int local_id;
    int abnormal_typeid;
    int lane;
    int users_id;
}ABNROMAL_INFO;
class V2X_Information_Operational
{
   public:
    void Get_Abnormal_Table();
    void Get_LadarInfo_Table();
    void Post_LadarConnectInfo();
    void Post_V2XInfo();
    void Post_UpdataLidarConTime();
    void Post_TimeUpdataLidarConTime();
    void Post_CarInfo(std::vector<POSTCAR_INFO> postcarinfo);
    std::string  Post_V2XAbnormalEven(uint64 event_id,std::string timestamp,int lidar_id,std::string event_type,std::string image_url,int car_id,int obj_type,int local_id,int lane,int users_id);
    void Post_V2XCoordinates();
    int Post_Image(const std::string& key, const std::string& localFile);
    std::string curl_post(std::string url,std::string postStr);
    int curl_get(std::string url,std::string  & postStr);
    void Post_V2XLiveInfo();
    void AddAbnormalevnet(std::string eventype,int car_id,int obj_type,int lane);
    void SetNowFrame(cv::Mat frame);
public:
    int  iAbnormal_Lentgth;
    int  iAbnormal_Width;
    int  iAbnormal_Height;
    int  iAbnormal_MaxSpeed;
    int  iAbnormal_MinSpeed;
    int over_size;
    int over_speed;
    int low_speed;
    int parking;
    int change_lanes;
    int back_up;
    int near_miss;
    int congestion;
    int crash_car;
    int crash_human;
    int execp_obj;
    int break_in;
    int ladar_id;
    int ladarangle;
    int ladarheight;
    unsigned int connect_time;
    int local_id;
    int is_fault;
    int code;
    int objid;
    int eventid;
    int user_id;
    list<cv::Mat> Abnormallist;
    list<ABNROMAL_INFO> Abnormalinfolist;
    cv::Mat NowFrame;
};
int camearimage_live();
int playvideo_online();
void AddVideoFrame();


#endif
