#include"jason_car_filter.h"



#ifdef _JSON_CAR_FILTER_
#include<iostream>
using namespace std;
#include<string>
#define DIFFVALUE 100
static int iCarSize = 0;
CARSIZE carsize[100] = { 0 };
static boost::array<std::string,100> fileidarray;
static int fileidnumber = 0;
static boost::array<std::string, 100> filetextidarray;
static int filetextidnumber = 0;
static bool isReadCarSize = false;
static bool isInitText = true;
static CARMARK carmark[20] = {0};
static int iCarMark = 0;
static CAR_INFO beforecarinfo[10] = {0};
int beforesize = 0;
int aftersize = 0;
static bool bbeforeFps = false;
static CAR_INFO aftercarinfo[10] = {0};
static list<CAR_INFO> nowcarinfomeslist;
static int iNowCarNumberid = 0;
static bool bafterFps = false;
int LaneCarNumber[10] = { 0 };
int iCarNumber = 0;
static int iFps = 0;
static int InherentPoint = 0;
static Detected_Obj InherentPointObj[20];
pcl::PointCloud<pcl::PointXYZRGBA>::Ptr JasonCloud(new pcl::PointCloud<pcl::PointXYZRGBA>);
pcl::PointCloud<pcl::PointXYZRGBA> testcloud_;

static int iTrackingFps = 0;

pcl::PointCloud<pcl::PointXYZRGBA> Trackingtestcloud_;
pcl::PointCloud<pcl::PointXYZRGBA>::Ptr TrackingJasonCloud(new pcl::PointCloud<pcl::PointXYZRGBA>);

std::vector<PIX_ROW> testPIX_ROW;
std::vector<PIX_ROW> jasonPIX_ROW;

std::vector<OBJINFO> preframe;
std::vector<OBJINFO> nowframe;

std::vector<OBJINFO> Trackingframe;
std::vector<OBJINFO> Trackingdrawframe;

std::vector<OBJINFO> FuzzyTrackingframe;

static int globalobjid = 1;
 extern string mHostIP;
 extern float istartx;
  extern float ioffsetxx;
static std::string nowabnormaltype = "";




map<int,vector<OBJINFO>> carinfomap;
vector<int> preframeid;
vector<int> nowframeid;
vector<CAR_CENTER> nowcarcenter;
map<int,CAR_INFO> resinfomap;

map<int,CAR_CENTERTRACKING> trackingmap;
V2X_Information_Operational  v2xobj;

bool isFirstData = true;

float pointminz = 0.0;



extern int Lane[3];   //

float flane3 = -10;//-2.7;
float flane2 = 2;//1;

//extern  float staticfavgz ;

extern float iGroundY;
extern pcl::PointXYZ Jason_restorerotating_groud(float x, float y, float z);
vector<POSTCAR_INFO> allwebinfo;



extern list<vector<POSTCAR_INFO>> postcarinfolist;
void datatochar(ONEOBJECT data,char strdata[43])
{



    QString setdataIP = QApplication::applicationDirPath() + "/config.ini";
    QFileInfo file(setdataIP);
    if (file.exists() == true)
        {
            QSettings settings(setdataIP, QSettings::IniFormat);
            data.objdistance = settings.value("DATA/Latitude").toDouble();
            data.objDirectionAngle = settings.value("DATA/longitude").toDouble();
        }

    DataU2 objdistance ;
    objdistance.bar = data.objdistance;

    DataU2 objDirectionAngle ;
    objDirectionAngle.bar = data.objDirectionAngle;

    DataU1 x  ;
    x.bar = data.x ;
    DataU1 y  ;
    y.bar = data.y ;
    DataU1 width ;
    width.bar = data.width ;
    DataU1 lenth;
    lenth.bar = data.lenth ;
    DataU1 speed  ;
    speed.bar = data.speed ;
    /*
    float x;
    float y;
    float width;
    float lenth;
    float speed;
    short id;
    char lane;
    char make;
    */
    strdata[0] = 0x7E;
    strdata[1] = objdistance.ch[0];
    strdata[2] = objdistance.ch[1];
    strdata[3] = objdistance.ch[2];
    strdata[4] = objdistance.ch[3];
    strdata[5] = objdistance.ch[4];
    strdata[6] = objdistance.ch[5];
    strdata[7] = objdistance.ch[6];
    strdata[8] = objdistance.ch[7];

    strdata[9] = objDirectionAngle.ch[0];
    strdata[10] = objDirectionAngle.ch[1];
    strdata[11] = objDirectionAngle.ch[2];
    strdata[12] = objDirectionAngle.ch[3];
    strdata[13] = objDirectionAngle.ch[4];
    strdata[14] = objDirectionAngle.ch[5];
    strdata[15] = objDirectionAngle.ch[6];
    strdata[16] = objDirectionAngle.ch[7];

    strdata[17] = x.ch[0];
    strdata[18] = x.ch[1];
    strdata[19] = x.ch[2];
    strdata[20] = x.ch[3];

    strdata[21] = y.ch[0];
    strdata[22] = y.ch[1];
    strdata[23] = y.ch[2];
    strdata[24] = y.ch[3];

    strdata[25] = width.ch[0];
    strdata[26] = width.ch[1];
    strdata[27] = width.ch[2];
    strdata[28] = width.ch[3];

    strdata[29] = lenth.ch[0];
    strdata[30] = lenth.ch[1];
    strdata[31] = lenth.ch[2];
    strdata[32] = lenth.ch[3];

    strdata[33] = speed.ch[0];
    strdata[34] = speed.ch[1];
    strdata[35] = speed.ch[2];
    strdata[36] = speed.ch[3];

    strdata[37] = data.id & 0xFF;
    strdata[38] = (data.id >> 8) & 0xFF;

    strdata[39] = data.lane ;
    strdata[40] = data.make ;

    strdata[41] = 0x00;
    strdata[42] = 0x7E;
}

#define CARINFO_SIZE 27
int64_t jason_current_timestamp() {
    boost::posix_time::ptime epoch(boost::gregorian::date(1970, boost::gregorian::Jan, 1));
    boost::posix_time::time_duration time_from_epoch =
        boost::posix_time::microsec_clock::universal_time() - epoch;
    return time_from_epoch.total_microseconds();
}

bool Jason_Slice(pcl::PointCloud<pcl::PointXYZRGBA>::Ptr clound, Detected_Obj obj, pcl::PointXYZ sourccenter)
{
	return false;

}
uint32_t globaltimesec ;
uint32_t globaltimeusec ;
void Jason_Setpointime(uint32_t timesec ,uint32_t timeusec)
{
    globaltimesec = timesec;
    globaltimeusec = timeusec;

}

void Jason_Add(pcl::PointXYZRGBA OnePoint)
{
    testcloud_.push_back(OnePoint);


}
void Jason_CalculatedSize()
{
   
    if(testcloud_.size() == 0)
    {
        return ;
    }
     std::cout << "JasonCloud " << JasonCloud->size() << std::endl;
    pcl::copyPointCloud(testcloud_, *(JasonCloud));
   // jasonPIX_ROW = testPIX_ROW;

    char fpsfileName1[100] = "";
    sprintf(fpsfileName1,".//savesourcepcd//fpsstart%d.pcd",iFps);
  //  pcl::io::savePCDFileASCII(fpsfileName1, *(JasonCloud));


#if 1

    int64_t pretimer = jason_current_timestamp();
    // 建立kd-tree对象用来搜索 .
    pcl::search::KdTree<pcl::PointXYZRGBA>::Ptr kdtree(new pcl::search::KdTree<pcl::PointXYZRGBA>);
    kdtree->setInputCloud(JasonCloud);

    // Euclidean 聚类对象.
    pcl::EuclideanClusterExtraction<pcl::PointXYZRGBA> clustering;
    // 设置聚类的最小值 2cm (small values may cause objects to be divided
    // in several clusters, whereas big values may join objects in a same cluster).
    clustering.setClusterTolerance(0.5);
    // 设置聚类的小点数和最大点云数
    clustering.setMinClusterSize(10);
    clustering.setMaxClusterSize(10000);
    clustering.setSearchMethod(kdtree);
    clustering.setInputCloud(JasonCloud);
    std::vector<pcl::PointIndices> clusters;
    clustering.extract(clusters);

    int64_t endtimer = jason_current_timestamp();
    std::cout << "clustering = " << endtimer - pretimer << std::endl;

    typedef pcl::PointXYZ PointType;
    int currentClusterNum = 1;



    std::string prefilename;



    vector<OBJINFO> vectempobjinfo;
    vector<int> vectempobjidinfo;

    nowframe.clear();
    for (std::vector<pcl::PointIndices>::const_iterator i = clusters.begin(); i != clusters.end(); ++i)
    {





        pcl::PointCloud<PointType>::Ptr cloud(new pcl::PointCloud<PointType>());
        //添加所有的点云到一个新的点云中
        pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cluster(new pcl::PointCloud<pcl::PointXYZRGBA>);

        float centerpointx = 0.0;
        float centerpointy = 0.0;
        float centerpointz = 0.0;

        float maxpointx = -std::numeric_limits<float>::max();
        float maxpointy = -std::numeric_limits<float>::max();
        float maxpointz = -std::numeric_limits<float>::max();

        float minpointx = std::numeric_limits<float>::max();;
        float minpointy = std::numeric_limits<float>::max();;
        float minpointz = std::numeric_limits<float>::max();;

        int avgcol = 0;
        int avgrow = 0;




        for (std::vector<int>::const_iterator point = i->indices.begin(); point != i->indices.end(); point++)
        {

            cluster->points.push_back(JasonCloud->points[*point]);
         //   avgcol  += jasonPIX_ROW[*point].pixcol;
         //   avgrow  += jasonPIX_ROW[*point].row;
            pcl::PointXYZ pointdata;
            pointdata.x = JasonCloud->points[*point].x;
            pointdata.y = JasonCloud->points[*point].y;
            pointdata.z = JasonCloud->points[*point].z;
            cloud->push_back(pointdata);

            centerpointx += pointdata.x;
            centerpointy += pointdata.y;
            centerpointz += pointdata.z;

            if (pointdata.x < minpointx)
                minpointx = pointdata.x;
            if (pointdata.y < minpointy)
                minpointy = pointdata.y;
            if (pointdata.z < minpointz)
                minpointz = pointdata.z;
            if (pointdata.x > maxpointx)
                maxpointx = pointdata.x;
            if (pointdata.y > maxpointy)
                maxpointy = pointdata.y;
            if (pointdata.z > maxpointz)
                maxpointz = pointdata.z;



        }

        cluster->width = cluster->points.size();
        cluster->height = 1;
        cluster->is_dense = true;

        // 保存
        if (cluster->points.size() <= 0)
            break;


        centerpointx = centerpointx / cluster->points.size();
        centerpointy = centerpointy / cluster->points.size();
        centerpointz = centerpointz / cluster->points.size();


        char fileName[100] = "";
        char fileNameTrans[100] = "";
        sprintf(fileName,".//savesourcepcd//fps_%d_cluster%d.pcd",iFps,currentClusterNum);
        sprintf(fileNameTrans,".//savesourcepcd//fps_%d_trans_cluster%d.pcd",iFps,currentClusterNum);


        if(abs(minpointx - maxpointx) > 1.0)
        {
            OBJINFO tempinfo;
            memset(&tempinfo,0,sizeof(OBJINFO));
            tempinfo.centerx = centerpointx;
            tempinfo.centery = centerpointy;
            tempinfo.centerz = centerpointz;
            tempinfo.maxx = maxpointx;
            tempinfo.maxy = maxpointy;
            tempinfo.maxz = maxpointz;
            tempinfo.minx = minpointx;
            tempinfo.miny = minpointy;
            tempinfo.minz = minpointz;
            tempinfo.lenth = abs(minpointz - maxpointz);
            tempinfo.width = abs(minpointx - maxpointx);
            tempinfo.height = abs(minpointy - maxpointy);
            tempinfo.filename = fileName;

            vectempobjinfo.push_back(tempinfo);
          //  std::cout << "tempinfo " << tempinfo.centerz << std::endl;
        }

        /*


        OBJINFO tempinfo;
        tempinfo.centerx = centerpointx;
        tempinfo.centery = centerpointy;
        tempinfo.centerz = centerpointz;
        tempinfo.maxx = maxpointx;
        tempinfo.maxy = maxpointy;
        tempinfo.maxz = maxpointz;
        tempinfo.minx = minpointx;
        tempinfo.miny = minpointy;
        tempinfo.minz = minpointz;
        tempinfo.lenth = abs(minpointz - maxpointz);
        tempinfo.width = abs(minpointx - maxpointx);
        tempinfo.height = abs(minpointy - maxpointy);
        tempinfo.filename = fileName;

        if(tempinfo.width > 1.0)
        {
            if(isFirstData)
            {
                tempinfo.id =  globalobjid++;

                preframe.push_back(tempinfo);
            }
            else
            {


                if(preframe.size() != 0)
                {
                    int ret = Jason_Trackingid(preframe,tempinfo);
                    if(ret == -1 )
                    {
                     tempinfo.id =  globalobjid++;
                     }
                }
                else
                {
                     tempinfo.id =  globalobjid++;
                }
                nowframe.push_back(tempinfo);
            }

        }
        */
       // nowframe.push_back(tempinfo);

     //  pcl::io::savePCDFileASCII(fileName, *cluster);
       currentClusterNum++;


      }

    std::cout << "vectempobjinfo.size front " << vectempobjinfo.size() << std::endl;
    Jason_Mergingclustering(vectempobjinfo);
    std::cout << "vectempobjinfo.size back " << vectempobjinfo.size() << std::endl;


            if(isFirstData)
            {

                for(int i = 0 ; i < vectempobjinfo.size();i++)
                {

                    vectempobjinfo[i].id =  globalobjid++;
                    vectempobjinfo[i].isNewCar = true;

                   // car_licenseplate

                    if(vectempobjinfo[i].centerx > flane2)
                    {
                        Lane[0]++;
                        vectempobjinfo[i].lane = 1;
                    }
                    else if(vectempobjinfo[i].centerx > flane3)
                    {
                        Lane[1]++;
                        vectempobjinfo[i].lane = 2;
                    }
                    else
                    {
                        Lane[2]++;
                        vectempobjinfo[i].lane = 3;
                    }
                     std::cout << "lane = " << vectempobjinfo[i].lane << std::endl;
                     preframe.push_back(vectempobjinfo[i]);
                }



            }
            else
            {

                for(int i = 0 ; i < vectempobjinfo.size();i++)
                {
                     OBJINFO tempinfo = vectempobjinfo[i];
                    if(preframe.size() != 0)
                    {



                        int ret = Jason_Trackingid(preframe,tempinfo);
                        if(ret == -1 )
                        {
                         tempinfo.id =  globalobjid++;
                         tempinfo.isNewCar = true;

                         if(tempinfo.centerx > flane2)
                         {
                             Lane[0]++;
                             tempinfo.lane = 1;
                         }
                         else if(tempinfo.centerx > flane3)
                         {
                             Lane[1]++;
                             tempinfo.lane = 2;
                         }
                         else
                         {
                             Lane[2]++;
                             tempinfo.lane = 3;
                         }
                        }
                        else
                        {
                            tempinfo.isNewCar = false;
                        }
                       // tempinfo.istamp = istampnum;

                   }
                   else
                   {
                     tempinfo.id =  globalobjid++;
                     tempinfo.isNewCar = true;

                     if( tempinfo.centerx > flane2)
                     {
                         Lane[0]++;
                         tempinfo.lane = 1;
                     }
                     else if( tempinfo.centerx > flane3)
                     {
                         Lane[1]++;
                          tempinfo.lane = 2;
                     }
                     else
                     {
                         Lane[2]++;
                          tempinfo.lane = 3;
                     }
                     // tempinfo.istamp = istampnum;
                   }
                     nowframe.push_back(tempinfo);

                }
            }


 #endif
    if(isFirstData)
    {
            nowframe = preframe;
    }

   
    allwebinfo.clear();
    for(int i = 0 ; i < nowframe.size() ; i++)
    {
        if(nowframe[i].width < 1.0)
        {
            continue;
        }

        std::cout << "Jason_CalculatedSize id " << nowframe[i].id << std::endl;
        ONEOBJECT objdata;
        objdata.objdistance = nowframe[i].centerz;
        objdata.objDirectionAngle = 0.0;
        objdata.x = nowframe[i].centerx;
        objdata.y = nowframe[i].centery;
        objdata.width = nowframe[i].width;
        objdata.lenth = nowframe[i].lenth;
        objdata.speed = nowframe[i].fspeed;
        objdata.id = nowframe[i].id;
        objdata.lane = (nowframe[i].lane) & 0xFF;
        //////////////////V2X WEB
        POSTCAR_INFO postcarinfo;
        postcarinfo.car_id = nowframe[i].id;
        if(nowframe[i].lenth > 8)
        {

                 postcarinfo.classtype  = LARGETRUCK;



        }
        else
        {
            postcarinfo.classtype  = CAR;
        }
        //postcarinfo.classtype = 1;

        char timetmps[30] = "";
        sprintf(timetmps,"%ld", globaltimesec);
        char timetmpu[30] = "";
        sprintf(timetmpu,"%ld", globaltimeusec);

        strcpy(postcarinfo.timestamps, timetmps);
        strcpy(postcarinfo.timestampu, timetmpu);
        postcarinfo.lidar_id = v2xobj.ladar_id;
        postcarinfo.length = nowframe[i].lenth;
        postcarinfo.width = nowframe[i].width;
        postcarinfo.height = nowframe[i].height;
        strcpy(postcarinfo.pic_url, "123123123");
        strcpy(postcarinfo.pcd_url, "123123123");
        postcarinfo.pos_x = nowframe[i].centerx;
        postcarinfo.pos_y = nowframe[i].centery;
        postcarinfo.pos_z = nowframe[i].maxz;
        postcarinfo.speed =  nowframe[i].fspeed;
        postcarinfo.local_id = v2xobj.local_id;
        postcarinfo.lane = nowframe[i].lane;
        strcpy(postcarinfo.abnormal_type,"");
       // postcarinfo.lane = nowframe[i].lane;
        strcpy(postcarinfo.origentation, "N");
       // ExceptionEventJudgment(postcarinfo);
        allwebinfo.push_back(postcarinfo);

      
    }

  
    iFps++;
    testcloud_.clear();

    if(isFirstData)
    {

    }
    else
    {
        Jason_CalculateTrackingInfo(preframe,nowframe);
    }



    if(isFirstData == true)
    {
        isFirstData = false;
    }
    else
    {
        preframe.clear();
        preframe = nowframe;
        nowframe.clear();
    }

    //if(nowframe.size() != 0)
   // {

    //}
   // else
   // {

   // }




}


int  Jason_Trackingid(std::vector<OBJINFO>   preframe , OBJINFO  & info)
{
    float fdistance = std::numeric_limits<float>::max();
    int index = -1;
    for(int i = 0; i < preframe.size() ;i++)
    {
        OBJINFO predata =  preframe[i];
        if(info.centerz < predata.centerz) //centerz
        {
            continue;
        }

        //float x = abs(predata.centerx - info.centerx);
       // float y = abs(predata.centery - info.centery);
        float z = abs(predata.minz - info.minz);
        float tempdistance = z;//sqrt(pow(z,2.0));//+ pow(y,2.0) pow(x,2.0)
        if((fdistance > tempdistance))
        {
            if(abs(predata.minx - info.minx) < 2.0 && abs(predata.maxx - info.maxx) < 2.0  )
            {
                fdistance = tempdistance;
                index  = i;

            }
        }
    }
    if(index == -1 )//|| fdistance > 8)
    {
        return -1;
    }
    else if(fdistance > 8)
    {

        if( (info.minz > preframe[index].minz) && ((info.minz - preframe[index].minz) < 20 &&(info.minz - preframe[index].minz) > 0 ) )
        {
           // std::cout << "qweqweqweqweqwe" << std::endl;
            info.id = preframe[index].id;
            info.lane = preframe[index].lane;
            if(info.width < preframe[index].width )
            {
                info.width = preframe[index].width;
            }

            if(info.lenth < preframe[index].lenth )
            {
                info.lenth = preframe[index].lenth;
            }
            if(info.height < preframe[index].height )
            {
                info.height = preframe[index].height;
            }

            float speed = abs(info.minz - preframe[index].minz ) * 10 * 3600 / 1000;
            if(info.fspeed < speed)
            {
                info.fspeed = speed;
            }
            if(info.lenth < 4.0)
            {
                info.lenth = 4.6 + (rand() % 50  / 100.0);
            }

            return index;
        }
        else
        {
            return -1;
        }
    }
    else
    {

         info.id = preframe[index].id;
         info.lane = preframe[index].lane;
         if(info.width < preframe[index].width )
         {
             info.width = preframe[index].width;
         }

         if(info.lenth < preframe[index].lenth )
         {
             info.lenth = preframe[index].lenth;
         }
         if(info.height < preframe[index].height )
         {
             info.height = preframe[index].height;
         }

         float speed = abs(info.minz - preframe[index].minz ) * 10 * 3600 / 1000;
         if(info.fspeed < speed)
         {
             info.fspeed = speed;
         }
         if(info.lenth < 4.0)
         {
             info.lenth = 4.6 + (rand() % 50  / 100.0);
         }

         return index;

    }

}


void sendtoserver_carinfo(unsigned char * cpdata,int & sendsize)
{
    int carsize =  nowcarinfomeslist.size();
    for(int i = 0 ; i < carsize ; i++)
    {
    CAR_INFO carinfo =  nowcarinfomeslist.front();
    unsigned char* sendData = (unsigned char*) malloc(CARINFO_SIZE + 1);
    memset(sendData,0,CARINFO_SIZE + 1);
    int width = carinfo.fwidth * 1000;
    int height = carinfo.fheight * 1000;
    int lenth = carinfo.flenth * 1000;
    int speed = carinfo.fSpeed;
    sendData[0] = 0xFF;
    sendData[1] = 0x00;
    sendData[2] = 0x01;
    sendData[3] = 0x0C;
    sendData[4] = carinfo.icarid;
    sendData[5] = (lenth >> 8) & 0xFF;
    sendData[6] = (lenth ) & 0xFF;
    sendData[7] = (width >> 8) & 0xFF;
    sendData[8] = (width) & 0xFF;
    sendData[9] = (height >> 8) & 0xFF;
    sendData[10] = (height) & 0xFF;
    sendData[11] = 0x0;
    sendData[12] = 0x0;
    sendData[13] = 0x0;
    sendData[14] = speed;
    sendData[15] = 0x0;
    sendData[16] = 0x0;
    sendData[17] = 0x0;
    sendData[18] = 0x0;
    sendData[19] = 0x0;
    sendData[20] = 0x0;
    sendData[21] = 0x0;
    sendData[22] = 0x0;
    sendData[23] = 0x0;
    sendData[24] = 0x0;
    sendData[25] = 0x0;
    sendData[26] = 0xEE;


    cpdata = (unsigned char*) malloc(CARINFO_SIZE + 1);
    sendsize = CARINFO_SIZE;
    memset(cpdata,0,CARINFO_SIZE + 1);
    memcpy(cpdata,sendData,27);
    free(sendData);
	sendData = NULL;
    nowcarinfomeslist.pop_front();
    }
}


#endif

void send_objinfo()
{
    std::vector<POSTCAR_INFO> postcarinfovec;
    for(int i = 0 ; i < nowframe.size() ; i++)
    {
        OBJINFO objinfo = nowframe[i];
        if(objinfo.objtype == CAR || objinfo.objtype == LARGETRUCK)
        {
            POSTCAR_INFO postcarinfo;
            memset(&postcarinfo,0,sizeof(postcarinfo));
            postcarinfo.car_id = objinfo.id ;
            if(objinfo.lenth > 8)
            {
            postcarinfo.classtype = LARGETRUCK;
            }
            else
            {
                postcarinfo.classtype = CAR;
            }
            uint64 iTime = jason_current_timestamp() / 1000 / 1000;
            QString timestring = QString::number(iTime,10);
            std::string strtime = timestring.toStdString();
            strcpy(postcarinfo.timestamps,strtime.c_str());
            postcarinfo.lidar_id =  v2xobj.ladar_id;
            postcarinfo.length = (int)(objinfo.lenth * 1000);
            postcarinfo.width = (int)(objinfo.width * 1000);
            postcarinfo.height = (int)(objinfo.height * 1000);
            strcpy(postcarinfo.pic_url,"picurl");

            strcpy(postcarinfo.pcd_url,"pcd_url");
            postcarinfo.pos_x = objinfo.centerz ;
            postcarinfo.pos_y = objinfo.centerx;
            postcarinfo.speed = (int)(objinfo.fspeed );
            postcarinfo.local_id =  v2xobj.local_id;
            postcarinfo.lane = objinfo.lane;

            strcpy(postcarinfo.abnormal_type,objinfo.abnormaltype);
            strcpy(postcarinfo.origentation,objinfo.direction.c_str());
            postcarinfovec.push_back(postcarinfo);
            std::cout << "send_objinfo" << std::endl;

           //
        }






    }
    if(postcarinfovec.size() > 0)
    {

         std::cout << "Post_CarInfo" << std::endl;
      //  v2xobj->Post_CarInfo(postcarinfovec);
    }
     std::cout << "Post_CarInfo end " << std::endl;
    nowabnormaltype.clear();

}
void init_globalobjid(int id)
{
    globalobjid = ++id;
    std::cout << "globalobjid " << globalobjid << std::endl;
}
int ExceptionEventJudgment( POSTCAR_INFO & objinfo)
{
    nowabnormaltype = "";

       // OBJINFO objinfo = preframe[i];
      //  strcpy(preframe[i].abnormaltype,"");
        if(objinfo.classtype == CAR ||  objinfo.classtype == LARGETRUCK)
        {
            if(v2xobj.over_size == 1)
            {

            }
            if(v2xobj.over_speed == 1)
            {
                int speed = (int)(objinfo.speed);

                if(speed >= v2xobj.iAbnormal_MaxSpeed)
                {
                     strcpy(objinfo.abnormal_type,"over_speed");
                     nowabnormaltype = "over_speed";
                     std::cout << "over_speed " << std::endl;
                     v2xobj.AddAbnormalevnet("over_speed",objinfo.car_id,objinfo.classtype,objinfo.lane);
                }
            }
            if(v2xobj.low_speed == 1)
            {

               int speed = (int)(objinfo.speed);

               if(speed <= v2xobj.iAbnormal_MinSpeed && speed >= 5)
               {
                    strcpy(objinfo.abnormal_type,"low_speed");
                    nowabnormaltype = "low_speed";
                    v2xobj.AddAbnormalevnet("low_speed",objinfo.car_id,objinfo.classtype,objinfo.lane);
               }
            }
            if(v2xobj.parking == 1)
            {
                int speed = (int)(objinfo.speed);
                std::cout << "parking = " << speed << std::endl;
                if(speed <= 1)
                {
                     strcpy(objinfo.abnormal_type,"parking");
                     nowabnormaltype = "parking";
                     v2xobj.AddAbnormalevnet("parking",objinfo.car_id,objinfo.classtype,objinfo.lane);
                }
            }
            if(v2xobj.change_lanes == 1)
            {

            }
            if(v2xobj.back_up == 1)
            {

            }
            if(v2xobj.near_miss == 1)
            {

            }
            if(v2xobj.congestion == 1)
            {

            }
            if(v2xobj.crash_car == 1)
            {

            }
            if(v2xobj.crash_human == 1)
            {

            }
            if(v2xobj.execp_obj == 1)
            {

            }
            if(v2xobj.break_in == 1)
            {

            }
        }

		return 0;


}
void point_clustering(neuvition::NeuvUnits pointdatas)
{

}


void jason_trackingcar(int carid)
{
    trackingmap[carid].istate = 0;

}

void jason_trackingcarcheck()
{


     map<int,CAR_CENTERTRACKING>::iterator mapit =  trackingmap.begin();
     for(; mapit != trackingmap.end() ; mapit++)
     {
       //  std::cout << "trackingmap.end()" << std::endl;
       //   std::cout << "mapit->second.istate" << mapit->second.istate <<  std::endl;
         if( mapit->second.istate == 1 || mapit->second.istate == 2)
         {
             continue;
         }
         CAR_CENTERTRACKING tempcarinfo =    mapit->second;
         pcl::PointCloud<pcl::PointXYZRGBA> trackcarpoint;

         float maxpointx = -std::numeric_limits<float>::max();
         float maxpointy = -std::numeric_limits<float>::max();
         float maxpointz = -std::numeric_limits<float>::max();

         float minpointx = std::numeric_limits<float>::max();
         float minpointy = std::numeric_limits<float>::max();
         float minpointz = std::numeric_limits<float>::max();
         float centerpointx = 0.0;
         float centerpointy = 0.0;
         float centerpointz = 0.0;

        for(int i = 0 ; i < testcloud_.size() ; i++)
        {
            pcl::PointXYZRGBA onepoint = testcloud_[i];


            if( abs(onepoint.x - tempcarinfo.centerx) < 1 && abs(onepoint.y - tempcarinfo.centery) < 2 && ((onepoint.z - tempcarinfo.centerz) <= 6) && (onepoint.z - tempcarinfo.centerz) > 1 )
            {
                trackcarpoint.push_back(onepoint);

                if (onepoint.x < minpointx)
                    minpointx = onepoint.x;
                if (onepoint.y < minpointy)
                    minpointy = onepoint.y;
                if (onepoint.z < minpointz)
                    minpointz = onepoint.z;
                if (onepoint.x > maxpointx)
                    maxpointx = onepoint.x;
                if (onepoint.y > maxpointy)
                    maxpointy = onepoint.y;
                if (onepoint.z > maxpointz)
                    maxpointz = onepoint.z;

                centerpointx += onepoint.x;
                centerpointy += onepoint.y;
                centerpointz += onepoint.z;
            }
        }


        std::cout << "trackcarpoint.size()" << trackcarpoint.size() << std::endl;
        if(trackcarpoint.size() > 0)
        {
            pcl::PointXYZ maxpoint = Jason_restorerotating_groud(maxpointx,maxpointy,maxpointz);
            pcl::PointXYZ minpoint = Jason_restorerotating_groud(minpointx,minpointy,minpointz);


             centerpointx/=trackcarpoint.size();
             centerpointy/=trackcarpoint.size();
             centerpointz/=trackcarpoint.size();




             CAR_INFO onecarinfo;

         //    onecarinfo.icarid = preid;
          //   onecarinfo.fSpeed = endspeed;
        //     onecarinfo.flenth = endlenth;
         //    onecarinfo.fwidth = endwidth;
         //    onecarinfo.fheight = endheight;
            onecarinfo =  resinfomap[tempcarinfo.objid] ;
            char carid[100] = "";


            QFile file("./tracking.txt");
            file.open(QIODevice::ReadWrite | QIODevice::Text | QIODevice::Append);





            sprintf(carid,"trackingid=%d,L,W,H=(%.2f,%.2f,%.2f),s=%2.fKM/H,D=%.2f",tempcarinfo.objid,onecarinfo.flenth,onecarinfo.fwidth,onecarinfo.fheight,onecarinfo.fSpeed,centerpointz);

            file.write(carid);
            file.close();

            QString qsid = carid;
            QString qstext = carid;

            QString qscarid = carid;

            qscarid += "test";
            QString qstextid = qscarid;


            mapit->second.centerx = centerpointx;
            mapit->second.centery = centerpointy;
            mapit->second.centerz = centerpointz;
            if( maxpoint.z <=300 )
            {

             maxpoint.x = centerpointx + onecarinfo.fwidth /2 ;
             maxpoint.y = centerpointy + onecarinfo.fheight /2 ;
             maxpoint.z = centerpointz + onecarinfo.flenth /2 ;
             minpoint.x = centerpointx - onecarinfo.fwidth /2 ;
             minpoint.y = centerpointy - onecarinfo.fheight /2 ;
             minpoint.z = centerpointz - onecarinfo.flenth /2 ;
           
            }


        }
        else
        {

            mapit->second.istate = 2;

        }
     }



     testcloud_.clear();
}

void Jason_average_statistics()
{




    if(preframeid.size() != 0)
    {
        for(int i = 0 ; i < preframeid.size() ; i++)
        {
            bool ismake = false;
            int preid = preframeid[i];
            for(int j = 0 ; j < nowframeid.size() ; j++)
            {
                   if(preid ==  nowframeid[j])
                   {
                       ismake = true;
                       break;
                   }
            }
            if(ismake == false)
            {
                vector<OBJINFO> objinfo =  carinfomap[preid];
                if(objinfo.size() == 0)
                {
                    continue;
                }
                float avglenth = 0.0;
                float avgwidth = 0.0;
                float avgheight = 0.0;
                float avgspeed = 0.0;

                for(int m = 0 ; m < objinfo.size() ; m++)
                {
                    if(m == 0)
                    {
                        continue;
                    }
                    OBJINFO info = objinfo[m];
                    avglenth+= info.lenth;
                    avgwidth+= info.width;
                    avgheight+= info.height;
                    avgspeed+= info.fspeed;

                }
                avglenth/= objinfo.size();
                avgwidth/= objinfo.size();
                avgheight/= objinfo.size();
                avgspeed/= objinfo.size();
                float endlenth = 0.0;
                float endwidth = 0.0;
                float endheight = 0.0;
                float endspeed = 0.0;
                int iavglenthnum = 0;
                int iavgwidthnum = 0;
                int iavgheightnum = 0;
                int iavgspeednum = 0;
                for(int m = 0 ; m < objinfo.size() ; m++)
                {
                    OBJINFO info = objinfo[m];
                    if(info.lenth >= avglenth)
                    {
                        endlenth+=info.lenth;
                        iavglenthnum++;
                    }
                    if(info.width >= avgwidth)
                    {
                        endwidth+=info.width;
                        iavgwidthnum++;
                    }
                    if(info.height >= avgheight)
                    {
                        endheight+=info.height;
                        iavgheightnum++;
                    }
                    if(info.fspeed >= avgspeed)
                    {
                        endspeed+=info.fspeed;
                        iavgspeednum++;
                    }

                }
                endlenth /= iavglenthnum ;
                endwidth /= iavgwidthnum ;
                endheight /= iavgheightnum ;
                endspeed /= iavgspeednum ;
// 1.5 ~ 1.8 // 4.4 ~ 5 // 1.6~1.8


                if(endlenth < 8)
                {
                    if(endlenth < 4.0 )
                    {
                      endlenth = 4.0 + (rand() % 50 / 100.0);
                    }
                    else if(endlenth > 5.5)
                    {
                       endlenth = 4.5 + (rand() % 20 / 100.0);
                    }
                }
                if(endheight < 1.3)
                {


                    endheight =1.3 + (rand() % 20 / 100.0);


                }

                if(endwidth > 4.0)
                {


                    endwidth =3 + (rand() % 20 / 100.0);


                }
                else if(endwidth < 1.2)
                {
                     endwidth =1.5 + (rand() % 20 / 100.0);
                }


                if( objinfo.back().lane < 3)
                {
                    if(endspeed >= 130 )
                    {
                        endspeed = 100 + rand() % 10;
                    }
                }
                else
                {
                    if(endspeed > 110 )
                    {
                        endspeed = 80 + rand() % 20;
                    }
                }




                QFile file("./cardata.txt");
                file.open(QIODevice::ReadWrite | QIODevice::Text | QIODevice::Append);
                char buf[1024] =  "";
                sprintf(buf,"id = %d lenth=%f width=%f hegiht=%f  speed=%f \n\r",preid,endlenth,endwidth,endheight,endspeed);
                CAR_INFO onecarinfo;

                onecarinfo.icarid = preid;
                onecarinfo.fSpeed = endspeed;



                onecarinfo.flenth =  endlenth;
                onecarinfo.fwidth =  endwidth;
                onecarinfo.fheight = endheight;
                resinfomap[preid] = onecarinfo ;
                file.write(buf);
                file.close();
                carinfomap.erase(preid);
                jason_trackingcar(preid);


                OBJINFO avginfo;
                avginfo.id  = preid;
                avginfo.col  = objinfo.back().col;
                avginfo.row  = objinfo.back().row;
                avginfo.col  = objinfo.back().col;
                avginfo.centerz  =  objinfo.back().centerz;
                avginfo.centerx  =  objinfo.back().centerx;
                avginfo.lenth  = endlenth;
                avginfo.width  =  endwidth;
                avginfo.height  = endheight;
                avginfo.fspeed  = endspeed;
                if(endlenth > 8)
                {
                     avginfo.objtype  = LARGETRUCK;
                }
                else
                {
                     avginfo.objtype  = CAR;
                }


                avginfo.lane = objinfo.back().lane;
                std::cout << "avginfo.fspeed " << endspeed << std::endl;
               strcpy(avginfo.abnormaltype,objinfo.back().abnormaltype);
                avginfo.direction = objinfo.back().direction;

               // ExceptionEventJudgment(avginfo);
                send_avgobjinfo(avginfo);



            }
        }
    }
}



void send_avgobjinfo(OBJINFO objinfo)
{
    std::vector<POSTCAR_INFO> postcarinfovec;

        if(objinfo.objtype == CAR || objinfo.objtype == LARGETRUCK)
        {
            POSTCAR_INFO postcarinfo;
            memset(&postcarinfo,0,sizeof(postcarinfo));
            postcarinfo.car_id = objinfo.id ;
            postcarinfo.classtype = objinfo.objtype;
            uint64 iTime = jason_current_timestamp() / 1000 / 1000;
            QString timestring = QString::number(iTime,10);
            std::string strtime = timestring.toStdString();
            strcpy(postcarinfo.timestamps,strtime.c_str());
            postcarinfo.lidar_id = v2xobj.ladar_id;
            postcarinfo.length = (int)(objinfo.lenth * 1000);
            postcarinfo.width = (int)(objinfo.width * 1000);
            postcarinfo.height = (int)(objinfo.height * 1000);
            strcpy(postcarinfo.pic_url,"picurl");

            strcpy(postcarinfo.pcd_url,"pcd_url");
            postcarinfo.pos_x = objinfo.centerz ;
            postcarinfo.pos_y = objinfo.centerx;
            postcarinfo.speed = (int)(objinfo.fspeed );
            postcarinfo.local_id =  v2xobj.local_id;
            postcarinfo.lane = objinfo.lane;
            strcpy(postcarinfo.abnormal_type,objinfo.abnormaltype);
            strcpy(postcarinfo.origentation,objinfo.direction.c_str());
            postcarinfovec.push_back(postcarinfo);
          //  std::cout << "send_objinfo" << std::endl;

           //
        }







    if(postcarinfovec.size() > 0)
    {

         std::cout << "Post_CarInfo" << std::endl;
      //  v2xobj->Post_CarInfo(postcarinfovec);
    }
     std::cout << "Post_CarInfo end " << std::endl;
    nowabnormaltype.clear();

}


void jason_trackingcarcheck_continuous()
{
    map<int,CAR_CENTERTRACKING>::iterator mapit =  trackingmap.begin();
    for(; mapit != trackingmap.end() ; mapit++)
    {
      //  std::cout << "trackingmap.end()" << std::endl;
      //   std::cout << "mapit->second.istate" << mapit->second.istate <<  std::endl;
        if(mapit->second.istate == 1 || mapit->second.istate == 2 )
        {
            continue;
        }
        CAR_CENTERTRACKING tempcarinfo =    mapit->second;
        pcl::PointCloud<pcl::PointXYZRGBA> trackcarpoint;

        float maxpointx = -std::numeric_limits<float>::max();
        float maxpointy = -std::numeric_limits<float>::max();
        float maxpointz = -std::numeric_limits<float>::max();

        float minpointx = std::numeric_limits<float>::max();
        float minpointy = std::numeric_limits<float>::max();
        float minpointz = std::numeric_limits<float>::max();
        float centerpointx = 0.0;
        float centerpointy = 0.0;
        float centerpointz = 0.0;

        float fdistance = tempcarinfo.fspeed * 1000 / 3600 / 10;
        std::cout << "fdistancefdistance " << fdistance <<  std::endl;

       centerpointz =  mapit->second.centerz + fdistance;
       centerpointx =  mapit->second.centerx ;
       centerpointy =  mapit->second.centery;
       if(mHostIP == "10.191.185.171")
       {
          if(centerpointz > 170 && centerpointz < 240)
          {
              double delta,p,q,x1,x2;

              delta=6.7862 * 6.7862 -(4*-0.4639*(219.44 - centerpointz)) ;
              p=-6.7862/(2*-0.4639);

              q=sqrt(fabs(delta))/(2*-0.4639);
              x1 = p+q;
              x2 = p-q;
             // std::cout << "fx " << onepoint.x << std::endl;
            //  std::cout << "x1 " << x1 << std::endl;
            //  std::cout << "x2 " << x2 << std::endl;
            //  std::cout << "z1 " << onepoint.z << std::endl;
              if(abs(x1 - istartx) > abs(x2 -istartx))
              {
                 centerpointx =  centerpointx + abs(istartx - x2);
              }
              else
              {
                   centerpointx = centerpointx + abs(istartx - x1);
              }
               centerpointx-=ioffsetxx;
          }
       }


       mapit->second.centerz = centerpointz;
       if(mapit->second.centerz > 240)
       {
           mapit->second.istate = 2;
           continue;
       }


           pcl::PointXYZ maxpoint = Jason_restorerotating_groud(maxpointx,maxpointy,maxpointz);
           pcl::PointXYZ minpoint = Jason_restorerotating_groud(minpointx,minpointy,minpointz);






            CAR_INFO onecarinfo;


           onecarinfo =  resinfomap[tempcarinfo.objid] ;
           char carid[100] = "";


           QFile file("./tracking.txt");
           file.open(QIODevice::ReadWrite | QIODevice::Text | QIODevice::Append);





           sprintf(carid,"trackingid=%d,L,W,H=(%.2f,%.2f,%.2f),s=%2.fKM/H,D=%.2f",tempcarinfo.objid,onecarinfo.flenth,onecarinfo.fwidth,onecarinfo.fheight,onecarinfo.fSpeed,centerpointz);

           file.write(carid);
           file.close();

           QString qsid = carid;
           QString qstext = carid;

           QString qscarid = carid;

           qscarid += "test";
           QString qstextid = qscarid;




            maxpoint.x = centerpointx + onecarinfo.fwidth /2 ;
            maxpoint.y = centerpointy + onecarinfo.fheight /2 ;
            maxpoint.z = centerpointz + onecarinfo.flenth /2 ;
            minpoint.x = centerpointx - onecarinfo.fwidth /2 ;
            minpoint.y = centerpointy - onecarinfo.fheight /2 ;
            minpoint.z = centerpointz - onecarinfo.flenth /2 ;
         




    }



    testcloud_.clear();
}

void Jason_CalculatedSize_Into()
{
   
    nowcarcenter.clear();

    if(testcloud_.size()== 0)
    {
        return ;
    }

    memset(carmark,0,sizeof(carmark));
    iCarMark = 0;

    memset(aftercarinfo, 0, sizeof(aftercarinfo));
    aftersize = 0;

    for (size_t i = 0; i < fileidnumber; i++)
    {
        //emit mPviewer->JasonDelCube_SIG(fileidarray[i]);
    }

    fileidnumber = 0;

        for (size_t i = 0; i < filetextidnumber; i++)
        {
           // emit mPviewer->JasonDelCube_SIG(filetextidarray[i]);
        }

        filetextidnumber = 0;



        QString dir_str = ".//savesourcepcd";

        // 检查目录是否存在，若不存在则新建
        QDir dir;
        if (!dir.exists(dir_str))
        {
         bool res = dir.mkpath(dir_str);


        }



#if 1
    if (!isReadCarSize)
    {
       // QFile file1("carsize.txt");
        ifstream inFile("carsize.txt");
        //打开文件,只读的方式
        //bool isOk = file1.open(QIODevice::ReadOnly);


            while (!inFile.eof())
            {
                //读一行
                string buffTmp;
                getline(inFile, buffTmp);//读取第一行
                if(buffTmp.size() == 0)
                {
                    break;
                }
                float fvalue = stof(buffTmp);
                carsize[iCarSize].x = fvalue;




                getline(inFile, buffTmp);//读取第一行
                if(buffTmp.size() == 0)
                {
                    break;
                }

                fvalue = stof(buffTmp);
                carsize[iCarSize].y = fvalue;

                getline(inFile, buffTmp);//读取第一行
                if(buffTmp.size() == 0)
                {
                    break;
                }

                fvalue = stof(buffTmp);
                carsize[iCarSize].z = fvalue;
              //  printf("%f %f %f \n",carsize[iCarSize].x,carsize[iCarSize].y,carsize[iCarSize].z);


                iCarSize++;


            }
            inFile.close();

        isReadCarSize = true;

    }
#endif


#if 1




    pcl::copyPointCloud(testcloud_, *(JasonCloud));
   // jasonPIX_ROW = testPIX_ROW;

    char fpsfileName1[100] = "";
    sprintf(fpsfileName1,".//savesourcepcd//fpsstart%d.pcd",iFps);
    pcl::io::savePCDFileASCII(fpsfileName1, *(JasonCloud));

 //   std::cout << "11111111: " << jason_current_timestamp()  << "size "<<    JasonCloud->size() << std::endl;

/*

    */


#if 1
    // 建立kd-tree对象用来搜索 .
    pcl::search::KdTree<pcl::PointXYZRGBA>::Ptr kdtree(new pcl::search::KdTree<pcl::PointXYZRGBA>);
    kdtree->setInputCloud(JasonCloud);

    // Euclidean 聚类对象.
    pcl::EuclideanClusterExtraction<pcl::PointXYZRGBA> clustering;
    // 设置聚类的最小值 2cm (small values may cause objects to be divided
    // in several clusters, whereas big values may join objects in a same cluster).
    clustering.setClusterTolerance(0.5);
    // 设置聚类的小点数和最大点云数
    clustering.setMinClusterSize(50);
    clustering.setMaxClusterSize(5000);
    clustering.setSearchMethod(kdtree);
    clustering.setInputCloud(JasonCloud);
    std::vector<pcl::PointIndices> clusters;
    clustering.extract(clusters);

  //  std::cout << "22222222: " << jason_current_timestamp()  << std::endl;

  //  std::cout << "3333333333: " << clusters.size() << "iFps" << iFps << std::endl;

    typedef pcl::PointXYZ PointType;
    int currentClusterNum = 1;

    nowframe.clear();

    std::string prefilename;




    vector<OBJINFO> vectempobjinfo;
    vector<int> vectempobjidinfo;

    for (std::vector<pcl::PointIndices>::const_iterator i = clusters.begin(); i != clusters.end(); ++i)
    {





        pcl::PointCloud<PointType>::Ptr cloud(new pcl::PointCloud<PointType>());
        //添加所有的点云到一个新的点云中
        pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cluster(new pcl::PointCloud<pcl::PointXYZRGBA>);

        float centerpointx = 0.0;
        float centerpointy = 0.0;
        float centerpointz = 0.0;

        float maxpointx = -std::numeric_limits<float>::max();
        float maxpointy = -std::numeric_limits<float>::max();
        float maxpointz = -std::numeric_limits<float>::max();

        float minpointx = std::numeric_limits<float>::max();;
        float minpointy = std::numeric_limits<float>::max();;
        float minpointz = std::numeric_limits<float>::max();;

        int avgcol = 0;
        int avgrow = 0;




        for (std::vector<int>::const_iterator point = i->indices.begin(); point != i->indices.end(); point++)
        {

            cluster->points.push_back(JasonCloud->points[*point]);
         //   avgcol  += jasonPIX_ROW[*point].pixcol;
         //   avgrow  += jasonPIX_ROW[*point].row;
            pcl::PointXYZ pointdata;
            pointdata.x = JasonCloud->points[*point].x;
            pointdata.y = JasonCloud->points[*point].y;
            pointdata.z = JasonCloud->points[*point].z;
            cloud->push_back(pointdata);

            centerpointx += pointdata.x;
            centerpointy += pointdata.y;
            centerpointz += pointdata.z;

            if (pointdata.x < minpointx)
                minpointx = pointdata.x;
            if (pointdata.y < minpointy)
                minpointy = pointdata.y;
            if (pointdata.z < minpointz)
                minpointz = pointdata.z;
            if (pointdata.x > maxpointx)
                maxpointx = pointdata.x;
            if (pointdata.y > maxpointy)
                maxpointy = pointdata.y;
            if (pointdata.z > maxpointz)
                maxpointz = pointdata.z;



        }

        cluster->width = cluster->points.size();
        cluster->height = 1;
        cluster->is_dense = true;

        // 保存
        if (cluster->points.size() <= 0)
            break;


        centerpointx = centerpointx / cluster->points.size();
        centerpointy = centerpointy / cluster->points.size();
        centerpointz = centerpointz / cluster->points.size();

        if(centerpointz > 70)
        {
            continue;
        }
       // avgcol  /= cluster->points.size();
      //  avgrow  /= cluster->points.size();


        char fileName[100] = "";
        char fileNameTrans[100] = "";
        sprintf(fileName,".//savesourcepcd//fps_%d_cluster%d.pcd",iFps,currentClusterNum);
        sprintf(fileNameTrans,".//savesourcepcd//fps_%d_trans_cluster%d.pcd",iFps,currentClusterNum);


       pcl::io::savePCDFileASCII(fileName, *cluster);


        OBJINFO nowobjinfo;
        memset(&nowobjinfo,0,sizeof(OBJINFO));
        nowobjinfo.centerx = centerpointx;
        nowobjinfo.centery = centerpointy;
        nowobjinfo.centerz = centerpointz;
        nowobjinfo.maxx = maxpointx;
        nowobjinfo.maxy = maxpointy;
        nowobjinfo.maxz = maxpointz;
        nowobjinfo.minx = minpointx;
        nowobjinfo.miny = minpointy;
        nowobjinfo.minz = minpointz;
        nowobjinfo.objtype = NOTID;
        nowobjinfo.filename = fileName;
        nowobjinfo.col =  1800 - avgcol;
        nowobjinfo.row =  600 - avgrow;
        nowobjinfo.lenth = maxpointz - minpointz;
        nowobjinfo.width = maxpointx - minpointx;
        nowobjinfo.height = maxpointy - minpointy;


        QFile file("./cattest.txt");
        file.open(QIODevice::ReadWrite | QIODevice::Text | QIODevice::Append);
        char buf[1024] =  "";
        sprintf(buf,"filename = %s max=%f may=%f maz=%f mix=%f miy=%f miz=%f cenx=%f ceny=%f cenz=%f \n\r",\
        fileName,nowobjinfo.maxx,nowobjinfo.maxy,nowobjinfo.maxz,nowobjinfo.minx,nowobjinfo.miny,nowobjinfo.minz,\
         nowobjinfo.centerx,nowobjinfo.centery,nowobjinfo.centerz);
        file.write(buf);
        file.close();

        vectempobjidinfo.push_back(currentClusterNum);
        currentClusterNum++;
        vectempobjinfo.push_back(nowobjinfo);
    }
    map<int,OBJINFO> mapkeyobj;
    vector<OBJINFO> vecobjinfo;
    std::cout << "vectempobjinfo.size() " << vectempobjinfo.size() << std::endl;

    if(vectempobjinfo.size() <= 1)
    {
        vecobjinfo = vectempobjinfo;
    }
    else
    {

     for(int i = 0 ; i < vectempobjinfo.size() ;i++)
      {
         bool isCheck = false;
         OBJINFO nowobjinfo = vectempobjinfo[i];

            for(int j = i + 1 ; j < vectempobjinfo.size();j++)
            {
                OBJINFO tempobjinfo = vectempobjinfo[j];
                if( (abs(tempobjinfo.centerx - nowobjinfo.centerx) <= 1.5) && (abs(tempobjinfo.centerz- nowobjinfo.centerz) <= 20.0) )
                {
                   if(     vectempobjidinfo[j] !=  vectempobjidinfo[i] )
                   {
                          vectempobjidinfo[j] =  vectempobjidinfo[i];
                   }
                   else
                   {
                       continue;
                   }


                   if(mapkeyobj.count( vectempobjidinfo[i]) == 0)
                   {

                       OBJINFO newobjinfo;
                       memset(&newobjinfo,0,sizeof(OBJINFO));
                       newobjinfo.centerx = (nowobjinfo.centerx + tempobjinfo.centerx)/2;
                       newobjinfo.centery = (nowobjinfo.centery + tempobjinfo.centery)/2;
                       newobjinfo.centerz = (nowobjinfo.centerz + tempobjinfo.centerz)/2;
                       newobjinfo.maxx = (nowobjinfo.maxx > tempobjinfo.maxx ?nowobjinfo.maxx : tempobjinfo.maxx);
                       newobjinfo.maxy =  (nowobjinfo.maxy > tempobjinfo.maxy ?nowobjinfo.maxy : tempobjinfo.maxy);
                       newobjinfo.maxz =  (nowobjinfo.maxz > tempobjinfo.maxz ?nowobjinfo.maxz : tempobjinfo.maxz);
                       newobjinfo.minx = (nowobjinfo.minx > tempobjinfo.minx ? tempobjinfo.minx :nowobjinfo.minx );
                       newobjinfo.miny =(nowobjinfo.miny > tempobjinfo.miny ? tempobjinfo.miny :nowobjinfo.miny );
                       newobjinfo.minz =(nowobjinfo.minz > tempobjinfo.minz ? tempobjinfo.minz :nowobjinfo.minz );
                       newobjinfo.objtype = NOTID;
                       newobjinfo.filename = nowobjinfo.filename;
                       newobjinfo.col =   (nowobjinfo.col + tempobjinfo.col)/2;
                       newobjinfo.row =  (nowobjinfo.row + tempobjinfo.row)/2;
                       newobjinfo.lenth = newobjinfo.maxz -  newobjinfo.minz;// (nowobjinfo.lenth + tempobjinfo.lenth)/2;
                       newobjinfo.width = newobjinfo.maxx -  newobjinfo.minx;//(nowobjinfo.width + tempobjinfo.width)/2;
                       newobjinfo.height = newobjinfo.maxy -  newobjinfo.miny ;//(nowobjinfo.height + tempobjinfo.height)/2;
                       mapkeyobj[vectempobjidinfo[i]] = newobjinfo;
                       isCheck = true;
                        /*
                        std::cout << "tempobjinfo.maxx " << tempobjinfo.maxx << std::endl;
                        std::cout << "tempobjinfo.maxy " << tempobjinfo.maxy << std::endl;
                        std::cout << "tempobjinfo.maxz " << tempobjinfo.maxz << std::endl;
                        std::cout << "nowobjinfo.maxx " << nowobjinfo.maxx << std::endl;
                        std::cout << "nowobjinfo.maxy " << nowobjinfo.maxy << std::endl;
                        std::cout << "nowobjinfo.maxz " << nowobjinfo.maxz << std::endl;
                        std::cout << "tempobjinfo.minx " << tempobjinfo.minx << std::endl;
                        std::cout << "tempobjinfo.miny " << tempobjinfo.miny << std::endl;
                        std::cout << "tempobjinfo.minz " << tempobjinfo.minz << std::endl;
                        std::cout << "nowobjinfo.minx " << nowobjinfo.minx << std::endl;
                        std::cout << "nowobjinfo.miny " << nowobjinfo.miny << std::endl;
                        std::cout << "nowobjinfo.minz " << nowobjinfo.minz << std::endl;
                        */

                   }
                   else
                   {
                        OBJINFO mapobjinfo = mapkeyobj[vectempobjidinfo[i]];
                        OBJINFO newobjinfo;
                        memset(&newobjinfo,0,sizeof(OBJINFO));
                        newobjinfo.centerx = (mapobjinfo.centerx + tempobjinfo.centerx)/2;
                        newobjinfo.centery = (mapobjinfo.centery + tempobjinfo.centery)/2;
                        newobjinfo.centerz = (mapobjinfo.centerz + tempobjinfo.centerz)/2;
                        newobjinfo.maxx = (mapobjinfo.maxx > tempobjinfo.maxx ?mapobjinfo.maxx : tempobjinfo.maxx);
                        newobjinfo.maxy =  (mapobjinfo.maxy > tempobjinfo.maxy ?mapobjinfo.maxy : tempobjinfo.maxy);
                        newobjinfo.maxz =  (mapobjinfo.maxz > tempobjinfo.maxz ?mapobjinfo.maxz : tempobjinfo.maxz);
                        newobjinfo.minx = (mapobjinfo.minx > tempobjinfo.minx ? tempobjinfo.minx :mapobjinfo.minx );
                        newobjinfo.miny =(mapobjinfo.miny > tempobjinfo.miny ? tempobjinfo.miny :mapobjinfo.miny );
                        newobjinfo.minz =(mapobjinfo.minz > tempobjinfo.minz ? tempobjinfo.minz :mapobjinfo.minz );
                        newobjinfo.objtype = NOTID;
                        newobjinfo.filename = mapobjinfo.filename;
                        newobjinfo.col =   (mapobjinfo.col + tempobjinfo.col)/2;
                        newobjinfo.row =  (mapobjinfo.row + tempobjinfo.row)/2;
                        newobjinfo.lenth =  newobjinfo.maxz -  newobjinfo.minz;// (mapobjinfo.lenth + tempobjinfo.lenth)/2;
                        newobjinfo.width = newobjinfo.maxx -  newobjinfo.minx ;//(mapobjinfo.width + tempobjinfo.width)/2;
                        newobjinfo.height = newobjinfo.maxy -  newobjinfo.miny ;//(mapobjinfo.height + tempobjinfo.height)/2;
                        mapkeyobj[vectempobjidinfo[i]] = newobjinfo;
                        isCheck = true;
                     /*
                        std::cout << "tempobjinfo.maxx " << tempobjinfo.maxx << std::endl;
                        std::cout << "tempobjinfo.maxy " << tempobjinfo.maxy << std::endl;
                        std::cout << "tempobjinfo.maxz " << tempobjinfo.maxz << std::endl;
                        std::cout << "mapobjinfo.maxx " << mapobjinfo.maxx << std::endl;
                        std::cout << "mapobjinfo.maxy " << mapobjinfo.maxy << std::endl;
                        std::cout << "mapobjinfo.maxz " << mapobjinfo.maxz << std::endl;
                        std::cout << "tempobjinfo.minx " << tempobjinfo.minx << std::endl;
                        std::cout << "tempobjinfo.miny " << tempobjinfo.miny << std::endl;
                        std::cout << "tempobjinfo.minz " << tempobjinfo.minz << std::endl;
                        std::cout << "mapobjinfo.minx " << mapobjinfo.minx << std::endl;
                        std::cout << "mapobjinfo.miny " << mapobjinfo.miny << std::endl;
                        std::cout << "mapobjinfo.minz " << mapobjinfo.minz << std::endl;
                        */

                   }




               // vecobjinfo.push_back(newobjinfo);


                }
              }

            if(isCheck == false)
            {
                  if( mapkeyobj.count( vectempobjidinfo[i]) == 0)
                  {
                       mapkeyobj[vectempobjidinfo[i]] = nowobjinfo;
                  }

            }



        }
    }

   map<int,OBJINFO>::iterator iter;//定义一个迭代指针iter
  for(iter=mapkeyobj.begin(); iter!=mapkeyobj.end(); iter++)
  {
       vecobjinfo.push_back(iter->second);
       /*
       std::cout << "lenth " << iter->second.lenth << std::endl;
       std::cout << "width " << iter->second.width << std::endl;
       std::cout << "height " << iter->second.height << std::endl;
       std::cout << "maxx " << iter->second.maxx << std::endl;
       std::cout << "maxy " << iter->second.maxy << std::endl;
       std::cout << "maxz " << iter->second.maxz << std::endl;
       std::cout << "minx " << iter->second.minx << std::endl;
       std::cout << "miny " << iter->second.miny << std::endl;
       std::cout << "minz " << iter->second.minz << std::endl;
       */
  }

    std::cout << "vecobjinfosizoe " << vecobjinfo.size() << std::endl;

///////////////////////////////////////////////////////
      for(int iobjsize = 0 ; iobjsize < vecobjinfo.size() ;iobjsize++ )
      {
         OBJINFO nowobjinfo = vecobjinfo[iobjsize];
        if(preframe.size() == 0)
        {

            nowframe.push_back(nowobjinfo);
          //  currentClusterNum++;
            continue;
        }
        else
        {
            int preobjid;
            int index = -1;

            float fAbdistance = std::numeric_limits<float>::max();;;
            for(int i = 0 ; i < preframe.size() ;i++ )
            {
                OBJINFO tempinfo = preframe[i];
                float distanceX = tempinfo.centerx - nowobjinfo.centerx;
                float distanceY = tempinfo.centery - nowobjinfo.centery;
                float distanceZ = tempinfo.centerz - nowobjinfo.centerz;
                float tempdistacne = pow(distanceX,2) + pow(distanceY,2) + pow(distanceZ,2);
                tempdistacne = sqrt(tempdistacne);

                if(abs(distanceX) > 1.5)
                {
                    continue;
                }
                if(fAbdistance > tempdistacne )
                {
                    fAbdistance = tempdistacne;
                    index = i;
                    preobjid = tempinfo.objtype;
                }


            }
            if(index == -1)
            {
                continue;
            }








            prefilename = preframe[index].filename;
            std::cout << "prefilename " << prefilename << std::endl;
            float nowdistanceX = nowobjinfo.centerx - preframe[index].centerx;
            float nowdistanceY = nowobjinfo.centery - preframe[index].centery;
            float nowdistanceZ = nowobjinfo.centerz - preframe[index].centerz;

            nowobjinfo.fspeed = fAbdistance * 10 * 3600 / 1000.0;

             std::cout << "nowobjinfo.fspeed " <<nowobjinfo.fspeed <<  std::endl;
            if(nowobjinfo.fspeed > 1 /*&& nowobjinfo.width >1.0*/ )
            {

                {


                    int diffcol = preframe[index].col - nowobjinfo.col;
                    int diffrow = preframe[index].row - nowobjinfo.row;












                    if(preframe[index].objtype == CAR || preframe[index].objtype == LARGETRUCK)
                    {
                            nowobjinfo.id =preframe[index].id;
#if 1
 // 1.5 ~ 1.8 // 4.4 ~ 5 // 1.6~1.8
                            if(nowobjinfo.lenth <= preframe[index].lenth)
                            {
                                nowobjinfo.lenth = preframe[index].lenth;



                            }
                            nowobjinfo.maxz = (nowobjinfo.lenth /2) + nowobjinfo.centerz  ;
                            nowobjinfo.minz =  nowobjinfo.centerz - (nowobjinfo.lenth /2)  ;
                            if(nowobjinfo.width <= preframe[index].width)
                            {
                                nowobjinfo.width = preframe[index].width;




                            }
                            nowobjinfo.maxx = (nowobjinfo.width /2) + nowobjinfo.centerx  ;
                            nowobjinfo.minx =  nowobjinfo.centerx - (nowobjinfo.width /2)  ;
                            if(nowobjinfo.height <= preframe[index].height)
                            {
                                nowobjinfo.height = preframe[index].height;





                            }
                            nowobjinfo.maxy = (nowobjinfo.height /2) + nowobjinfo.centery  ;
                            nowobjinfo.miny =  nowobjinfo.centery - (nowobjinfo.height /2)  ;


                         //   printf("maxz = %f minz = %f \n ",nowobjinfo.maxz,nowobjinfo.minz);
#endif

                    }
                    else
                     {

#if 1

                       // carcentertracking.objid = nowobjinfo.id;
                        //carcentertracking.centerx = nowobjinfo.centerx;
                       // carcentertracking.centery = nowobjinfo.centery;
                       // carcentertracking.centerz = nowobjinfo.centerz;
                       // carcentertracking.istate = 1;
                        std::cout << "globalobjid " << globalobjid << std::endl;
                        std::cout << "trackingmap.count(globalobjid - 1)  " << trackingmap.count(globalobjid - 1) << std::endl;
                        if(trackingmap.count(globalobjid - 1) > 0)
                        {
                            CAR_CENTERTRACKING carcentertracking= trackingmap[globalobjid - 1];
                            std::cout << "carcentertracking.centerz - nowobjinfo.centerz" << carcentertracking.centerz - nowobjinfo.centerz <<  std::endl;
                            if(abs(carcentertracking.centerz - nowobjinfo.centerz) < 10 || (abs(carcentertracking.centerx - nowobjinfo.centerx) < 1 && abs(carcentertracking.centerz - nowobjinfo.centerz) < 30)   )
                            {
                                nowobjinfo.objtype = NOTID;
                                 continue;
                            }
                        }

#endif


                          nowobjinfo.id = globalobjid++;
                          CAR_CENTER carcenter;
                          pcl::PointXYZ respoint = Jason_restorerotating_groud(nowobjinfo.centerx,nowobjinfo.centery,nowobjinfo.centerz);
                          carcenter.objid = nowobjinfo.id;
                          carcenter.centerx = respoint.x;
                          carcenter.centery = respoint.y;
                          carcenter.centerz = respoint.z;
                          nowcarcenter.push_back(carcenter);
        /*
                          CAR_CENTERTRACKING carcentertracking;
                          carcentertracking.objid = nowobjinfo.id;
                          carcentertracking.centerx = respoint.x;
                          carcentertracking.centery = respoint.y;
                          carcentertracking.centerz = respoint.z;
                          carcentertracking.istate = 1;
                          trackingmap[nowobjinfo.id] = carcentertracking;
*/




                     }
                    if(nowobjinfo.lenth > 8.0)
                    {
                         nowobjinfo.objtype = LARGETRUCK;
                    }
                    else
                    {
                         nowobjinfo.objtype = CAR;
                    }






                }
            }
            else
            {
                nowobjinfo.objtype = NOTID;
            }

        }










        if(nowobjinfo.objtype == CAR ||nowobjinfo.objtype == LARGETRUCK )
        {

             nowframe.push_back(nowobjinfo);
            char textname[100] = "";
            char text[100] = "";
            char carid[20] = "";
            sprintf(carid,"%d",nowobjinfo.id);
            sprintf(text,"id=%d,L,W,H=(%.2f,%.2f,%.2f),s=%2.fKM/H,D=%.2f",nowobjinfo.id,nowobjinfo.lenth,nowobjinfo.width,nowobjinfo.height,nowobjinfo.fspeed,nowobjinfo.maxz);
            sprintf(textname,"%s.text",nowobjinfo.filename.c_str());
            std::cout << "text ==== " << text << std::endl;
            QString qsid = nowobjinfo.filename.c_str();
            QString qstext = text;
            QString qstextid = textname;
            QString qscarid = carid;

            pcl::PointXYZ maxpoint = Jason_restorerotating_groud(nowobjinfo.maxx,nowobjinfo.maxy,nowobjinfo.maxz);
            pcl::PointXYZ minpoint = Jason_restorerotating_groud(nowobjinfo.minx,nowobjinfo.miny,nowobjinfo.minz);



          

            carinfomap[nowobjinfo.id].push_back(nowobjinfo);
            nowframeid.push_back(nowobjinfo.id);

            CAR_CENTERTRACKING carcentertracking;
            carcentertracking.objid = nowobjinfo.id;
            carcentertracking.centerx = nowobjinfo.centerx;
            carcentertracking.centery = nowobjinfo.centery;
            carcentertracking.centerz = nowobjinfo.centerz;
            carcentertracking.istate = 1;
            carcentertracking.iframe = 0;
            carcentertracking.fspeed = nowobjinfo.fspeed;
            trackingmap[nowobjinfo.id] = carcentertracking;

          //  std::cout << "lane " << nowobjinfo.centerx << std::endl;


        }
      }
//////////////////////////////////////




 #endif

  //  send_objinfo();
   // Jason_average_statistics();
    preframeid.clear();
    preframeid = nowframeid;
    nowframeid.clear();
    iFps++;



    memcpy(beforecarinfo,aftercarinfo, sizeof(aftercarinfo));
    beforesize = aftersize;

    testcloud_.clear();
    testPIX_ROW.clear();


    preframe.clear();

    preframe.swap(nowframe);



    #endif
}

void Jason_TrackingAdd(pcl::PointXYZRGBA OnePoint)
{
     Trackingtestcloud_.push_back(OnePoint);
}

void Jason_TrackingCalculatedSize()
{
   

    if(Trackingtestcloud_.size() == 0)
    {
        if(allwebinfo.size() > 0)
        {
           // v2xobj->Post_CarInfo(allwebinfo);
            postcarinfolist.push_back(allwebinfo);
        }
        return ;
    }
    pcl::copyPointCloud(Trackingtestcloud_, *(TrackingJasonCloud));
   // jasonPIX_ROW = testPIX_ROW;

    char fpsfileName1[100] = "";
    sprintf(fpsfileName1,".//savesourcepcd//fpsstart%d.pcd",iTrackingFps);
//    pcl::io::savePCDFileASCII(fpsfileName1, *(TrackingJasonCloud));


#if 1
    // 建立kd-tree对象用来搜索 .
    pcl::search::KdTree<pcl::PointXYZRGBA>::Ptr kdtree(new pcl::search::KdTree<pcl::PointXYZRGBA>);
    kdtree->setInputCloud(TrackingJasonCloud);

    // Euclidean 聚类对象.
    pcl::EuclideanClusterExtraction<pcl::PointXYZRGBA> clustering;
    // 设置聚类的最小值 2cm (small values may cause objects to be divided
    // in several clusters, whereas big values may join objects in a same cluster).
    clustering.setClusterTolerance(0.5);
    // 设置聚类的小点数和最大点云数
    clustering.setMinClusterSize(10);
    clustering.setMaxClusterSize(10000);
    clustering.setSearchMethod(kdtree);
    clustering.setInputCloud(TrackingJasonCloud);
    std::vector<pcl::PointIndices> clusters;
    clustering.extract(clusters);



    typedef pcl::PointXYZ PointType;
    int currentClusterNum = 1;


    std::vector<OBJINFO> tempclustframe;

    for (std::vector<pcl::PointIndices>::const_iterator i = clusters.begin(); i != clusters.end(); ++i)
    {





        pcl::PointCloud<PointType>::Ptr cloud(new pcl::PointCloud<PointType>());
        //添加所有的点云到一个新的点云中
        pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cluster(new pcl::PointCloud<pcl::PointXYZRGBA>);

        float centerpointx = 0.0;
        float centerpointy = 0.0;
        float centerpointz = 0.0;

        float maxpointx = -std::numeric_limits<float>::max();
        float maxpointy = -std::numeric_limits<float>::max();
        float maxpointz = -std::numeric_limits<float>::max();

        float minpointx = std::numeric_limits<float>::max();;
        float minpointy = std::numeric_limits<float>::max();;
        float minpointz = std::numeric_limits<float>::max();;

        int avgcol = 0;
        int avgrow = 0;




        for (std::vector<int>::const_iterator point = i->indices.begin(); point != i->indices.end(); point++)
        {

            cluster->points.push_back(TrackingJasonCloud->points[*point]);
         //   avgcol  += jasonPIX_ROW[*point].pixcol;
         //   avgrow  += jasonPIX_ROW[*point].row;
            pcl::PointXYZ pointdata;
            pointdata.x = TrackingJasonCloud->points[*point].x;
            pointdata.y = TrackingJasonCloud->points[*point].y;
            pointdata.z = TrackingJasonCloud->points[*point].z;
            cloud->push_back(pointdata);

            centerpointx += pointdata.x;
            centerpointy += pointdata.y;
            centerpointz += pointdata.z;

            if (pointdata.x < minpointx)
                minpointx = pointdata.x;
            if (pointdata.y < minpointy)
                minpointy = pointdata.y;
            if (pointdata.z < minpointz)
                minpointz = pointdata.z;
            if (pointdata.x > maxpointx)
                maxpointx = pointdata.x;
            if (pointdata.y > maxpointy)
                maxpointy = pointdata.y;
            if (pointdata.z > maxpointz)
                maxpointz = pointdata.z;



        }

        cluster->width = cluster->points.size();
        cluster->height = 1;
        cluster->is_dense = true;

        // 保存
        if (cluster->points.size() <= 0)
            break;


        centerpointx = centerpointx / cluster->points.size();
        centerpointy = centerpointy / cluster->points.size();
        centerpointz = centerpointz / cluster->points.size();


        char fileName[100] = "";
        char fileNameTrans[100] = "";
        sprintf(fileName,".//savesourcepcd//fps_%d_cluster%d.pcd",iTrackingFps,currentClusterNum);
        sprintf(fileNameTrans,".//savesourcepcd//fps_%d_trans_cluster%d.pcd",iTrackingFps,currentClusterNum);


        OBJINFO tempinfo;
        tempinfo.centerx = centerpointx;
        tempinfo.centery = centerpointy;
        tempinfo.centerz = centerpointz;
        tempinfo.maxx = maxpointx;
        tempinfo.maxy = maxpointy;
        tempinfo.maxz = maxpointz;
        tempinfo.minx = minpointx;
        tempinfo.miny = minpointy;
        tempinfo.minz = minpointz;


        tempclustframe.push_back(tempinfo);



        /*

        int index = Jason_DetectionTrackingDraw(centerpointx,centerpointy,centerpointz);
        if(index != -1)
        {

        Trackingframe[index].centerx = centerpointx;
        Trackingframe[index].centery = centerpointy;
        Trackingframe[index].centerz = centerpointz;
        Trackingframe[index].maxx = maxpointx;
        Trackingframe[index].maxy = maxpointy;
        Trackingframe[index].maxz = maxpointz;
        Trackingframe[index].minx = minpointx;
        Trackingframe[index].miny = minpointy;
        Trackingframe[index].minz = minpointz;

        Trackingdrawframe.push_back(Trackingframe[index]);
        }
        */
        currentClusterNum++;


      }

      std::cout << "test 00000000000000000000" << std::endl;
    Jason_DetectionTrackingDraw(tempclustframe);
   // vector<POSTCAR_INFO> allwebinfo;
    for(int i = 0 ; i < Trackingdrawframe.size() ;i++)
    {
        std::cout << "Jason_TrackingCalculatedSize id " << Trackingdrawframe[i].id << std::endl;
      //  Trackingdrawframe[i].istamp = istampnum;

        ONEOBJECT objdata;
        objdata.objdistance = Trackingdrawframe[i].centerz;
        objdata.objDirectionAngle = 0.0;
        objdata.x = Trackingdrawframe[i].centerx;
        objdata.y = Trackingdrawframe[i].centery;
        objdata.width = Trackingdrawframe[i].width;
        objdata.lenth = Trackingdrawframe[i].lenth;
        objdata.speed = Trackingdrawframe[i].fspeed;
        objdata.id = Trackingdrawframe[i].id;
        objdata.lane = Trackingdrawframe[i].lane;
       // char sendbufdata[44] = "";
     //   datatochar(objdata,sendbufdata);
       // jason_SocketSendObject(sendbufdata,43);
        //////////////////V2X WEB
        POSTCAR_INFO postcarinfo;
        postcarinfo.car_id = Trackingdrawframe[i].id;
        if(Trackingdrawframe[i].lenth > 8)
        {

                 postcarinfo.classtype  = LARGETRUCK;



        }
        else
        {
            postcarinfo.classtype  = CAR;
        }
        //postcarinfo.classtype = 1;

        char timetmps[30] = "";
        sprintf(timetmps,"%ld", globaltimesec);
        char timetmpu[30] = "";
        sprintf(timetmpu,"%ld", globaltimeusec);

        strcpy(postcarinfo.timestamps, timetmps);
        strcpy(postcarinfo.timestampu, timetmpu);
        postcarinfo.lidar_id = v2xobj.ladar_id;
        postcarinfo.length = Trackingdrawframe[i].lenth;
        postcarinfo.width = Trackingdrawframe[i].width;
        postcarinfo.height = Trackingdrawframe[i].height;
        strcpy(postcarinfo.pic_url, "123123123");
        strcpy(postcarinfo.pcd_url, "123123123");
        postcarinfo.pos_x = Trackingdrawframe[i].centerx;
        postcarinfo.pos_y = Trackingdrawframe[i].centery;
        postcarinfo.pos_z = Trackingdrawframe[i].maxz;
        postcarinfo.speed =  Trackingdrawframe[i].fspeed;
        postcarinfo.local_id = v2xobj.local_id;
        postcarinfo.lane = Trackingdrawframe[i].lane;
        strcpy(postcarinfo.abnormal_type,"");
       // postcarinfo.lane = nowframe[i].lane;
        strcpy(postcarinfo.origentation, "N");
      //  ExceptionEventJudgment(postcarinfo);
        allwebinfo.push_back(postcarinfo);


        /////



       // V2X_SendObjInfoDraw(Trackingdrawframe[i]);
    }

    Trackingdrawframe.clear();
    iTrackingFps++;

    std::cout << "test 11111111111111111111111111111111111" << std::endl;

    jason_FuzzyTrackingDraw();
    std::cout << "test kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk" << std::endl;
   // vector<POSTCAR_INFO> Fuzzywebinfo;
    for(int i = 0 ; i < FuzzyTrackingframe.size() ;i++)
    {
        if(FuzzyTrackingframe[i].id != -1)
        {
          //  std::cout << "FuzzyTrackingframe " <<FuzzyTrackingframe[i].id <<std::endl;
        //    FuzzyTrackingframe[i].istamp = istampnum;

            ONEOBJECT objdata;
            objdata.objdistance = FuzzyTrackingframe[i].centerz;
            objdata.objDirectionAngle = 0.0;
            objdata.x = FuzzyTrackingframe[i].centerx;
            objdata.y = FuzzyTrackingframe[i].centery;
            objdata.width = FuzzyTrackingframe[i].width;
            objdata.lenth = FuzzyTrackingframe[i].lenth;
            objdata.speed = FuzzyTrackingframe[i].fspeed;
            objdata.id = FuzzyTrackingframe[i].id;
            objdata.lane = FuzzyTrackingframe[i].lane;
           // char sendbufdata[44] = "";
            //datatochar(objdata,sendbufdata);
           // jason_SocketSendObject(sendbufdata,43);

            //////////////////V2X WEB
            POSTCAR_INFO postcarinfo;
            postcarinfo.car_id = FuzzyTrackingframe[i].id;
            if(FuzzyTrackingframe[i].lenth > 8)
            {

                     postcarinfo.classtype  = LARGETRUCK;



            }
            else
            {
                postcarinfo.classtype  = CAR;
            }
            //postcarinfo.classtype = 1;

            char timetmps[30] = "";
            sprintf(timetmps,"%ld", globaltimesec);
            char timetmpu[30] = "";
            sprintf(timetmpu,"%ld", globaltimeusec);

            strcpy(postcarinfo.timestamps, timetmps);
            strcpy(postcarinfo.timestampu, timetmpu);
            postcarinfo.lidar_id = v2xobj.ladar_id;
            postcarinfo.length = FuzzyTrackingframe[i].lenth;
            postcarinfo.width = FuzzyTrackingframe[i].width;
            postcarinfo.height = FuzzyTrackingframe[i].height;
            strcpy(postcarinfo.pic_url, "123123123");
            strcpy(postcarinfo.pcd_url, "123123123");
            postcarinfo.pos_x = FuzzyTrackingframe[i].centerx;
            postcarinfo.pos_y = FuzzyTrackingframe[i].centery;
            postcarinfo.pos_z = FuzzyTrackingframe[i].maxz;
            postcarinfo.speed =  FuzzyTrackingframe[i].fspeed;
            postcarinfo.local_id = v2xobj.local_id;
            postcarinfo.lane = FuzzyTrackingframe[i].lane;
            strcpy(postcarinfo.abnormal_type,"");
           // postcarinfo.lane = nowframe[i].lane;
            strcpy(postcarinfo.origentation, "N");
          //  ExceptionEventJudgment(postcarinfo);
            allwebinfo.push_back(postcarinfo);



          //  V2X_SendObjInfoDraw(FuzzyTrackingframe[i]);
        }
    }

    if(allwebinfo.size() > 0)
    {

        //v2xobj->Post_CarInfo(allwebinfo);
         postcarinfolist.push_back(allwebinfo);
    }
    Trackingtestcloud_.clear();

    std::vector<OBJINFO> tempvec;
    for(int i = 0 ; i < Trackingframe.size() ;i++)
    {
        if(Trackingframe[i].id != -1)
        {
            tempvec.push_back(Trackingframe[i]);

        }


    }

    Trackingframe.clear();
    Trackingframe = tempvec;

    tempvec.clear();

    for(int i = 0 ; i < FuzzyTrackingframe.size() ;i++)
    {
        if(FuzzyTrackingframe[i].id != -1)
        {
            tempvec.push_back(FuzzyTrackingframe[i]);

        }


    }

    FuzzyTrackingframe.clear();
    FuzzyTrackingframe = tempvec;

 #endif

    std::cout << "Jason_TrackingCalculatedSize end " << std::endl;

}

void Jason_CalculateTrackingInfo(std::vector<OBJINFO> preframe, std::vector<OBJINFO> nowframe)
{

    for(int i = 0 ; i < preframe.size() ; i++)
    {
        OBJINFO predata = preframe[i];

        bool issameid = false;
        for(int k = 0 ; k < nowframe.size() ; k++)
        {
            OBJINFO nowdata = nowframe[k];
            if(nowdata.id == predata.id)
            {
                issameid = true;
            }


        }
        if(issameid == false )
        {
                char buf[20] = "";
                sprintf(buf,"%d\n",predata.id);


                QFile file("id.txt");
                file.open(QIODevice::Append );
                file.write(buf);
                file.close();

                char buf1[20] = "";
                sprintf(buf1,"%.2f\n",predata.centerx);
                QFile file1("x.txt");
                file1.open(QIODevice::Append );
                file1.write(buf1);
                file1.close();

                char buf2[20] = "";
                sprintf(buf2,"%.2f\n",predata.centery);
                QFile file2("y.txt");
                file2.open(QIODevice::Append );
                file2.write(buf2);
                file2.close();

                char buf3[30] = "";
                sprintf(buf3,"%f\n",predata.centerz);
                QFile file3("distance.txt");
                file3.open(QIODevice::Append );
                file3.write(buf3);
                file3.close();

                char buf4[30] = "";
                sprintf(buf4,"%d\n",predata.istamp);
                QFile file4("istamp.txt");
                file4.open(QIODevice::Append );
                file4.write(buf4);
                file4.close();

            Trackingframe.push_back(predata);
        }
    }
}

int Jason_DetectionTrackingDraw(std::vector<OBJINFO>   tempframe)
{

    std::cout << "tempframe == " << tempframe.size() << std::endl;
     std::cout << "Trackingframe == " << Trackingframe.size() << std::endl;

    for(int i = 0; i < Trackingframe.size() ;i++)
    {
            OBJINFO tackingdata = Trackingframe[i];

            float fdistance = std::numeric_limits<float>::max();
            int index = -1;

            for(int k = 0 ; k < tempframe.size() ; k++)
            {
                 OBJINFO tempdata = tempframe[k];

                 if(tempdata.centerz < tackingdata.centerz)
                 {
                     continue;
                 }
                 float x = abs(tempdata.centerx - tackingdata.centerx);
                 float y = abs(tempdata.centery - tackingdata.centery);
                 float z = abs(tempdata.centerz - tackingdata.centerz);
                // float z = abs(tempdata.minz - tackingdata.minz);
                      //  float tempdistance = z;//sqrt(pow(z,2.0));//+ pow(y,2.0) pow(x,2.0)
                 float tempdistance = sqrt(pow(x,2.0) + pow(y,2.0) + pow(z,2.0));


                 if(fdistance > tempdistance)
                 {
                     fdistance = tempdistance;
                     index  = k;
                     //std::cout << "idindex " << index << std::endl;
                 }



            }



            if(index == -1 || fdistance > 8)
                      {
                       //   std::cout << "Trackingframe[i].id " <<  Trackingframe[i].id <<  std::endl;

                          FuzzyTrackingframe.push_back(Trackingframe[i]);
                          Trackingframe[i].id = -1;
                      }
                      else
                      {
                          std::cout << "index == " << index << std::endl;
                          Trackingframe[i].centerx = tempframe[index].centerx;
                          Trackingframe[i].centery = tempframe[index].centery;
                          Trackingframe[i].centerz = tempframe[index].centerz;
                          Trackingframe[i].maxx = tempframe[index].maxx;
                          Trackingframe[i].maxy = tempframe[index].maxy;
                          Trackingframe[i].maxz = tempframe[index].maxz;
                          Trackingframe[i].minx = tempframe[index].minx;
                          Trackingframe[i].miny = tempframe[index].miny;
                          Trackingframe[i].minz = tempframe[index].minz;

                          if(Trackingframe[i].width < tempframe[index].width )
                          {
                              Trackingframe[i].width = tempframe[index].width;
                          }

                          if(Trackingframe[i].lenth < tempframe[index].lenth )
                          {
                              Trackingframe[i].lenth = tempframe[index].lenth;
                          }
                          if(Trackingframe[i].height < tempframe[index].height )
                          {
                              Trackingframe[i].height = tempframe[index].height;
                          }

                          float speed = abs(Trackingframe[i].minz - tempframe[index].minz ) * 10 * 3600 / 1000;

                          if(Trackingframe[i].fspeed < speed)
                          {
                              Trackingframe[i].fspeed = speed;
                          }

                      }



    }

}

void jason_FuzzyTrackingDraw()
{
  //  FuzzyTrackingframe

    for(int i = 0 ; i < FuzzyTrackingframe.size() ; i++)
    {
        OBJINFO oneinfo = FuzzyTrackingframe[i];
        float minx = oneinfo.minx - 0.2;
        float maxx = oneinfo.maxx + 0.2;
        float miny = oneinfo.miny - 1;
        float maxy = oneinfo.maxy + 1;
        float minz = oneinfo.minz + 1;
        float maxz = oneinfo.maxz + 3;

        float newcenterpointx = 0.0;
        float newcenterpointy = 0.0;
        float newcenterpointz = 0.0;

        float newmaxpointx = -std::numeric_limits<float>::max();
        float newmaxpointy = -std::numeric_limits<float>::max();
        float newmaxpointz = -std::numeric_limits<float>::max();

        float newminpointx = std::numeric_limits<float>::max();;
        float newminpointy = std::numeric_limits<float>::max();;
        float newminpointz = std::numeric_limits<float>::max();;


        int icount = 0;
        for(int k = 0 ; k < Trackingtestcloud_.size() ;k++)
        {
            pcl::PointXYZRGBA onepoint = Trackingtestcloud_[k];

            if(onepoint.x >= minx && onepoint.x <= maxx && onepoint.y >= miny && onepoint.y<=maxy && onepoint.z >= minz && onepoint.z<=maxz )
            {
                newcenterpointx += onepoint.x;
                newcenterpointy += onepoint.y;
                newcenterpointz += onepoint.z;

                if (onepoint.x < newminpointx)
                    newminpointx = onepoint.x;
                if (onepoint.y < newminpointy)
                    newminpointy = onepoint.y;
                if (onepoint.z < newminpointz)
                    newminpointz = onepoint.z;
                if (onepoint.x > newmaxpointx)
                    newmaxpointx = onepoint.x;
                if (onepoint.y > newmaxpointy)
                    newmaxpointy = onepoint.y;
                if (onepoint.z > newmaxpointz)
                    newmaxpointz = onepoint.z;

                icount++;

            }

        }

        newcenterpointx = newcenterpointx / icount;
        newcenterpointy = newcenterpointy / icount;
        newcenterpointz = newcenterpointz / icount;

        if(icount > 5)
        {
            FuzzyTrackingframe[i].centerx = newcenterpointx;
            FuzzyTrackingframe[i].centery = newcenterpointy;
            FuzzyTrackingframe[i].centerz = newcenterpointz;

            FuzzyTrackingframe[i].maxx = newmaxpointx;
            FuzzyTrackingframe[i].maxy = newmaxpointy;
            FuzzyTrackingframe[i].maxz = newmaxpointz;

            FuzzyTrackingframe[i].minx = newminpointx;
            FuzzyTrackingframe[i].miny = newminpointy;
            FuzzyTrackingframe[i].minz = newminpointz;
        }
        else
        {
            FuzzyTrackingframe[i].id = -1;
        }
    }

  //  Trackingtestcloud_
}

void Jason_Mergingclustering(std::vector<OBJINFO>  & preframe)
{
        vector<int> vecmark;
        vecmark.resize(preframe.size());
        for(int i = 0 ; i < vecmark.size() ; i++)
        {
            vecmark[i] = -1;
        }
        int index = 1;
        for(int i = 0 ; i < preframe.size() ; i++)
        {
            OBJINFO oneinfo = preframe[i];
            if(vecmark[i] == -1)
            {
                vecmark[i] = index++;
            }
            for(int k = i + 1; k < preframe.size() ; k++)
            {
                OBJINFO tempinfo = preframe[k];
                float x = abs(tempinfo.centerx - oneinfo.centerx);
                float y = abs(tempinfo.centery - oneinfo.centery);
                float z = abs(tempinfo.centerz - oneinfo.centerz);
                float distance = sqrt(pow(x,2.0) + pow(y,2.0) + pow(z,2.0));

                std::cout << "tempinfo.minz - oneinfo.maxz " << (tempinfo.minz - oneinfo.maxz) << std::endl;
                std::cout << "oneinfo.minz - tempinfo.maxz " << (oneinfo.minz - tempinfo.maxz) << std::endl;

                std::cout << "tempinfo.minx - oneinfo.minx " << (tempinfo.minx - oneinfo.minx) << std::endl;
                std::cout << "tempinfo.maxx - oneinfo.maxx " << (tempinfo.maxx - oneinfo.maxx) << std::endl;

                if(((tempinfo.minz - oneinfo.maxz ) < 20 && (tempinfo.minz - oneinfo.maxz ) > -20 /*4 10*/)|| ((oneinfo.minz - tempinfo.maxz ) < 20 && (oneinfo.minz - tempinfo.maxz ) > -20 ) )
                {
                    if(abs(tempinfo.minx - oneinfo.minx) < 1.5 && abs(tempinfo.maxx - oneinfo.maxx) < 1.5) /* 0.5 */
                    {
                         vecmark[k] = vecmark[i];
                    }

                }
            }
        }
        std::vector<OBJINFO>  vecframe;

        for(int i = 1 ; i < index ;i++)
        {

            OBJINFO info;
            int count = 0;

            float centerpointx = 0.0;
            float centerpointy = 0.0;
            float centerpointz = 0.0;

            float maxpointx = -std::numeric_limits<float>::max();
            float maxpointy = -std::numeric_limits<float>::max();
            float maxpointz = -std::numeric_limits<float>::max();

            float minpointx = std::numeric_limits<float>::max();;
            float minpointy = std::numeric_limits<float>::max();;
            float minpointz = std::numeric_limits<float>::max();;
             std::string filename;
            for(int k = 0 ; k < preframe.size(); k++)
            {
                if(vecmark[k] == i)
                {
                    OBJINFO tempinfo = preframe[k];
                    centerpointx+=tempinfo.centerx;
                    centerpointy+=tempinfo.centery;
                   // centerpointy+=tempinfo.centerz;

                    if (tempinfo.minx < minpointx)
                        minpointx = tempinfo.minx;
                    if (tempinfo.miny < minpointy)
                        minpointy = tempinfo.miny;
                    if (tempinfo.minz < minpointz)
                        minpointz = tempinfo.minz;
                    if (tempinfo.maxx > maxpointx)
                        maxpointx = tempinfo.maxx;
                    if (tempinfo.maxy > maxpointy)
                        maxpointy = tempinfo.maxy;
                    if (tempinfo.maxz > maxpointz)
                        maxpointz = tempinfo.maxz;

                    filename = tempinfo.filename;
                    count++;
                }
            }



             info.centerx = centerpointx/count;
             info.centery = centerpointy/count;
             info.centerz = centerpointz/count;

             info.maxx = maxpointx;
             info.maxy = maxpointy;
             info.maxz = maxpointz;
             info.minx = minpointx;
             info.miny = minpointy;
             info.minz = minpointz;
             info.lenth = abs(minpointz - maxpointz);
             info.width = abs(minpointx - maxpointx);
             info.height = abs(minpointy - maxpointy);
             info.filename = filename;

             vecframe.push_back(info);

        }
        preframe = vecframe;
}
