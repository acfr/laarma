#include"v2x.h"
class PCLViewer;
extern PCLViewer *mPviewer;
list<cv::Mat> camear_livelist;
extern std::string lidarmac;
extern std::string httpposturl;
using namespace boost::property_tree;
static size_t receive_data_t(void *contents, size_t size, size_t nmemb, void *stream){
   std::string *str = (std::string *)stream;
   (*str).append((char *)contents, size * nmemb);
   return size * nmemb;
}
int64_t v2x_current_timestamp() {
    boost::posix_time::ptime epoch(boost::gregorian::date(1970, boost::gregorian::Jan, 1));
    boost::posix_time::time_duration time_from_epoch =
        boost::posix_time::microsec_clock::universal_time() - epoch;
    return time_from_epoch.total_microseconds();
}
void V2X_Information_Operational::Get_Abnormal_Table()
{

}

void V2X_Information_Operational::Get_LadarInfo_Table()
{

}

void V2X_Information_Operational::Post_LadarConnectInfo()
{

}

void V2X_Information_Operational::Post_V2XInfo()
{
    std::string v2xinfostr;
    int iret = curl_get("http://api_car.neuvition.top/api/lidar_type",v2xinfostr);
    std::stringstream parse_stream(v2xinfostr);
    ptree parseRoot;
    read_json(parse_stream, parseRoot);

}

void V2X_Information_Operational::Post_UpdataLidarConTime()
{

    std::string v2xinfostr;
    char urlbuf[200] = "";
    sprintf(urlbuf,"http://api_car.neuvition.top/api/lidar_details?mac=%s","123456");
    int iret = curl_get(urlbuf,v2xinfostr);

    if(v2xinfostr.size() == 0)
    {
        std::cout << "http connect is fail" << std::endl;
        return ;
    }

    std::stringstream parse_stream(v2xinfostr);

    ptree parseRoot;
    ptree abnormal_setting;
    std::cout << "Post_UpdataLidarConTime" << v2xinfostr << std::endl;

    read_json(parse_stream, parseRoot);
   // abnormal_setting = parseRoot.get_child("abnormal_settings");





     ptree retPtree;
    for (ptree::iterator it = parseRoot.begin(); it != parseRoot.end(); ++it) {
        std::string key = it->first;


        if (key == "code") {
            try { int code = it->second.get_value<int>();
                if(code != 200)
                {
                    this->code = -1;
                    return;
                }
                else
                {
                    this->code = 200;
                    std::cout << "code" << this->code <<  std::endl;

                }
            }
            catch (...) {}
        }
        else if (key == "data") {
             ptree retPtree = parseRoot.get_child("data");
             abnormal_setting = retPtree.get_child("abnormal_settings");
             for (ptree::iterator itret = retPtree.begin(); itret != retPtree.end(); ++itret) {
                 std::string keyret = itret->first;

                 if (keyret == "lidar_id") {
                     try { ladar_id = itret->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyret == "angle") {
                     try { ladarangle = itret->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyret == "height") {
                     try { ladarheight = itret->second.get_value<int>(); }
                     catch (...) {}
                 }
                else if (keyret == "local_id") {
                     try { local_id = itret->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyret == "is_fault") {
                     try { is_fault = itret->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyret == "max_obj_id") {
                     try { objid = itret->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyret == "max_event_id") {
                     try { this->eventid = itret->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if(keyret == "users_id")
                     {
                         this->user_id = itret->second.get_value<int>();
                     }






             }
             std::cout << "local_id" << local_id <<  std::endl;

             for (ptree::iterator itset = abnormal_setting.begin(); itset != abnormal_setting.end(); ++itset) {

                  std::string keyset = itset->first;

                 if (keyset == "over_size_length") {
                     try { iAbnormal_Lentgth = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "over_size_height") {
                     try { iAbnormal_Height = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "over_size_width") {
                     try { iAbnormal_Width = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "max_speed") {
                     try { iAbnormal_MaxSpeed = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "min_speed") {
                     try { iAbnormal_MinSpeed = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "over_size") {
                     try { over_size = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "over_speed") {
                     try { over_speed = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "low_speed") {
                     try { low_speed = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "parking") {
                     try { parking = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "change_lanes") {
                     try { change_lanes = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "back_up") {
                     try { back_up = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "near_miss") {
                     try { near_miss = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "congestion") {
                     try { congestion = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "crash_car") {
                     try { crash_car = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "crash_human") {
                     try { crash_human = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "execp_obj") {
                     try { execp_obj = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "break_in") {
                     try { break_in = itset->second.get_value<int>(); }
                     catch (...) {}
                 }

             }

             std::cout << "over_size_width" << iAbnormal_Width <<  std::endl;

        }
    }






}

void V2X_Information_Operational::Post_TimeUpdataLidarConTime()
{
    std::string v2xinfostr;
    int iret = curl_get("http://api_car.neuvition.top/api/lidar_details?mac=00:0a:35:00:01:00",v2xinfostr);

    if(v2xinfostr.size() == 0)
    {
        std::cout << "http connect is fail" << std::endl;
        return ;
    }

    std::stringstream parse_stream(v2xinfostr);

    ptree parseRoot;
    ptree abnormal_setting;
    std::cout << "Post_UpdataLidarConTime" << v2xinfostr << std::endl;

    read_json(parse_stream, parseRoot);
   // abnormal_setting = parseRoot.get_child("abnormal_settings");





     ptree retPtree;
    for (ptree::iterator it = parseRoot.begin(); it != parseRoot.end(); ++it) {
        std::string key = it->first;


       if (key == "data") {
             ptree retPtree = parseRoot.get_child("data");
             abnormal_setting = retPtree.get_child("abnormal_settings");



             }


             for (ptree::iterator itset = abnormal_setting.begin(); itset != abnormal_setting.end(); ++itset) {

                  std::string keyset = itset->first;

                 if (keyset == "over_size_length") {
                     try { iAbnormal_Lentgth = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "over_size_height") {
                     try { iAbnormal_Height = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "over_size_width") {
                     try { iAbnormal_Width = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "max_speed") {
                     try { iAbnormal_MaxSpeed = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "min_speed") {
                     try { iAbnormal_MinSpeed = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "over_size") {
                     try { over_size = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "over_speed") {
                     try { over_speed = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "low_speed") {
                     try { low_speed = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "parking") {
                     try { parking = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "change_lanes") {
                     try { change_lanes = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "back_up") {
                     try { back_up = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "near_miss") {
                     try { near_miss = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "congestion") {
                     try { congestion = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "crash_car") {
                     try { crash_car = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "crash_human") {
                     try { crash_human = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "execp_obj") {
                     try { execp_obj = itset->second.get_value<int>(); }
                     catch (...) {}
                 }
                 else if (keyset == "break_in") {
                     try { break_in = itset->second.get_value<int>(); }
                     catch (...) {}
                 }

             }


        }

}

void V2X_Information_Operational::Post_CarInfo(std::vector<POSTCAR_INFO> postcarinfo)
{
    boost::property_tree::ptree allDatas;
     boost::property_tree::ptree DataArry;
    for(int i = 0 ; i < postcarinfo.size() ; i++)
    {

    boost::property_tree::ptree Datas;
    char bufkey[100] = "";
    sprintf(bufkey,"%d",i);
    std::string arrkeystr  = bufkey;
    Datas.put(std::string("obj_id"), postcarinfo[i].car_id);


    Datas.put(std::string("obj_type"), postcarinfo[i].classtype);

    Datas.put(std::string("timestamps"), postcarinfo[i].timestamps);
    Datas.put(std::string("timestampu"), postcarinfo[i].timestampu);
    Datas.put(std::string("lidar_id"),postcarinfo[i].lidar_id);
    Datas.put(std::string("length"),postcarinfo[i].length);
    Datas.put(std::string("width"), postcarinfo[i].width);
    Datas.put(std::string("height"), postcarinfo[i].height);
    Datas.put(std::string("pos_x"), postcarinfo[i].pos_x);
    Datas.put(std::string("pos_y"), postcarinfo[i].pos_y);
    Datas.put(std::string("pos_z"), postcarinfo[i].pos_z);

    Datas.put(std::string("speed"), postcarinfo[i].speed);
    Datas.put(std::string("local_id"), postcarinfo[i].local_id);
    Datas.put(std::string("origentation"), postcarinfo[i].origentation);
    Datas.put(std::string("pic_url"), postcarinfo[i].pic_url);
    Datas.put(std::string("pcd_url"), postcarinfo[i].pcd_url);
    Datas.put(std::string("abnormal_type"), postcarinfo[i].abnormal_type);
    Datas.put(std::string("users_id"), this->user_id);
    Datas.put(std::string("lane"), postcarinfo[i].lane);

    DataArry.add_child(arrkeystr,Datas);

    }
    std::cout << "postcarinfo.size() " << postcarinfo.size() << std::endl;

    std::cout << "1111111111111111111111111111111111" << postcarinfo.size() << std::endl;

    allDatas.add_child(std::string("datas"), DataArry);
    std::stringstream sendjson;
    boost::property_tree::write_json(sendjson, allDatas, false);
    char curlbuf[200] = "";
  //  sprintf(curlbuf,"http://39.101.168.11:9501?type=%d@%d",this->local_id,this->ladar_id);
      std::cout << "1111111111111111111111111111111111 " << sendjson.str() << std::endl;
    sprintf(curlbuf,"%s",httpposturl.c_str());
    this->curl_post(curlbuf,sendjson.str());
}


 std::string V2X_Information_Operational::Post_V2XAbnormalEven(uint64 event_id,std::string timestamp,int lidar_id,std::string event_type,std::string image_url,int car_id,int obj_type,int local_id,int lane,int users_id)
{



    boost::property_tree::ptree Datas;



    Datas.put(std::string("event_id"), event_id);
    Datas.put(std::string("timestamp"), timestamp);
    Datas.put(std::string("lidar_id"), lidar_id);
    Datas.put(std::string("abnormal_type"),event_type);
    Datas.put(std::string("image_url"),image_url);
    Datas.put(std::string("car_id"), car_id);
    Datas.put(std::string("obj_type"), obj_type);
    Datas.put(std::string("local_id"), local_id);
    Datas.put(std::string("lane"), lane);
    Datas.put(std::string("users_id"), users_id);






    std::stringstream sendjson;
    boost::property_tree::write_json(sendjson, Datas, false);
    std::cout << "sendjson" << sendjson.str()<<std::endl;
   // this->curl_post("http://api_car.neuvition.top/api/abnormal",sendjson.str());
    this->curl_post("http://192.168.1.214:9000",sendjson.str());
    return sendjson.str();
}

void V2X_Information_Operational::Post_V2XCoordinates()
{

}

int V2X_Information_Operational::Post_Image(const std::string &key, const std::string &localFile)
{
#ifdef _WINDOWS
#else
    Qiniu_Global_Init(-1);

    Qiniu_Mac mac;
mac.accessKey = "4zk5q22rHxBeRgL5xWrjHE20uWe7i8yccM5ug2iF";
mac.secretKey = "8gG1Gb5nvi3wKuknOKwXlLa6nxYBp2jr5PAfgmW5";

char *bucket = "dev-lidar-hub";
//char *key = "neuvsnap_screenface.png";
//char *localFile = "/home/ubuntu/NeuViewerData/pcd/neuvsnap_screenface.png";

Qiniu_Io_PutRet putRet;
Qiniu_Client client;
Qiniu_RS_PutPolicy putPolicy;
Qiniu_Io_PutExtra putExtra;
Qiniu_Zero(putPolicy);
Qiniu_Zero(putExtra);

putPolicy.scope = bucket;

char *uptoken = Qiniu_RS_PutPolicy_Token(&putPolicy, &mac);

//设置机房域名
//Qiniu_Use_Zone_Beimei(Qiniu_False);
//Qiniu_Use_Zone_Huabei(Qiniu_True);
//Qiniu_Use_Zone_Huadong(Qiniu_False);
Qiniu_Use_Zone_Beimei(Qiniu_True);

Qiniu_Client_InitMacAuth(&client, 1024, &mac);
Qiniu_Error error = Qiniu_Io_PutFile(&client, &putRet, uptoken, key.c_str(), localFile.c_str(), &putExtra);
int iRet = -1;
if (error.code != 200) {
    std::cout << "upload error " << std::endl;
    printf("upload file %s:%s error.\n", bucket, key.c_str());
    iRet = -1;
   // debug_log(&client, error);
} else {
    std::cout << "upload suc " << std::endl;
    /*200, 正确返回了, 你可以通过statRet变量查询一些关于这个文件的信息*/
  //  std::cout << "upload file %s:%s success.\n\n", bucket, key.c_str());
    std::cout << "key "  << putRet.key <<std::endl;//("key:\t%s\n",putRet.key);
    std::cout << "hash "  << putRet.hash <<std::endl;//("key:\t%s\n",putRet.key);
   // printf("hash:\t%s\n", putRet.hash);
    iRet = 0;
}
Qiniu_Free(uptoken);
Qiniu_Client_Cleanup(&client);
return iRet;
#endif
return 0;
}
std::string V2X_Information_Operational::curl_post(std::string url,std::string postStr)
{
    std::string strResponse = "";
 #ifndef NO_SEND_WEB


    CURL *curl;



    CURLcode res;

    CURLMcode mres;

    curl_global_init(CURL_GLOBAL_ALL);
    curl = curl_easy_init();


    if (!curl) {
        std::cout << "curl init failed." << endl;
        return "";
    }



    std::cout << " url: " << url << std::endl;
    std::cout << " postStr: " << postStr << std::endl;
    curl_slist *pList = NULL;
    pList = curl_slist_append(pList, "Content-Type: application/json");
    pList = curl_slist_append(pList, "Accept: application/json");
    pList = curl_slist_append(pList, "Connection: close");
    pList = curl_slist_append(pList, "Expect:");
    curl_easy_setopt( curl, CURLOPT_CONNECTTIMEOUT, 1 );
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, pList);
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postStr.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, receive_data_t);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void*)&strResponse);

    std::cout << "post start time" << v2x_current_timestamp() << std::endl;
    res = curl_easy_perform(curl);
     std::cout << "post end time" << v2x_current_timestamp() << std::endl;
    std::cout << " res: " << res << std::endl;
    std::cout << " strResponse: " << strResponse << std::endl;



    curl_easy_cleanup(curl);
    curl_slist_free_all(pList);
    curl_global_cleanup();
 #endif
    return strResponse;

}

int V2X_Information_Operational::curl_get(string url, string & postStr)
{

    std::string strResponse = "";
    CURL *curl;
    CURLcode res;

    curl_global_init(CURL_GLOBAL_ALL);

    curl = curl_easy_init();

    if (!curl) {
        std::cout << "curl init failed." << endl;
        return -1;
    }
    std::cout << " url: " << url << std::endl;

    curl_slist *pList = NULL;
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
       //curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
       curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
       curl_easy_setopt(curl, CURLOPT_TIMEOUT, 1);
       curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 1L);
       curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION,receive_data_t);
       curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void*)&postStr);
       res = curl_easy_perform(curl);
       curl_easy_cleanup(curl);
       std::cout << "curl_get   " << res << std::endl;
       std::cout << "postStr" << postStr.size() << std::endl;
       return res;

}

void V2X_Information_Operational::Post_V2XLiveInfo()
{
    std::string v2xinfoliveaddr;
    int iret = curl_get("http://api_car.neuvition.top/api/live?an=car&sn=road&key=pushurl",v2xinfoliveaddr);
    std::stringstream parse_stream(v2xinfoliveaddr);
    std::cout << "live addr " << v2xinfoliveaddr << std::endl;
    ptree parseRoot;
    read_json(parse_stream, parseRoot);
}

void V2X_Information_Operational::AddAbnormalevnet(std::string eventype,int obj_id,int obj_type,int lane)
{
#if 0
    ABNROMAL_INFO abninfo;
    abninfo.event_id = this->eventid++;
    uint64 iTime1 = v2x_current_timestamp() / 1000 / 1000;
    QString timestring1 = QString::number(iTime1,10);
    std::string strtime1 = timestring1.toStdString();
    abninfo.timestamp = strtime1;
    abninfo.lidar_id = this->ladar_id;
    abninfo.abnormal_type = eventype;
    abninfo.car_id = obj_id;
    abninfo.obj_type = obj_type;
    abninfo.local_id =  this->local_id;
    abninfo.image_url = "http://dev-lh.neuvition.top/";
    abninfo.lane = lane;
    abninfo.users_id = this->user_id;

    list<ABNROMAL_INFO> copyAbnormalinfolist = Abnormalinfolist;
     int idfind = 0;
    if(copyAbnormalinfolist.size()!= 0)
    {

        list<ABNROMAL_INFO>::iterator it = copyAbnormalinfolist.begin();
        for(; it != copyAbnormalinfolist.end() ; it++)
        {
            ABNROMAL_INFO oneinfo = *it;
            if(oneinfo.car_id == abninfo.car_id)
            {
                idfind = 1;
                break;
            }
        }
    }
    if(idfind == 0)
    {
        this->Abnormallist.push_back(this->NowFrame);
        this->Abnormalinfolist.push_back(abninfo);
         this->eventid++;
    }


    std::cout << "AddAbnormalevnet" << std::endl;
#endif 
}
void V2X_Information_Operational::SetNowFrame(cv::Mat frame)
{
    this->NowFrame= frame.clone();

}




int camearimage_live()
{








#if 0


    //海康相机的rtsp url
    //char *inUrl = "rtsp://172.16.136.115:554/3016";
    //nginx-rtmp 直播服务器rtmp推流URL
    char *outUrl = "rtmp://view.neuvition.top/car/road?auth_key=1607499318-0-0-40cd33a6451e11344287f41a9ce14e57";

    //注册所有的编解码器

    avcodec_register_all();

    //注册所有的封装器
    av_register_all();

    //注册所有网络协议
    avformat_network_init();


    VideoCapture cam;
    Mat frame;
    //namedWindow("video");

    //像素格式转换上下文
    SwsContext *vsc = NULL;

    //输出的数据结构
    AVFrame *yuv = NULL;

    //编码器上下文
    AVCodecContext *vc = NULL;

    //rtmp flv 封装器
    AVFormatContext *ic = NULL;


    try
    {   ////////////////////////////////////////////////////////////////
        /// 1 使用opencv打开rtsp相机

        int inWidth = 1280;
        int inHeight = 720;
        int fps = 0;
        fps = 25;

        ///2 初始化格式转换上下文
        vsc = sws_getCachedContext(vsc,
            inWidth, inHeight, AV_PIX_FMT_BGR24,     //源宽、高、像素格式
            inWidth, inHeight, AV_PIX_FMT_YUV420P,//目标宽、高、像素格式
            SWS_BICUBIC,  // 尺寸变化使用算法
            0, 0, 0
            );
        if (!vsc)
        {
            //throw exception("sws_getCachedContext failed!");
             std::cout << "sws_getCachedContext failed!\n" << std::endl;
        }
        ///3 初始化输出的数据结构
        yuv = av_frame_alloc();
        yuv->format = AV_PIX_FMT_YUV420P;
        yuv->width = inWidth;
        yuv->height = inHeight;
        yuv->pts = 0;
        //分配yuv空间
        int ret = av_frame_get_buffer(yuv, 32);
        if (ret != 0)
        {
            char buf[1024] = { 0 };
            av_strerror(ret, buf, sizeof(buf)-1);
            printf("%s\n",buf);
            //throw exception(buf);
        }

        ///4 初始化编码上下文
        //a 找到编码器


        AVCodec *codec = avcodec_find_encoder(AV_CODEC_ID_H264);//AV_CODEC_ID_MJPEG AV_CODEC_ID_H264
        if (!codec)
        {
            std::cout << "Can`t find h264 encoder!\n" << std::endl;
        }
        //b 创建编码器上下文
        vc = avcodec_alloc_context3(codec);
        if (!vc)
        {
            printf("avcodec_alloc_context3 failed!\n");
            //throw exception("avcodec_alloc_context3 failed!");
        }
        //c 配置编码器参数
        vc->flags |= AV_CODEC_FLAG_GLOBAL_HEADER; //全局参数
        vc->codec_id = codec->id;
        vc->thread_count = 8;

        vc->bit_rate = 50 * 1024 * 8;//压缩后每秒视频的bit位大小 50kB
        vc->width = inWidth;
        vc->height = inHeight;
        vc->time_base = { 1, fps };
        vc->framerate = { fps, 1 };

        //画面组的大小，多少帧一个关键帧
        vc->gop_size = 50;
        vc->max_b_frames = 0;
        vc->pix_fmt = AV_PIX_FMT_YUV420P;
       // vc->qmin = 10;   //H264编码重要参数，否则返回-1
       // vc->qmax = 51;
        //d 打开编码器上下文
        ret = avcodec_open2(vc, 0, 0);
        std::cout << "ret  = " << ret << std::endl;
        if (ret != 0)
        {
            char buf[1024] = { 0 };
            av_strerror(ret, buf, sizeof(buf)-1);
             printf("123123123%s\n",buf);
            //throw exception(buf);
        }


        ///5 输出封装器和视频流配置
        //a 创建输出封装器上下文
        ret = avformat_alloc_output_context2(&ic, 0, "flv", outUrl);
        if (ret != 0)
        {
            char buf[1024] = { 0 };
            av_strerror(ret, buf, sizeof(buf)-1);
             printf("33333333%s\n",buf);
            //throw exception(buf);
        }
        //b 添加视频流
        AVStream *vs = avformat_new_stream(ic, NULL);
        if (!vs)
        {
            printf("avformat_new_stream failed\n");
        }
        vs->codecpar->codec_tag = 0;
        //从编码器复制参数
        avcodec_parameters_from_context(vs->codecpar, vc);
        av_dump_format(ic, 0, outUrl, 1);


        ///打开rtmp 的网络输出IO
        ret = avio_open(&ic->pb, outUrl, AVIO_FLAG_WRITE);
        if (ret != 0)
        {
            char buf[1024] = { 0 };
            av_strerror(ret, buf, sizeof(buf)-1);
              printf("%s\n",buf);
        }

        //写入封装头
        ret = avformat_write_header(ic, NULL);
        if (ret != 0)
        {
            char buf[1024] = { 0 };
            av_strerror(ret, buf, sizeof(buf)-1);
              printf("%s\n",buf);
        }

        AVPacket pack;
        memset(&pack, 0, sizeof(pack));
        int vpts = 0;
        for (;;)
        {
            std::cout << "play continue" << std::endl;
            ///读取rtsp视频帧，解码视频帧
            if (camear_livelist.size() == 0)
            {
                usleep(50);
                continue;
            }
            ///yuv转换为rgb
            std::cout << "play frame1111" << std::endl;
            cv::Mat nowframe = camear_livelist.front();
            frame = nowframe.clone();
             std::cout << "play frame size " <<  frame.rows << std::endl;
            camear_livelist.pop_front();
            /*
            if (!cam.retrieve(frame))
            {
                continue;
            }
            */
            imshow("video", frame);
            waitKey(20);
             std::cout << "play frame2222" << std::endl;

            ///rgb to yuv
            //输入的数据结构
            uint8_t *indata[AV_NUM_DATA_POINTERS] = { 0 };
            //indata[0] bgrbgrbgr
            //plane indata[0] bbbbb indata[1]ggggg indata[2]rrrrr
            indata[0] = frame.data;
            int insize[AV_NUM_DATA_POINTERS] = { 0 };
            //一行（宽）数据的字节数
            insize[0] = frame.cols * frame.elemSize();
            int h = sws_scale(vsc, indata, insize, 0, frame.rows, //源数据
                yuv->data, yuv->linesize);
            if (h <= 0)
            {
                 std::cout << "play frame3333" << std::endl;
                continue;
            }
            std::cout << "play hhhhh " << h << std::endl;
            ///h264编码
            yuv->pts = vpts;
            vpts++;
            ret = avcodec_send_frame(vc, yuv);
            if (ret != 0)
                continue;

            ret = avcodec_receive_packet(vc, &pack);
            if (ret != 0 || pack.size > 0)
            {
                //cout << "*" << pack.size << flush;
            }
            else
            {
                continue;
            }
            //推流
            pack.pts = av_rescale_q(pack.pts, vc->time_base, vs->time_base);
            pack.dts = av_rescale_q(pack.dts, vc->time_base, vs->time_base);
            pack.duration = av_rescale_q(pack.duration, vc->time_base, vs->time_base);
            ret = av_interleaved_write_frame(ic, &pack);
            if (ret == 0)
            {
                cout << "#" << flush;
            }
        }

    }
    catch (exception &ex)
    {

        if (vsc)
        {
            sws_freeContext(vsc);
            vsc = NULL;
        }

        if (vc)
        {
            avio_closep(&ic->pb);
            avcodec_free_context(&vc);
        }

        cerr << ex.what() << endl;
    }

#endif
	return 0;
}



int playvideo_online()
{
  /*
    while(1)
    {
        system("/usr/local/ffmpeg/bin/ffmpeg -i neuvition_1127_16132.avi -vcodec libx264 -preset ultrafast -f flv rtmp://view.neuvition.top/car/road?auth_key=1606469833-0-0-6625bb2c7298fa453fc1267fa7c8d446");
    }
    */
	return 0;
}

void AddVideoFrame()
{

}
