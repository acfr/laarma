
#ifdef _WINDOWS
#define _DLL_EXPORT
#include<winsock2.h>


//#define WIN32_LEAN_AND_MEAN
#else
#define _LINUX
#endif
#ifdef _LINUX
#define DECLSPEC_EXPORT  
#define CALLBACK __attribute__((stdcall))
#endif

#ifdef _DLL_EXPORT
#define CALLBACK __stdcall
#ifdef  NEUVWINSDK_EXPORTS
#define DECLSPEC_EXPORT _declspec(dllexport)
#else
#define DECLSPEC_EXPORT _declspec(dllimport)
#endif 
#endif

#include <vector>
#include <cstdlib>
#include <cstdint>
#include <opencv2/imgcodecs.hpp>
 int test_start_rtspcamera(const char * url = "rtsp://192.168.1.101:8554/720p-stream");
 void test_stop_rtspcamera();
 void test_set_rtspfun(void ( * on_rtspdatafun)(int , int , unsigned char  *));
 void test_set_rtspmatfun(void ( * on_rtspdatafun)(int,int64_t ,cv::Mat imgmat));
