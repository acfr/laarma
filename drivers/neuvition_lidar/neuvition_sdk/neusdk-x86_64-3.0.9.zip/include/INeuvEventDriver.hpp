#ifndef  __INEUVEVENTDRIVER_HPP__
#define  __INEUVEVENTDRIVER_HPP__

#include <neuv_defs.hpp>
#include <string.h>

using namespace std;
using namespace neuvition;

class INeuvEventDriver
{

public: 
    INeuvEventDriver(const string deviceId, const string dlObject);
	~INeuvEventDriver();

protected:
	const string _deviceId;
	const string _dlObject;

public:
	int set_flip_axis(const bool flip_x, const bool flip_y);
	int setup_client(const char* host, const int port, INeuvEvent* handler, const bool flag);
	double get_hfov();
	
	double get_vfov();
	int get_device_type();
	
	int set_laser_power(const int percent);
	int set_laser_interval(const int index);
	int set_frame_frequency(const int fps);
	
	int set_camera_status(const bool enabled);
	int set_c_wire_callback(neuvition::on_wire_data_callback);
	int set_c_wire_detection_enabled(bool enabled);
	int start_stream();
	int stop_stream();
	int start_scan();
	int stop_scan();
	int teardown_client();

	int shutdown_device();
	int query_device_status();
	int query_device_params();
	int save_device_params();

	int set_mjpg_curl(const bool enabled);

private:

	void *_obj_handle = NULL;  

};


#endif


