
#include <neuv_defs.hpp>
#include <iostream>
#include <stdio.h>
#include <unistd.h>
class NeuvPczHandler :public neuvition::NeuvEventPCZCallBack
{
       void on_framedata(int code, int64_t microsec, const neuvition::NeuvUnits&  pczdata, const neuvition::nvid_t& frame_id)
       {
              std::cout << "pczdata : " << pczdata.size() << std::endl;
       	      
              for (neuvition::NeuvUnits::const_iterator iter = pczdata.begin();  iter != pczdata.end(); iter++)
              {
                     const neuvition::NeuvUnit& np = (*iter);
                    
              }
       }
void on_framestart(int) {}
void on_framestop() {}
};
int main(int argc, char *argv[])
{
   
       NeuvPczHandler * pHandler = new NeuvPczHandler;
       neuvition::set_pczevent_callback(pHandler);
    //   QString sPath = QString::fromLocal8Bit("/home/jason/0517/cheku/neuvition_0919_102025.pcz");
     //  sPath.toLocal8Bit().toStdString().c_str();
       neuvition::open_pczdata("/home/jason/0517/cheku/neuvition_0919_102025.pcz");
       while(1)
	{	
	   usleep(1000);
	}
       return 0;
}
