#include <neuv_defs.hpp>
#include <iostream>
#include <iomanip>
#include <cmath>
#ifndef _WINDOWS_
#include <unistd.h>
#endif

#include <sys/time.h>

/////////////////////////////////
#include <stdio.h>
#include <fstream>
#include "neuv_duplicateMoments.hpp"

/////////////////////////////////

enum NEU_LASER_RATE {NEU_200KHZ, NEU_300KHZ, NEU_400KHZ, NEU_500KHZ, NEU_750KHZ, NEU_1P5MHZ};

const int CONNECT_STATE_CONNECTING = 0;
const int CONNECT_STATE_CONNECTED = 1;
const int CONNECT_STATE_DISCONNECTED = -1;

static int mConnectState = CONNECT_STATE_DISCONNECTED;

neuvition::NeuvWireDatas mNeuvWireDatas;
neuvition::on_wire_data_callback *wire_data_callback = NULL;

// 获取时间�?
double get_timestamp(void) {
    struct timeval now;
    gettimeofday(&now,0);
    return (double)(now.tv_sec) + (double)(now.tv_usec)/1000000.0;
} 

void showretval(int ret) { if(ret == 0) return; std::cout<<"ret:"<<ret<<std::endl;}

// 对INeuvEvent虚类的实�?
class myeventh : public neuvition::INeuvEvent
{
public:  
    virtual void on_connect(int code,const char* msg) {
        std::cout<<"[NEUVITION]| Connect... code=" << code << ", msg="<< msg << std::endl;
        if (code == 0) {  
            mConnectState = CONNECT_STATE_CONNECTED;
        } else {
            mConnectState = CONNECT_STATE_DISCONNECTED;
        }
    }

    virtual void on_disconnect(int code) {
        if (code == 0) { std::cout<<"[NEUVITION]| Disconnect..." << std::endl; }
        mConnectState = CONNECT_STATE_DISCONNECTED; 
    }

    virtual void on_response(int code,enum neuvition::neuv_cmd_code cmd) {

        switch (cmd) {
            case neuvition::NEUV_CMD_START_SCAN: {
                if (code == 0) { std::cout<<"[NEUVITION]| Start scanning..." << std::endl; }
                break;
            }

            case neuvition::NEUV_CMD_STOP_SCAN: {
                if (code == 0) { std::cout<<"[NEUVITION]| Stop scanning..." << std::endl; }
                break;
            }

            case neuvition::NEUV_CMD_START_STREAM: {
                if (code == 0) { std::cout<<"[NEUVITION]| Start data streaming..." << std::endl; }
                break;
            }

            case neuvition::NEUV_CMD_STOP_STREAM: {
                if (code == 0) { std::cout<<"[NEUVITION]| Stop data streaming..." << std::endl; }
                break;
            }

            // 上传底层设备配置参数
            case neuvition::NEUV_CMD_GET_PARAMS: {
                if (code == 0) { std::cout<<"[NEUVITION]| Device parameters synced..." << std::endl; }
                break;
            }

        }
    }

    void on_framedata(int code, int64_t microsec, const neuvition::NeuvUnits& data, const neuvition::nvid_t& frame_id) {
    
    // 通过回调函数on_framedata()返回点云数据
        // 在此函数中进行点云处�?        
		std::cout<<"[NEUVITION]| On framedata... | Size " << data.size() << std::endl;
 	

        if (data.size() == 0) return;
   
        int itest = 0;
        for (neuvition::NeuvUnits::const_iterator iter = data.begin(); iter != data.end(); iter++) {
            const neuvition::NeuvUnit& np = (*iter);
		
            if(itest == 0)
	    {
               std::cout<<"[NEUVITION]| On framedata... | microsec " << np.timestamp << std::endl; // np.timestamp 是每个点的时间戳。正常一帧只要获取一个点的时间戳即可
            }
	    itest++;
            float x = np.x*0.001;
            float y = np.y*0.001;
            float z = np.z*0.001;
        // 如果设置摄像头开启，并开启图像获取，则RGB为真实颜色，否则�?28
            uint8_t r = np.r; 
            uint8_t g = np.g; 
            uint8_t b = np.b;
            uint8_t intensity = np.intensity;   
            uint32_t timestamp = np.timestamp;
        }
    }

    void on_imudata(int code,int64_t microsec, const neuvition::NeuvUnits& data,const neuvition::ImuData& imu) {}

    void on_pczdata(bool status) {}

   void on_mjpgdata(int code, int64_t microsec, cv::Mat mat) {

	
	   std::cout<<"[NEUVITION]| On 111111111111111111111 on_mjpgdata... | time | "<<microsec <<std::endl; // microsec为图像时间戳
        

    }

    void on_Ladar_Camera( const neuvition::NeuvCameraLadarDatas& datas) {

    }
};

void on_wire_data_callback_func(int frame_id, int64_t microsec, float temp, const neuvition::NeuvUnit* points,
	int cloudsize, const neuvition::NeuvWireData* wire_data, int wire_size) {
	std::cout << frame_id << " " << microsec << " " << temp << " " << cloudsize << " " << wire_size << std::endl;
	mNeuvWireDatas.clear();
	mNeuvWireDatas.resize(wire_size);
	for (int i = 0; i < wire_size; ++i) {
		neuvition::NeuvWireData wp = wire_data[i];
		mNeuvWireDatas.push_back(wp);
		//neu_log(NEU_INFO, "id=%d, angle=%d, high=%d  ", wp.id, wp.angle, wp.high);
	}
	//std::cout << std::endl;
}


#if 1

#include <boost/date_time.hpp>
#include <boost/atomic.hpp>

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/impl/point_types.hpp>
#include <pcl/visualization/cloud_viewer.h>

pcl::visualization::CloudViewer g_PCL_viewer("Process_G_Filter_Viewer");
pcl::PointCloud<pcl::PointXYZRGB>::Ptr g_pcl = boost::make_shared<pcl::PointCloud<pcl::PointXYZRGB> >();

int64_t curt_timestamp()
{
	boost::posix_time::ptime epoch(boost::gregorian::date(1970, boost::gregorian::Jan, 1));
	boost::posix_time::time_duration time_from_epoch =
		boost::posix_time::microsec_clock::universal_time() - epoch;
	return time_from_epoch.total_microseconds();
}

int main(int argc, char* argv[]) 
{
	neuvition::NeuvUnits	pt_frame;
    char*       			buffer = new char[sizeof(neuvition::NeuvUnit)];
	neuvition::Neuv_PointImage			pt_Img;

	
	//pcl::visualization::CloudViewer PCL_viewer("Test_Viewer");
	pcl::PointCloud<pcl::PointXYZRGB>::Ptr _pcl = boost::make_shared<pcl::PointCloud<pcl::PointXYZRGB>>();

	neuvition::set_npvt_value(3);
	neuvition::Load_Matrix_FromFile("Martix_0_274994596.data");

	///////////////////////////////////////////////////////////////////////////////////////
	
	std::ifstream iframe("Frame_5_1853706891.raw", std::ifstream::binary);

	if(iframe)
    	std::cout << "File open success and Reading data as a block0 -- point info: ";

	while(iframe)
	{
		iframe.read(buffer, sizeof(neuvition::NeuvUnit));

		if(iframe)
		{
			neuvition::NeuvUnit* ptrPoint = (neuvition::NeuvUnit*)buffer;

            //std::cout << "(x, y, z, row, col, tof) = " << ptrPoint->x << ", " << ptrPoint->y << ", " << ptrPoint->z 
            //          << ", " << ptrPoint->row << ", " << ptrPoint->col << ", " << ptrPoint->tof << std::endl;  

			pt_frame.push_back(*ptrPoint);
		}
    }

	iframe.close();

	std::cout << "The Original Frame0 Size = " << pt_frame.size() << ", start gaus filter at : " << curt_timestamp() << std::endl;

	neuvition::g_filter_shaddowCopy(&pt_frame);

	
//	///////////////////////////////////////////////////////////////////////////////////////
//    pt_frame.clear();
//	
//	iframe = std::ifstream("Frame_841_1204075020.raw", std::ifstream::binary);
//
//	if(iframe)
//		std::cout << "File open success and Reading data as a block0 -- point info: ";
//
//	while(iframe)
//	{
//		iframe.read(buffer, sizeof(neuvition::NeuvUnit));
//
//		if(iframe)
//		{
//			neuvition::NeuvUnit* ptrPoint = (neuvition::NeuvUnit*)buffer;
//
//			//std::cout << "(x, y, z, row, col, tof) = " << ptrPoint->x << ", " << ptrPoint->y << ", " << ptrPoint->z 
//			//			<< ", " << ptrPoint->row << ", " << ptrPoint->col << ", " << ptrPoint->tof << std::endl;  
//
//			pt_frame.push_back(*ptrPoint);
//		}
//	}
//
//	iframe.close();
//
//	std::cout << "The Original Frame0 Size = " << pt_frame.size() << ", start gaus filter at : " << curt_timestamp() << std::endl;
//
//	neuvition::g_filter_shaddowCopy(&pt_frame);

	//neuvition::g_gaus_fit(0, &pt_frame);
	neuvition::NeuvUnits* p = &pt_frame;
	neuvition::g_filter_exec(1, 0, p);
	
	std::cout << "\n\n##finish at : " << curt_timestamp() << std::endl;

	//to do project the points for 2D image
//	pt_Img.loadToFImage(pt_frame);
//
	for (int i = 0; i < p->size(); i++)
	{
		pcl::PointXYZRGB  test_p;
	
		test_p.x = p->at(i).x * 0.001; 
        test_p.y = p->at(i).y * 0.001; 
        test_p.z = p->at(i).z * 0.001;

		test_p.r = p->at(i).r; test_p.g= p->at(i).g;  test_p.b = p->at(i).b;

		g_pcl->push_back(test_p);
	}

	g_PCL_viewer.showCloud(g_pcl);
	while(!g_PCL_viewer.wasStopped())
	{
		sleep(1);
	}
	
	pt_frame.clear();
	
//	////////////////////////////////////////////////////////////////////////////
//	std::ifstream iframe2("Frame_1_1886026426.raw", std::ifstream::binary);
//	
//	if(iframe2)
//		std::cout << "File open success and Reading data as a block2 -- point info: ";
//
//	while(iframe2)
//	{
//		iframe2.read(buffer, sizeof(neuvition::NeuvUnit));
//
//		if(iframe2)
//		{
//			neuvition::NeuvUnit* ptrPoint = (neuvition::NeuvUnit*)buffer;
//
//			//std::cout << "(x, y, z, row, col, tof) = " << ptrPoint->x << ", " << ptrPoint->y << ", " << ptrPoint->z 
//			//			<< ", " << ptrPoint->row << ", " << ptrPoint->col << ", " << ptrPoint->tof << std::endl;  
//
//			pt_frame.push_back(*ptrPoint);
//		}
//	}
//	
//	iframe2.close();
//
//	std::cout << "The Original Frame1 Size = " << pt_frame.size() << ", start gaus filter at : " << curt_timestamp() << std::endl;
//	neuvition::g_gaus_fit(1, &pt_frame);
//	std::cout << "\n\n##finish at : " << curt_timestamp() << std::endl;
//


    delete[] buffer;


//while(!PCL_viewer.wasStopped())
//{
//	PCL_viewer.showCloud(_pcl);
	
    //PCL_viewer.removeAllPointClouds();
	//PCL_viewer.addPointCloud(_pcl); 
	//PCL_viewer.updatePointCloud(_pcl, "test"); 
	//PCL_viewer.spinOnce(0.000001);
//}

	//	pcl::visualization::PCLVisualizer g_PCL_viewer("Process_point_Viewer");
	//
	//	pcl::io::loadPCDFile("//work_dir/TestData/PCD_with_PTZ/neuvsnap_0318_092722.pcd", *_pcl);


	//	std::cout << "\n\nStart do KD search at " << curt_timestamp() << std::endl;
	//	neuvition::g_gaus_fit_via_LOAM(0, &pt_frame);
	//	  std::cout << "##finish at : " << curt_timestamp() << std::endl;

  	return 1;
}


#else

int main(int argc, char* argv[]) {
    int ret=0;

    // int i = 0;
    // for (i = 0; i < argc; ++i){
    //     printf("argv[%d], %s\n", i, *(argv + i*sizeof(char)));
    // }

	//////////////////////////////////////////////////////
	//it is sure the this will be ahead of process_points()

	//////////////////////////////////////////////////////			


    // 可�? X/Y轴翻�?    
	ret = neuvition::set_flip_axis(false,true);
    showretval(ret);

	neuvition::INeuvEvent* phandler = new myeventh();

    mConnectState = CONNECT_STATE_CONNECTING;
    // 建立与底层设备的连接
    ret = neuvition::setup_client("192.168.1.101",6668,phandler/*event-handler*/,false/*auto-reconnect*/);
    sleep(1);

    while(mConnectState == CONNECT_STATE_CONNECTING) {
        usleep(10000);
        printf("waiting...\n");
    }

    usleep(20000);

    // 查询状�?    
	if (mConnectState == CONNECT_STATE_CONNECTED) 
	{
    	// 获取设备视场角、设备类型、俯仰角、位置参�? 
       double hfov = neuvition::get_hfov();
        double vfov = neuvition::get_vfov();
        int device_type = neuvition::get_device_type();
        double bias_y = 0.0;    //设备俯仰角，默认�?

		//neuvition::set_npvt_value(3);

        // 设置激光功�?
        // 范围值：0~65%
        ret = neuvition::set_laser_power(70);
        usleep(20000);//20ms

        // 设置激光发射频率档�?        
		// 可选值：0: 200KHZ 1:300KHZ 2:400KHZ 3:500KHZ 4:750KHZ 5:1MHZ
        ret = neuvition::set_laser_interval(NEU_500KHZ);
        usleep(20000);//20ms

        // 设置点云帧率FPS
        // 可选值：3/5/6/10/15/20/30
        ret = neuvition::set_frame_frequency(10);
        usleep(20000);//20ms

      	
	
  		// 可�? 设置摄像头开启，并开启图像获�?        
		// 如果不使用，直接注释
        ret = neuvition::set_camera_status(true);


	   std::cout<<"[NEUVITION]| ret "<<ret <<std::endl;
        
        ret = neuvition::set_mjpg_curl(true);
		std::cout<<"[NEUVITION]| ret "<<ret <<std::endl;
        
		if (wire_data_callback == NULL) {
		    wire_data_callback = new neuvition::on_wire_data_callback;
		    *wire_data_callback = &on_wire_data_callback_func;
		    neuvition::set_c_wire_callback(*wire_data_callback);
		}
		neuvition::set_c_wire_detection_enabled(true);
        

        // 请求底层设备开始扫�?        
		ret=neuvition::start_scan();
        sleep(2); // 2s

        // 请求底层设备开始送点云流
        ret=neuvition::start_stream();
    

        // 等待10�?从底层设备获取TOF数据并回�?        
		// 等待时间可自行定�?        
		sleep(6000);

        // 请求底层设备停止送点云流
        ret=neuvition::stop_stream();
        usleep(20000);//20ms

        // 请求底层设备停止扫描
        ret=neuvition::stop_scan();

        // 断开与底层设备的连接
        ret=neuvition::teardown_client();
        usleep(200000);//20ms

    } 

    sleep(1);
    delete phandler;
    return 0;

}

#endif


