
#include "INeuvEventDriver.hpp"
#include <iostream>
#include <dlfcn.h>

INeuvEventDriver::INeuvEventDriver(const string devId, const string dlfname):_deviceId(devId), _dlObject(dlfname)
{
	_obj_handle = dlopen(dlfname.c_str(), RTLD_LOCAL | RTLD_LAZY);  

    if (_obj_handle == NULL) 
	{  
        std::cout << "critical error happened, not found the dll library, pls check the file path. err = " 
			      << dlerror() << std::endl;  
        exit(1);  
    }  
}

INeuvEventDriver::~INeuvEventDriver()
{
	if(!_obj_handle)
	{
		dlclose(_obj_handle); 
	}
}

int INeuvEventDriver::set_flip_axis(const bool flip_x, const bool flip_y)
{
	char *error;

	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_set_flip_axis)(const bool, const bool);
    
    _set_flip_axis = (int (*)(const bool, const bool))dlsym(_obj_handle, "_ZN9neuvition13set_flip_axisEbb");

    error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle, error = " << string(error) << std::endl;
		exit(1);
	}

	return (*_set_flip_axis)(flip_x, flip_y);
}

int INeuvEventDriver::setup_client(const char* host, const int port, INeuvEvent* handler, const bool flag)
{
	char *error;

	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_setup_client)(const char*, const int, INeuvEvent*, const bool);
    
    _setup_client = (int (*)(const char*, const int, INeuvEvent*, const bool))dlsym(_obj_handle, "_ZN9neuvition12setup_clientEPKciPNS_10INeuvEventEb");

    error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = " << string(error) << std::endl;
		exit(1);
	}

	return (*_setup_client)(host, port, handler, flag);
	
}

double INeuvEventDriver::get_hfov()
{
	char *error;

	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	double (*_get_hfov)();
    
    _get_hfov = (double(*)())dlsym(_obj_handle, "_ZN9neuvition8get_hfovEv");

    error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = " << string(error) << std::endl;
		exit(1);
	}

	return (*_get_hfov)();
}

double INeuvEventDriver::get_vfov()
{
	char *error;
	
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	double (*_get_vfov)();
    
    _get_vfov = (double(*)())dlsym(_obj_handle, "_ZN9neuvition8get_vfovEv");

    error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = "  << string(error) << std::endl;
		exit(1);
	}

	return (*_get_vfov)();

}


int INeuvEventDriver::get_device_type()
{
	char *error;
	
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_get_device_type)();
    
    _get_device_type = (int(*)())dlsym(_obj_handle, "_ZN9neuvition15get_device_typeEv");

    error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = "  << string(error) << std::endl;
		exit(1);
	}

	return (*_get_device_type)();
}

int INeuvEventDriver::set_laser_power(const int percent)
{
	char *error;
	
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_set_laser_power)(const int);
    
    _set_laser_power = (int(*)(const int))dlsym(_obj_handle, "_ZN9neuvition15set_laser_powerEi");

    error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = "  << string(error) << std::endl;
		exit(1);
	}

	return (*_set_laser_power)(percent);

}

int INeuvEventDriver::set_laser_interval(const int index)
{
	char *error;
	
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_set_laser_interval)(const int);
    
    _set_laser_interval = (int(*)(const int))dlsym(_obj_handle, "_ZN9neuvition18set_laser_intervalEi");

    error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = "  << string(error) << std::endl;
		exit(1);
	}

	return (*_set_laser_interval)(index);

}

int INeuvEventDriver::set_frame_frequency(const int fps)
{
	char *error;
	
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_set_frame_frequency)(const int);
    
    _set_frame_frequency = (int(*)(const int))dlsym(_obj_handle, "_ZN9neuvition19set_frame_frequencyEi");

    error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = "  << string(error) << std::endl;
		exit(1);
	}

	return (*_set_frame_frequency)(fps);
}

int INeuvEventDriver::set_camera_status(const bool enabled)
{
	char *error;
	
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_set_camera_status)(const bool);
    
    _set_camera_status = (int(*)(const bool))dlsym(_obj_handle, "_ZN9neuvition17set_camera_statusEb");

    error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = "  << string(error) << std::endl;
		exit(1);
	}

	return (*_set_camera_status)(enabled);

}

int INeuvEventDriver::set_c_wire_callback(neuvition::on_wire_data_callback cbfunc)
{
	char *error;
	
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_set_c_wire_callback)(neuvition::on_wire_data_callback);
    
    _set_c_wire_callback = (int(*)(neuvition::on_wire_data_callback))dlsym(_obj_handle, 
		 "_ZN9neuvition19set_c_wire_callbackEPFvilfPKNS_9NEUV_UNITEiPKNS_13NEUV_WIREDATAEiE");

    error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = "  << string(error) << std::endl;
		exit(1);
	}

	return (*_set_c_wire_callback)(cbfunc);
}

int INeuvEventDriver::set_c_wire_detection_enabled(bool enabled)
{
	char *error;
	
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_set_c_wire_detection_enabled)(bool);
    
    _set_c_wire_detection_enabled = (int(*)(bool))dlsym(_obj_handle, "_ZN9neuvition28set_c_wire_detection_enabledEb");

    error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = "  << string(error) << std::endl;
		exit(1);
	}

	return (*_set_c_wire_detection_enabled)(enabled);

}

int INeuvEventDriver::start_stream()
{
	char *error;
		
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_start_stream)();
	
	_start_stream = (int(*)())dlsym(_obj_handle, "_ZN9neuvition12start_streamEv");

	error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = "  << string(error) << std::endl;
		exit(1);
	}

	return (*_start_stream)();
}

int INeuvEventDriver::stop_stream()
{
	char *error;
		
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_stop_stream)();
	
	_stop_stream = (int(*)())dlsym(_obj_handle, "_ZN9neuvition11stop_streamEv");

	error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = "  << string(error) << std::endl;
		exit(1);
	}

	return (*_stop_stream)();
}

int INeuvEventDriver::start_scan()
{
	char *error;
		
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_start_scan)();
	
	_start_scan = (int(*)())dlsym(_obj_handle, "_ZN9neuvition10start_scanEv");

	error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = "  << string(error) << std::endl;
		exit(1);
	}

	return (*_start_scan)();
}

int INeuvEventDriver::stop_scan()
{
	char *error;
		
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_stop_scan)();
	
	_stop_scan = (int(*)())dlsym(_obj_handle, "_ZN9neuvition9stop_scanEv");

	error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = "  << string(error) << std::endl;
		exit(1);
	}

	return (*_stop_scan)();

}

int INeuvEventDriver::teardown_client()
{
	char *error;
		
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_teardown_client)();
	
	_teardown_client = (int(*)())dlsym(_obj_handle, "_ZN9neuvition15teardown_clientEv");

	error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = "  << string(error) << std::endl;
		exit(1);
	}

	return (*_teardown_client)();
}


int INeuvEventDriver::set_mjpg_curl(const bool enabled)
{
	char *error;
		
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_set_mjpg_curl)(const bool);
	
	_set_mjpg_curl = (int(*)(const bool))dlsym(_obj_handle, "_ZN9neuvition13set_mjpg_curlEb");

	error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = "  << string(error) << std::endl;
		exit(1);
	}

	return (*_set_mjpg_curl)(enabled);

}

int INeuvEventDriver::shutdown_device()
{
	char *error;
		
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_shutdown_device)();
	
	_shutdown_device = (int(*)())dlsym(_obj_handle, "_ZN9neuvition15shutdown_deviceEv");

	error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = "  << string(error) << std::endl;
		exit(1);
	}

	return (*_shutdown_device)();

}

int INeuvEventDriver::query_device_status()
{
	char *error;
		
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_query_device_status)();
	
	_query_device_status = (int(*)())dlsym(_obj_handle, "_ZN9neuvition19query_device_statusEv");

	error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = "  << string(error) << std::endl;
		exit(1);
	}

	return (*_query_device_status)();
}

int INeuvEventDriver::query_device_params()
{
	char *error;
		
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_query_device_params)();
	
	_query_device_params = (int(*)())dlsym(_obj_handle, "_ZN9neuvition19query_device_paramsEv");

	error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = "  << string(error) << std::endl;
		exit(1);
	}

	return (*_query_device_params)();

}


int INeuvEventDriver::save_device_params()
{
	char *error;
			
	if (_obj_handle == NULL) 
	{
		std::cout << "critical error as invalid handle" << std::endl;
		exit(1);
	}

	int (*_save_device_params)();
	
	_save_device_params = (int(*)())dlsym(_obj_handle, "_ZN9neuvition18save_device_paramsEv");

	error = dlerror();
	if(error != NULL)
	{
		std::cout << "not found the function or invalid handle,  error = " << string(error) << std::endl;
		exit(1);
	}

	return (*_save_device_params)();

}


