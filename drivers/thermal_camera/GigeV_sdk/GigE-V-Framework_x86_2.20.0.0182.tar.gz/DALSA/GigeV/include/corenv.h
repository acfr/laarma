#define COR_LINUX 1
#define COR_WIN32 0

