multicast_demo
=====================

Note on "Preliminary" support for Multicast :

The multicast demo operates only via standard network socket accesses.
The required multicast group membership code has not yet been integrated into 
the higher performance PF_PACKET interface.

Running the demo with the PF_PACKET interface enabled (via CAP_NET_RAW or 
using "sudo -E") will still work but falls back internally to use the 
standard socket layer accesses.

Any Jumbo-Frame MTU settings for the NIC (suggested for best performance) 
must be suitable for all receivers of the multicast stream. 


